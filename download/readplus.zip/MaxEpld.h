/************************************************/
/*												*/
/*	definition file for EPLD hardware V1.5		*/
/*  including RELAY control for cartridge       */
/*  automatic power off 						*/ 
/*  add delay for relay							*/
/*  add support for Nintendo flash cart         */
/*												*/
/************************************************/

unsigned ctrl_port;
unsigned data_port;
unsigned status_port;

/*** Ivan Soh, 6 Dec 00 - Added Unsigned definitions for clarity. ***/
#define U8		unsigned char
#define U16		unsigned short
/*** end of definitions***/


#define CTRL    ctrl_port
#define DATA    data_port
#define STATUS  status_port

/*
 * Bits for MUX (C B A):
 *      ~AUTOFDXT ~SCLINT ~STROBE
 * Bits in CTRL register (7..0):
 *      N/A N/A N/A IRQEnable ~SCLINT INIT ~AUTOFDXT ~STROBE
 */

#define MASK            0x00
#define nSTROBE         0x01
#define nAUTOFDXT       0x02
#define INIT            0x04
#define nSCLINT         0x08

/* CTRL MUX */
#define GET_LOW         MASK | nAUTOFDXT | nSCLINT | nSTROBE
#define GET_HIGH        MASK | nAUTOFDXT | nSCLINT
#define SET_DATA        MASK | nAUTOFDXT           | nSTROBE
#define DATA_REG        MASK | nAUTOFDXT
#define LOW_ADDR        MASK |             nSCLINT | nSTROBE
#define HIGH_ADDR       MASK |             nSCLINT
#define RELAY        	MASK |                       nSTROBE
#define NOP             MASK

/* CTRL U3 */
#define MREQ            INIT

/* Load a register: toggle CK (OFF and ON) */
#define LOAD(reg)       OUTPORT(CTRL, reg); OUTPORT(CTRL, NOP)

/* Put data on the bus */
#define WRITE(val)      OUTPORT(DATA, val)

/* Disable LED */
#define LED_OFF         WRITE(0x00); LOAD(RELAY)

/* Following line sets RELAY_OFF pin high. */
/* This should turn CART power off???. */
#define LED_ON          WRITE(0x01); LOAD(RELAY)

/*
 * Bits read (7..0):
 *      BUSY ~ACKPR PE SLCT ERROR N/A N/A N/A
 * Bits from REGISTER (D7..D4, D3..D0):
 *      SLCT PE BUSY ~ACK
 */

#define D7(val)             (val & 0x10) << 3
#define D6(val)             (val & 0x20) << 1
#define D5(val)             ((val ^ 0x80) & 0x80) >> 2
#define D4(val)             (val & 0x40) >> 2
#define D3(val)             (val & 0x10) >> 1
#define D2(val)             (val & 0x20) >> 3
#define D1(val)             ((val ^ 0x80) & 0x80) >> 6
#define D0(val)             (val & 0x40) >> 6

/* read data from RAM(1) or ROM(0) */
BYTE READ(BYTE Mode)
{                           
	BYTE low,high;
	
    OUTPORT(CTRL, GET_LOW  | (Mode*MREQ)); 
    low = INPORT(STATUS);
    OUTPORT(CTRL, NOP);
    OUTPORT(CTRL, GET_HIGH | (Mode*MREQ));
    high = INPORT(STATUS);
    OUTPORT(CTRL, NOP);
    return( D7(high)|D6(high)|D5(high)|D4(high)|D3(low)|D2(low)|D1(low)|D0(low) );
}                           

/* write data in bank-switch IC */
void WRITE_BKSW(data, address) 
{
	WRITE((BYTE)data); 
	LOAD(DATA_REG);    
	WRITE((BYTE)(address >> 8)); 
	LOAD(HIGH_ADDR);   
	WRITE((BYTE)(address & 0x00FF)); 
	LOAD(LOW_ADDR);    
	WRITE(0x00); 
	OUTPORT(CTRL, SET_DATA);
	WRITE(0x01);       
	WRITE(0x00); 
	OUTPORT(CTRL, NOP);
}

/* write data in RAM */
void WRITE_MEM(val)
{
	WRITE((BYTE)val);
	LOAD(DATA_REG);
    WRITE(0x00); 
    OUTPORT(CTRL, SET_DATA); 
	OUTPORT(CTRL, SET_DATA | MREQ); 
	WRITE(0x01); 
	WRITE(0x00); 
	OUTPORT(CTRL, NOP);
}

/* write data in Flash IC */
void WRITE_FLASH(val)
{
	  WRITE((BYTE)val);
	  LOAD(DATA_REG);   
      WRITE(0x00); 
      OUTPORT(CTRL, SET_DATA); 
	  WRITE(0x02);    
	  WRITE(0x00); 
	  OUTPORT(CTRL, NOP);
}

/* write data in Nintendo flash cart */
void WRITE_NFLASH(val)
{
      WRITE((BYTE)val);
      LOAD(DATA_REG);
      WRITE(0x00);
      OUTPORT(CTRL, SET_DATA );
      WRITE(0x01);
      WRITE(0x00);
      OUTPORT(CTRL, NOP);
}

/* write low address byte */
void ADDRESS_LOW(val)
{
	WRITE((BYTE)val);
	LOAD(LOW_ADDR);
}

/* write high address byte */
void ADDRESS_HIGH(val)
{
	WRITE((BYTE)val);
	LOAD(HIGH_ADDR);
}

/* usage of hardware */     
void usage_hardware(void)
{
	printf("\t-l\tSpecify the port to use (default is 1 = LPT1)\n");
}	

/* init port */
void init_port(int port)
{
	data_port = *(unsigned far *)MK_FP(0x0040, 6 + 2*port);
	if(data_port == 0)
	{
		printf("Can't find address of parallel port %d...\n", port);
		exit(1);
	} else {
		status_port = data_port + 1;
		ctrl_port   = data_port + 2;
		if(data_port != 0x378) printf("Parallel port %d is located at %X-%X\n", port, data_port, ctrl_port);

		/* This is where we turn on CART power, by setting RELAY_OFF (EPLD.79) to high. */
		WRITE(0x01);
		LOAD(RELAY);   
		delaytime(0x8000);	/* Let power stabilise. */
	}
}

/* Test program for EPLD hardware */
void test()
{
        printf("\nD0 - D7 data lines check !\n");
        printf("Check pins <22 up to 29> of GB connector\n");
        WRITE(0x00);
        LOAD(LOW_ADDR);
        LOAD(HIGH_ADDR);
        LOAD(DATA_REG);
        OUTPORT(CTRL, SET_DATA);
		printf("They should all be low. Press <RETURN>\n");
		getch();

		OUTPORT(CTRL, NOP);
        WRITE(0xFF);
        LOAD(DATA_REG);
        OUTPORT(CTRL, SET_DATA);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();
        
        OUTPORT(CTRL, NOP);
        printf("\n\n\nA0 - A7 address lines check !\n");
        printf("Check pins <6 up to 13> of GB connector\n");
        WRITE(0x00);
        LOAD(LOW_ADDR);
		printf("They should all be low. Press <RETURN>\n");
		getch();

        WRITE(0xFF);
        LOAD(LOW_ADDR);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nA8 - A15 address lines check !\n");
        printf("Check pins <14 up to 21> of GB connector\n");
        WRITE(0x00);
        LOAD(HIGH_ADDR);
		printf("They should all be low. Press <RETURN>\n");
		getch();

        WRITE(0xFF);
        LOAD(HIGH_ADDR);
        printf("Now, they should all be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nCS line check !\n");
        printf("check pin <5> of GB connector\n");
        OUTPORT(CTRL, MREQ);
		printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nRD line check !\n");
        printf("check pin <4> of GB connector\n");
        OUTPORT(CTRL, NOP);
		printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, SET_DATA);
        printf("Should be high. Press <RETURN>\n");
		getch();
        
        OUTPORT(CTRL, NOP);
        printf("\n\n\nWR line check !\n");
        printf("check pin <3> of GB connector\n");
        WRITE(0x01);
        LOAD(DATA_REG);
		OUTPORT(CTRL, SET_DATA);
        printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        printf("\n\n\nAudio IN line check !\n");
        printf("check pin <31> of GB connector\n");
        WRITE(0x02);
        LOAD(DATA_REG);
		OUTPORT(CTRL, SET_DATA);
        printf("Should be low. Press <RETURN>\n");
		getch();

        OUTPORT(CTRL, NOP);
        printf("Should be high. Press <RETURN>\n");
		getch();

        LED_OFF;	/* Remove CART power (ie. RELAY_OFF [a.k.a. PWR_ON#] at EPLD.79 high). */
        printf("\n\n\nTest complete !\n\n");
}


/************************************************************************\
 Description: Test program for EPLD hardware - 
	Additional tests added for HMP with Debug LEDs - Ivan Soh, 6 Dec 00 
\************************************************************************/

/************************************************************************\

	Test Utilities (This section must come before the Test Programs).

\************************************************************************/
/*** Test utilties ***/
void WriteDataBus(int d7d0bus)
{

		/* Write data. */
        OUTPORT(CTRL, NOP);			/* Ensure any previous action is termined. */

        WRITE(d7d0bus);				/* Set up data bus PD[7..0]. */
        LOAD(DATA_REG);				/* Clock data PD[7..0] into output data reg. */

        WRITE(0x01);				/* Arm WR# signal */
        OUTPORT(CTRL, SET_DATA);	/* Let D[7..0] appear on EPLD pins, same time setting
        							   WR# low.
        							 */
        WRITE(0x00);				/* Set WR# high to latch D[7..0] into debug LEDs. 
        							   At this point, data is still present on data bus,
        							   and can be probed if necessary.
        							 */
        OUTPORT(CTRL, SET_DATA);	/* Let D[7..0] appear on EPLD pins, same time setting
        							   WR# low.
        							 */
        OUTPORT(CTRL, NOP);			/* Ensure any previous action is termined. */


}


void WriteAddrBus(U16 AddrBus)
{
	U8	AddrLo, AddrHi;

#if 0
	/* Break 16 bit address into low and high bytes. */
	AddrLo = (U8*) (AddrBus & 0x00FF);
	AddrHi = (U8*) (AddrBus >> 0x08);
#endif

	AddrLo = AddrBus;
	AddrHi = AddrBus >> 8;


	/* Send it out to the address pins on EPLD. */
	WRITE(AddrLo);
	LOAD(LOW_ADDR);

	WRITE(AddrHi);
	LOAD(HIGH_ADDR);
}



void WaitTime(long i)
{
	long j;
	for (j = 0; j <= i; j++)
	{
		delay_20ms();
	}	
}




/************************************************************************\
   This is the power on test. The relay is turned on and CART Power LED is
   lit. Then it is turned off and CAR Power should be removed and should
   decay to 0V slowly (capacitance on the line).
\************************************************************************/
void TEST_CartPower()
{
        printf("\nCART power on test !\n");
        printf("Pin 1 of CART connector should now be +5V.\n");
        printf("CART power LED should be lit.\n");
        printf("Press a key to continue...\n");
		LED_ON;        
		getch();

        printf("\n\nCART power should now be removed.\n");
		LED_OFF;        
		// getch();

        printf("\n\n\n*** CART power on/off test complete ***!\n\n");
}




/************************************************************************\
   DATA RIPPLE TEST.

   This ripples data bits.

   CART power is turned ON before starting test and turned off at the
   end of test. This allows CART D[7..0] to be tested as well if one
   is inserted in the GB connector.
\************************************************************************/
void TEST_DataRipple()
{

	int tCount1, tCount2, d7d0_init1, d7d0_init2, d7d0, DataBits;
	int Ripples, WaitDelay1;
	
        printf("\nDATA RIPPLE TEST !\n");
        printf("Applying CART power now...\n");
		LED_ON;

		/* Set address bus to high (Addr Debug LEDs off). */
		WriteAddrBus(0xFFFF);

		/* Initialise variables. */
		d7d0_init1 = 0x01;
		d7d0_init2 = d7d0_init1 << 7;
		DataBits = 8;			// How many data bits are there?

		Ripples = 0x02;			// How many times do we run this test?
		WaitDelay1 = 0x03;		// Wait for this delay in between bit display.
		

		/* Walking 1 test. */
		printf("\nData bus walking 1 test...\n");	

		for (tCount1 = 0; tCount1 < Ripples; tCount1++)
		{
			d7d0 = d7d0_init1;
			for (tCount2 = 0; tCount2 <= DataBits; tCount2++, d7d0 = d7d0 << 1)
			{
				WriteDataBus(d7d0);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

			d7d0 = d7d0_init2;	// No start from MSB
			for (tCount2 = 0; tCount2 <= DataBits; tCount2++, d7d0 = d7d0 >> 1)
			{
				WriteDataBus(d7d0);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

		}


		/* Walking 0 test. */
		printf("Data bus walking 0 test...\n");	

		for (tCount1 = 0; tCount1 < Ripples; tCount1++)
		{
			d7d0 = d7d0_init1;
			for (tCount2 = 0; tCount2 <= DataBits; tCount2++, d7d0 = d7d0 << 1)
			{
				WriteDataBus(~d7d0);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

			d7d0 = d7d0_init2;	// No start from MSB
			for (tCount2 = 0; tCount2 <= DataBits; tCount2++, d7d0 = d7d0 >> 1)
			{
				WriteDataBus(~d7d0);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

		}

		// Set Debug Data Output LEDs off so we insert a Cart. */
		WriteDataBus(0x00);		

		/* Remove CART power. */
        printf("\n\nPowring CART down.\n");
		LED_OFF;        
		// getch();

        printf("\n\n\n*** DATA RIPPLE TEST complete ***\n\n");
}


/************************************************************************\
   ADDRESS RIPPLE TEST.

   This ripples addres bits.

   CART power is turned ON before starting test and turned off at the
   end of test. This allows CART D[7..0] to be tested as well if one
   is inserted in the GB connector.
\************************************************************************/
void TEST_AddrRipple()
{

	int 	tCount1, tCount2;
	int 	Ripples, WaitDelay1;
	U8		AddrBits;
	U16		addr_init1, addr_init2, addr;
	
        printf("\nADDR RIPPLE TEST !\n");
        printf("Applying CART power now....\n");
		LED_ON;

		/* Set Data Bus high (Data Debug LEDs off). */
		WriteDataBus(0xFF);	

		/* Initialise variables. */
		addr_init1 = 0x0001;
		addr_init2 = addr_init1 << 15;
		AddrBits = 16;			// How many address bits are there?

		Ripples = 0x02;			// How many times do we run this test?
		WaitDelay1 = 0x02;		// Wait for this delay in between bit display.

		/* Walking 1 test. */
		printf("\nAddress bus walking 1 test...\n");	

		for (tCount1 = 0; tCount1 < Ripples; tCount1++)
		{
			addr = addr_init1;
			for (tCount2 = 0; tCount2 <= AddrBits; tCount2++, addr = addr << 1)
			{
				WriteAddrBus(addr);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

			addr = addr_init2;	// No start from MSB
			for (tCount2 = 0; tCount2 <= AddrBits; tCount2++, addr = addr >> 1)
			{
				WriteAddrBus(addr);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

		}


		/* Walking 0 test. */
		printf("Address bus walking 0 test...\n");	

		for (tCount1 = 0; tCount1 < Ripples; tCount1++)
		{
			addr = addr_init1;
			for (tCount2 = 0; tCount2 <= AddrBits; tCount2++, addr = addr << 1)
			{
				WriteAddrBus(~addr);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

			addr = addr_init2;	// No start from MSB
			for (tCount2 = 0; tCount2 <= AddrBits; tCount2++, addr = addr >> 1)
			{
				WriteAddrBus(~addr);
				WaitTime(WaitDelay1);
				//getch();		// For debug only.
			}

		}

		// Set Debug Addr LEDs off so we insert a Cart. */
		WriteDataBus(0x00FF);	// Set LEDs all ON.



		/* Remove CART power. */
        printf("\n\nPowring CART down.\n");
		LED_OFF;        
		// getch();

        printf("\n\n\n*** ADDR RIPPLE TEST complete ***\n\n");
}



