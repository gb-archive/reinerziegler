XCARTIO - a FLASH cartridge programmer for the Nintendo Gameboy
---------------------------------------------------------------
Distribution file version 1.12, 07-Jan-99.


Xilinx EPLD implementation and PCB design by 
Andrew March
amarch@icenet.com.au
http://www.icenet.com.au/~amarch

based on an Altera EPLD implementation by
Reiner Ziegler
reinerziegler@gmx.de
http://www.reinerziegler.de


Disclaimer 
----------
This design is supplied without any warranty whatsoever, use at your own risk. 
I have built the unit and it works to my satisfaction. Your mileage may vary. 


Revision History
----------------
xc110.zip        First release 26-Dec-98
xc111.zip        Second release 26-Dec-98
                 Added bill of materials to readme.txt 
xc112.zip        Third release 07-Jan-99
                 Added EPLD circuit diagrams
                 Added JPEGs of XCARTIO and FLASH cart


Distribution files (xc110.zip)
---------------------------------
readme.txt       Yep, you're reading it.
xc110sch.pdf     Schematic version 1.10 in pdf format
xc110ovl.pdf     Component overlay PCB version 1.10 in pdf format 
xc110cop.pdf     Artwork PCB version 1.10 in pdf format
xc110cop.ps      Artwork PCB version 1.10 in postscript format
xc110.pcb        PCB design file version 1.10 in Protel Easytrax format
xc100.jed        Xilinx device programming file version 1.00
x100pld1.pdf     Xilinx EPLD circuit diagram page 1 of 4
x100pld2.pdf     Xilinx EPLD circuit diagram page 2 of 4
x100pld3.pdf     Xilinx EPLD circuit diagram page 3 of 4
x100pld4.pdf     Xilinx EPLD circuit diagram page 4 of 4
xc100top.jpg     Photograph of XCARTIO prototype - top view
xc100bot.jpg     Photograph of XCARTIO prototype - solder side view
c3guts.jpg       Inside of FLASH cartridge (Jeff Frohwein pic)
c3cart.jpg       Wiring diagram of FLASH cartridge (Jeff Frohwein pic)

 

What is XCARTIO?
----------------
XCARTIO is a FLASH cartridge programmer for the Nintendo Game Boy. It is used to
reload the memory of a Game Boy cartridge that has had its mask ROM replaced
with a 29F040 FLASH ROM. 

XCARTIO connects to the parallel (printer) port of a DOS/Windows PC running 
Reiner Ziegler's ReadPlus software (readepld.exe). The FLASH cartridge simply
plugs into the mating connector on the XCARTIO unit.  

XCARTIO is a Xilinx EPLD and single-sided PCB implementation of an Altera EPLD 
design by Reiner Ziegler. This in turn was based on a HC logic design by Pascal 
Felber known as CARTIO. A double-sided PCB for CARTIO was designed by Jeff 
Frohwein for his Carbon Copy Card project (aka C3).


Where can I get a FLASH cartridge?
----------------------------------
You have to make it yourself. See Reiner Ziegler's web-site for instructions.


Where do I get the software?
----------------------------
Visit Reiner Ziegler's web-site for the latest version of his ReadPlus software. 
XCARTIO requires the readepld.exe executable. It was tested with version 3.25.


Where can I buy a PCB?
----------------------
This is a constructional project, you make the PCB yourself. Full artwork and
a Protel Easytrax design file are provided in this distribution.

Depending on demand, a short form kit comprising PCB and EPLD only might become 
available so drop me a line to show your interest.


Where can I buy the components?
-------------------------------
That depends on where you live. In Perth, Western Australia, I get most parts  
from Altronics, the SIL resistor networks from RS Components and the Xilinx EPLD 
from Prospec Components. 

The Game Boy cartridge connector can be hard to get. I pulled one out of an old 
Game Boy. 
 

How do I program the Xilinx EPLD?
---------------------------------
Fortunately a dedicated EPLD programmer unit is NOT required. The Xilinx EPLD can 
be programmed AFTER it is soldered onto the XCARTIO PCB using a fairly simple 
JTAG download cable. 

Unless you have a Xilinx Foundation Series development system, a good way to go 
about this is to build my EZTag download cable and use the public domain EZTag 
software from Xilinx. See my web-site for a separate distribution file for EZTag 
(ez100.zip) and the programming software (eztag_pc.zip).


Bill of Materials
-----------------
Qty  Item                                     Designator
1    Printed circuit board XCARTIO 1.10       PCB
1    4k7 1/4W 5% resistor                     R1         
1    10k x 8 way SIL resistor network         S1         
1    1k x 8 way SIL resistor network          S2         
1    100k x 8 way SIL resistor network        S3         
1    47uF 25V electrolytic capacitor 0.1"     C1         
6    0.1uF 50V mono ceramic capacitor 0.1"    C2 C3 C4 C5 C6 C7         
1    1N4001 1A silicon diode                  D1         
1    1N4148 small signal silicon diode        D2         
1    Red LED 5mm                              L1         
1    Green LED 5mm                            L2         
1    BC548 NPN transistor                     Q1         
1    7805 voltage regulator in TO-220         U1         
1    Xilinx XC9572-15PC84 15ns EPLD in PLCC84 U2         
1    Relay 12V coil DPDT (Meisei M4-12H)      RLY1       
1    Game Boy cartridge socket                J1         
1    26 way DIL header (2 x 13 way) 0.1"      J2         
1    7 way SIL header 0.1"                    J3         
1    DC jack 2.5mm PC mount                   J4         
1    TO-220 heatsink for voltage regulator
3    M3 bolts 8mm
3    M3 nuts
     Tinned copper wire for links 

Cable to connect to PC:
1    Length ribbon cable, 25 way, 1 metre
1    IDC-26 header socket (2 x 13 way)  
1    DB25 male IDC connector
 

Constructor's notes:
--------------------
Fit the links, then components starting with lowest height, and then the 
connectors. Do not install the EPLD just yet.

When soldering components with many pins, tack solder just two pins first 
then check component orientation and seating against PCB before proceeding. 

The Game Boy connector mounting feet will have to be filed to let the pins
protrude through the PCB (the connector was designed for a thinner PCB than 
normal).

Before fitting the EPLD, apply power and check that the +5V rail is good. 

Remove power then surface mount the EPLD to the solder side of the PCB.

After soldering on the EPLD it is a good idea to clean off the solder flux and
use a magnifying glass and good light to check for solder bridges and dry joints.

The J2 header connects the XCARTIO unit to the PC via ribbon cable. This should be 
less than 1 metre in length. Before crimping on the connectors, strip the cable 
down to just 25 conductors. Fit an IDC26 socket to one end of the cable and an 
IDC DB25M plug to the other. Make sure pin 1 of both connectors aligns with the 
same conductor of the ribbon (usually the striped wire). 

To program the EPLD, connect the EZTag flying lead to J3. Remove the ribbon cable 
from J2 and plug it into the EZTag PCB instead. Apply power and download the JEDEC
file using the EZTag PC software. 

When programming finishes, disconnect power, remove the EZTag cable from J3 and 
replace the ribbon cable in J2.

Restore power, open a DOS box and launch readepld.exe with the -t option to run the 
test procedure.


-----------
End of file