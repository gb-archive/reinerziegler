// IO56.h : main header file for the IO56 application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CIO56App:
// See IO56.cpp for the implementation of this class
//

class CIO56App : public CWinApp
{
public:
	CIO56App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIO56App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	
	// Implementation

	//{{AFX_MSG(CIO56App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
