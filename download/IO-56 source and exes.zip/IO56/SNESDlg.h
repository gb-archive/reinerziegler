// SNESDlg.h : header file
//

#define SNES_RD	0
#define SNES_WR	1
#define SNES_RAME	2
#define SNES_POE	3

#define SNES_IDLE	OUTPORT(A_8255_PC, 0xFF)
#define SNES_RD_ROM   	OUTPORT(A_8255_PC, 0xFF-(0x01<<SNES_RD)-(0x01<<SNES_POE))
#define SNES_RD_LORAM	OUTPORT(A_8255_PC, 0xFF-(0x01<<SNES_RD)-(0x01<<SNES_POE))
#define SNES_RD_HIRAM	OUTPORT(A_8255_PC, 0xFF-(0x01<<SNES_RD))
#define SNES_WR_LORAM	OUTPORT(A_8255_PC, 0xFF-(0x01<<SNES_POE))
#define SNES_WR_HIRAM	OUTPORT(A_8255_PC, 0xFF)

#define SNES_LOROM	((snes_header[21]&0x0F)!=1)

static unsigned long snes_sram_addr;
static unsigned char snes_header[100] = {0};

UINT SNESAnalyzeThread(LPVOID pParam);
UINT SNESSaveThread(LPVOID pParam);
UINT SNESTestStaticRAMThread(LPVOID pParam);
UINT SNESClearStaticRAMThread(LPVOID pParam);
UINT SNESSaveStaticRAMThread(LPVOID pParam);
UINT SNESRestoreStaticRAMThread(LPVOID pParam);

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg dialog

class CSNESDlg : public CDialog
{
// Construction
public:
	CSNESDlg(CWnd* pParent = NULL);   // standard constructor

	BOOL m_Advanced, m_Analyzing, m_Saving, m_TestingStaticRAM,
	     m_ClearingStaticRAM, m_SavingStaticRAM, m_RestoringStaticRAM;
	
	void UpdateDialog();

	CString m_buffer, m_filename;

	FILE *fp;

	CString GetOperation(LPARAM lParam);

	DWORD        dwExitCode;
	CWinThread   *pThread;

	inline int snes_read_byte(register unsigned long);
	inline void snes_write_byte(register int, register unsigned long);
	void snes_read_header();
	void snes_init();
	void snes_analyze();
	void snes_save(FILE*);
	void snes_backup(FILE *);
	void snes_restore(FILE *);
	void snes_clear();
	void snes_test();

// Dialog Data
	//{{AFX_DATA(CSNESDlg)
	enum { IDD = IDD_SNES_DIALOG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSNESDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSNESDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdvancedButton();
	afx_msg void OnAnalyzeButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnSaveButton();
	afx_msg void OnSNESFilenameBrowseButton();
	afx_msg void OnStaticRAMBrowseButton();
	afx_msg void OnTestStaticRAMButton();
	afx_msg void OnClearStaticRAMButton();
	afx_msg void OnSaveStaticRAMButton();
	afx_msg void OnRestoreStaticRAMButton();
	afx_msg void OnHelpButton();
	afx_msg void OnSetcommandbitsButton();
	afx_msg void OnSetaddressButton();
	afx_msg void OnChangeAddressEdit();
	afx_msg void OnKillfocusAddressEdit();
	virtual void OnCancel();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	afx_msg long OnThreadFinished(WPARAM wParam, LPARAM lParam);
	afx_msg long OnThreadStarted(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
