// DebugTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "IO568255Ctrl.h"
#include "IO56OutputBufferCtrl.h"
#include "globals.h"
#include "PreferencesDlg.h"
#include "DebugTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDebugTestDlg dialog

CDebugTestDlg::CDebugTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDebugTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDebugTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CDebugTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugTestDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDebugTestDlg, CDialog)
	//{{AFX_MSG_MAP(CDebugTestDlg)
	ON_BN_CLICKED(IDC_BACK_BUTTON,        OnBackButton)
	ON_BN_CLICKED(IDC_NEXT_BUTTON,        OnNextButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON, OnPreferencesButton)
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,    OnMainmenuButton)
	ON_BN_CLICKED(IDC_DEBUG_BUTTON,       OnDebugButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON,        OnHelpButton)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugTestDlg message handlers

BOOL CDebugTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_warnings)
	{
	   if (MessageBox("Before performing the Debug Test,\nplease remove any attached extension!\n\nDo you wish to continue?", 
	      "IO-56 Debug Test Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnCancel();
		  return TRUE;
	   }
	}

	CRect CtrlALocation(15, 5, 504, 137);
	ChipACtrl.m_PinsStart = 33;
	ChipACtrl.m_WindowTitle = _T("Harris CP8255A");
	ChipACtrl.Create(IDD_8255CTRL_DIALOG, this);
	ChipACtrl.m_ReadOnly = TRUE;
	ChipACtrl.SetPorts(0,0,0,0,0);
	ChipACtrl.MoveWindow(CtrlALocation, TRUE);
	ChipACtrl.UpdateDialog();
	
	CRect CtrlBLocation(15, 5, 504, 137);
	ChipBCtrl.m_PinsStart = 9;
	ChipBCtrl.m_WindowTitle = _T("Harris CP8255B");
	ChipBCtrl.Create(IDD_8255CTRL_DIALOG, this);
	ChipBCtrl.m_ReadOnly = TRUE;
	ChipBCtrl.SetPorts(0,0,0,0,0);
	ChipBCtrl.MoveWindow(CtrlBLocation, TRUE);	
	ChipBCtrl.UpdateDialog();
	
	CRect CtrlOutputBuffer(128, 35, 392, 107);
	OutputBufferCtrl.m_PinsStart = 1;
	OutputBufferCtrl.m_WindowTitle = _T("Output Buffer");
	OutputBufferCtrl.Create(IDD_OUTPUTBUFFERCTRL_DIALOG, this);
	OutputBufferCtrl.m_ReadOnly = TRUE;
	OutputBufferCtrl.MoveWindow(CtrlOutputBuffer, TRUE);
	OutputBufferCtrl.UpdateDialog();
	
	((CAnimateCtrl *)GetDlgItem(IDC_DEBUGTESTING_AVI))->Open(IDR_DEBUGTESTING_AVI);
	
	OUTPORT(B_8255_PROG, 0x80 | PA_out | PB_out | PCl_out | PCh_out);
	OUTPORT(A_8255_PROG, 0x80 | PA_out | PB_out | PCl_out | PCh_out);

	m_nCurrentTest = 0;

	OnNextButton();

	return TRUE; 
}

/////////////////////////////////////////////////////////////////////////////
// CDebugTestDlg Command Buttons message handlers

void CDebugTestDlg::OnBackButton() 
{
	switch(m_nCurrentTest)
	{	
		case 10:
			ChipACtrl.ShowWindow(SW_HIDE);
			ChipBCtrl.ShowWindow(SW_HIDE);
			OutputBufferCtrl.ShowWindow(SW_SHOW);
			break;

		case 34:
			OutputBufferCtrl.ShowWindow(SW_HIDE);
			ChipACtrl.ShowWindow(SW_HIDE);
			ChipBCtrl.ShowWindow(SW_SHOW);
			break;

		case 58:
			((CButton *)GetDlgItem(IDC_NEXT_BUTTON))->EnableWindow(TRUE);
			break;				
	}
	
	m_nCurrentTest -= 2;

	OnNextButton();
}

void CDebugTestDlg::OnNextButton() 
{
	m_nCurrentTest++;

	switch(m_nCurrentTest)
	{	
		case 1:
			ChipACtrl.ShowWindow(SW_HIDE);
			ChipBCtrl.ShowWindow(SW_HIDE);
			OutputBufferCtrl.ShowWindow(SW_SHOW);
			((CButton *)GetDlgItem(IDC_BACK_BUTTON))->EnableWindow(FALSE);

			SetDlgItemText(IDC_MESSAGE_STATIC, 
			"\nPlease remove all extensions from the IO-56 card, and\nclick next. Use a multimeter to check for the correct output.");
			
			OutputBufferCtrl.SetValue(0);
			OUTPORT(BUFFER,0);
			break;

		case 2:
			((CButton *)GetDlgItem(IDC_BACK_BUTTON))->EnableWindow(TRUE);
			break;

		case 10:
			OutputBufferCtrl.ShowWindow(SW_HIDE);
			ChipACtrl.ShowWindow(SW_HIDE);
			ChipBCtrl.ShowWindow(SW_SHOW);
			break;

		case 34:
			ChipBCtrl.ShowWindow(SW_HIDE);
			OutputBufferCtrl.ShowWindow(SW_HIDE);
			ChipACtrl.ShowWindow(SW_SHOW);
			break;

		case 58:
			((CButton *)GetDlgItem(IDC_NEXT_BUTTON))->EnableWindow(FALSE);
			SetDlgItemText(IDC_MESSAGE_STATIC, 
			"\nIO-56 Debug Test Completed.");
			ChipACtrl.SetValues(0,0,0,0,0);
			OUTPORT(BUFFER,0);
			OUTPORT(A_8255_PA, 0);
			OUTPORT(A_8255_PB, 0);
			OUTPORT(A_8255_PC, 0);
			break;	
	}

	if (m_nCurrentTest > 1 && m_nCurrentTest < 10)
	{		
		m_value = 1 << (m_nCurrentTest - 2);
		m_buffer.Format("\nData on pins 1..8 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);
		OutputBufferCtrl.SetValue(m_value);
		OUTPORT(BUFFER,m_value);

	}

	if (m_nCurrentTest > 9 && m_nCurrentTest < 18)
	{		
		m_value = 1 << (m_nCurrentTest - 10);
		m_buffer.Format("\nData on pins 9..16 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipBCtrl.SetValues(m_value,0,0,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(B_8255_PA, m_value);
		OUTPORT(B_8255_PB, 0);
		OUTPORT(B_8255_PC, 0);
	}
	
	if (m_nCurrentTest > 17 && m_nCurrentTest < 26)
	{		
		m_value = 1 << (m_nCurrentTest - 18);
		m_buffer.Format("\nData on pins 17..24 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipBCtrl.SetValues(0,m_value,0,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(B_8255_PA, 0);
		OUTPORT(B_8255_PB, m_value);
		OUTPORT(B_8255_PC, 0);
		
	}

	if (m_nCurrentTest > 25 && m_nCurrentTest < 34)
	{		
		m_value = 1 << (m_nCurrentTest - 26);
		m_buffer.Format("\nData on pins 25..32 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipBCtrl.SetValues(0,0,m_value,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(B_8255_PA, 0);
		OUTPORT(B_8255_PB, 0);
		OUTPORT(B_8255_PC, m_value);
		
	}

	if (m_nCurrentTest > 33 && m_nCurrentTest < 42)
	{		
		m_value = 1 << (m_nCurrentTest - 34);
		m_buffer.Format("\nData on pins 33..40 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipACtrl.SetValues(m_value,0,0,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(A_8255_PA, m_value);
		OUTPORT(A_8255_PB, 0);
		OUTPORT(A_8255_PC, 0);
				
	}
	
	if (m_nCurrentTest > 41 && m_nCurrentTest < 50)
	{		
		m_value = 1 << (m_nCurrentTest - 42);
		m_buffer.Format("\nData on pins 41..48 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipACtrl.SetValues(0,m_value,0,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(A_8255_PA, 0);
		OUTPORT(A_8255_PB, m_value);
		OUTPORT(A_8255_PC, 0);
		
	}

	if (m_nCurrentTest > 49 && m_nCurrentTest < 58)
	{		
		m_value = 1 << (m_nCurrentTest - 50);
		m_buffer.Format("\nData on pins 49..56 should be 0x%02X.", m_value);
		SetDlgItemText(IDC_MESSAGE_STATIC, m_buffer);	
		ChipACtrl.SetValues(0,0,m_value,0,0);
		OUTPORT(BUFFER,0);
		OUTPORT(A_8255_PA, 0);
		OUTPORT(A_8255_PB, 0);
		OUTPORT(A_8255_PC, m_value);
	}
}

void CDebugTestDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;
	dlg.DoModal();	

	m_nCurrentTest--;

	OnNextButton();
}

void CDebugTestDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUDEBUGSYSTEMDEBUGTEST);
}

BOOL CDebugTestDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

void CDebugTestDlg::OnDebugButton() 
{
	OnCancel();
}

void CDebugTestDlg::OnMainmenuButton() 
{
	OnOK();
}
