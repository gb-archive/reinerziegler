// GameboyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "GameboyDlg.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg dialog

CGameboyDlg::CGameboyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGameboyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGameboyDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CGameboyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGameboyDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGameboyDlg, CDialog)
	//{{AFX_MSG_MAP(CGameboyDlg)
	ON_BN_CLICKED(IDC_SAVE_BUTTON,             OnSaveButton)
	ON_BN_CLICKED(IDC_ANALYZE_BUTTON,          OnAnalyzeButton)
	ON_BN_CLICKED(IDC_ADVANCED_BUTTON,         OnAdvancedButton)
	ON_BN_CLICKED(IDC_STATICRAMBROWSE_BUTTON,  OnStaticRAMBrowseButton)
	ON_BN_CLICKED(IDC_GBFILENAMEBROWSE_BUTTON, OnGBFilenameBrowseButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON,      OnPreferencesButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON,             OnHelpButton)
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,         OnMainmenuButton)
	ON_BN_CLICKED(IDC_TESTSTATICRAM_BUTTON,    OnTestStaticRAMButton)
	ON_BN_CLICKED(IDC_CLEARSTATICRAM_BUTTON,   OnClearStaticRAMButton)
	ON_BN_CLICKED(IDC_SAVESTATICRAM_BUTTON,    OnSaveStaticRAMButton)
	ON_BN_CLICKED(IDC_RESTORESTATICRAM_BUTTON, OnRestoreStaticRAMButton)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FINISHEDTHREADMESSAGE, OnThreadFinished)
	ON_MESSAGE(STARTEDTHREADMESSAGE,  OnThreadStarted )

	ON_EN_CHANGE(IDC_GBFILENAME_EDIT,        UpdateDialog)
	ON_EN_CHANGE(IDC_STATICRAMFILENAME_EDIT, UpdateDialog)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Threads 

UINT GBAnalyzeThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 1L);	
	pDlg->gb_analyze();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 1L);

	return 0;
}

UINT GBSaveThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;

	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 2L);	

	CheckFileExtension(IDC_GBFILENAME_EDIT, _T("gb"), filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
	   buffer.Format(_T("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again."), filename); 
	   
	   pDlg->MessageBox(buffer, _T("IO-56 Gameboy File Error!"), MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
	   return 0;
	}
	
	pDlg->gb_save(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 2L);

	return 0;
}

UINT GBSaveStaticRAMThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;
	CString filename, buffer;
	
	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 5L);	
	
	CheckFileExtension(IDC_STATICRAMFILENAME_EDIT, _T("grm"), filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
	   buffer.Format(_T("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again."), filename); 
	   
	   pDlg->MessageBox(buffer,_T("IO-56 Gameboy File Error!"), MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 5L);
	   return 0;
	}

	pDlg->gb_backup(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 5L);

	return 0;
}

UINT GBRestoreStaticRAMThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;
	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 6L);	
	
	CheckFileExtension(IDC_STATICRAMFILENAME_EDIT, _T("grm"), filename, pDlg);

	if ((pDlg->fp = fopen(filename, "rb")) == NULL)
	{
	   buffer.Format(_T("An error occurred while reading \"%s\"!\n\nPlease correct the problem and try again."), filename); 
	   
	   pDlg->MessageBox(buffer,_T("IO-56 Gameboy File Error!"), MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 6L);
	   return 0;
	}

	pDlg->gb_restore(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 6L);

	return 0;
}

UINT GBTestStaticRAMThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;
	
	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 3L);	
	pDlg->gb_test();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 3L);

	return 0;
}

UINT GBClearStaticRAMThread(LPVOID pPaRAM)
{
	CGameboyDlg *pDlg = (CGameboyDlg *)pPaRAM;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 4L);	
	pDlg->gb_clear();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 4L);

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Thread Message Handlers

long CGameboyDlg::OnThreadStarted(WPARAM wParam, LPARAM lParam)
{
	((CEdit *)GetDlgItem(IDC_GBSTATISTICS_EDIT))->SetWindowText(_T(""));
	((CEdit *)GetDlgItem(IDC_GBSTATUS_EDIT    ))->SetWindowText(_T(""));

	fp = NULL;

	m_buffer.Format(_T("-------- %s started at %s --------\r\n\r\n"), 
			GetOperation(lParam), GetTime());
		
	AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);
	
	return(0L);
}

long CGameboyDlg::OnThreadFinished(WPARAM wParam, LPARAM lParam)
{
	switch (lParam)
	{
		case 1:		   m_Analyzing = FALSE; break;
		case 2:		      m_Saving	= FALSE; break;
		case 3:	   m_TestingStaticRAM	= FALSE; break;
		case 4:   m_ClearingStaticRAM	= FALSE; break;
		case 5:	     m_SavingStaticRAM	= FALSE; break;
		case 6:	  m_RestoringStaticRAM	= FALSE; break;
	}

	if (fp)
		fclose(fp);

	if (wParam)
	{
		if (dwExitCode)
		   TerminateThread(pThread->m_hThread, dwExitCode);

		dwExitCode = 0;

		m_buffer.Format(_T("\r\n\r\n-------- %s terminated at %s --------\r\n\r\n"), 
			GetOperation(lParam), GetTime());	
	}
	else
	{
		m_buffer.Format(_T("\r\n-------- %s finished at %s --------\r\n"),
		GetOperation(lParam), GetTime()); 
	}

	AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);
		
	UpdateDialog();

	return (0L);
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Custom Functions

CString CGameboyDlg::GetOperation(LPARAM lParam)
{
	CString buffer;

	switch (lParam)
	{
		case 1:	buffer = _T("Analyzing");             break;
		case 2:	buffer = _T("Saving");                break;
		case 3:	buffer = _T("Testing");               break;
		case 4:	buffer = _T("Clearing");              break;
		case 5:	buffer = _T("Saving Static RAM");     break;
		case 6:	buffer = _T("Restoring Static RAM");  break;
	}

	return(buffer);
}

void CGameboyDlg::UpdateDialog()
{	
	// UpdateData(TRUE);   Uncomment When Verify Has Been Added
	
	SetDlgItemText(IDC_ADVANCED_BUTTON,         m_Advanced           ? _T("Standard") : _T("Advanced"));
	SetDlgItemText(IDC_SAVE_BUTTON,             m_Saving             ? _T("Stop")     : _T("Save"    ));
	SetDlgItemText(IDC_ANALYZE_BUTTON,          m_Analyzing          ? _T("Stop")     : _T("Analyze" ));

	SetDlgItemText(IDC_TESTSTATICRAM_BUTTON,    m_TestingStaticRAM
		? _T("Stop") : _T("Test Static RAM")   );
	SetDlgItemText(IDC_CLEARSTATICRAM_BUTTON,   m_ClearingStaticRAM 
		? _T("Stop") : _T("Clear Static RAM")  );
	SetDlgItemText(IDC_SAVESTATICRAM_BUTTON,    m_SavingStaticRAM
		? _T("Stop") : _T("Save Static RAM")   );
	SetDlgItemText(IDC_RESTORESTATICRAM_BUTTON, m_RestoringStaticRAM
		? _T("Stop") : _T("Restore Static RAM"));

	int operation = (m_Advanced) ? SW_SHOW : SW_HIDE;

	// Show Advanced Controls Here
	
	operation = !(	m_Analyzing		||             m_Saving ||
			m_TestingStaticRAM	||  m_ClearingStaticRAM ||
			m_SavingStaticRAM	|| m_RestoringStaticRAM   );

	// Enable Advanced Controls Here

	((CButton*  )GetDlgItem(IDC_PREFERENCES_BUTTON       ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_HELP_BUTTON              ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_MAINMENU_BUTTON          ))->EnableWindow(operation);
	
	//((CButton*  )GetDlgItem(IDC_ADVANCED_BUTTON          ))->EnableWindow(operation);

	((CButton*  )GetDlgItem(IDC_GBFILENAMEBROWSE_BUTTON  ))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_GBFILENAME_EDIT          ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_STATICRAMBROWSE_BUTTON   ))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_STATICRAMFILENAME_EDIT   ))->EnableWindow(operation);

	//((CButton*  )GetDlgItem(IDC_VERIFYNONE_CHECK        ))->EnableWindow(operation);
	//((CButton*  )GetDlgItem(IDC_VERIFY_CHECK            ))->EnableWindow(operation);
	//((CButton*  )GetDlgItem(IDC_VERIFYX2_CHECK          ))->EnableWindow(operation);
	
	((CButton*  )GetDlgItem(IDC_ANALYZE_BUTTON         ))->EnableWindow(operation || m_Analyzing);
	((CButton*  )GetDlgItem(IDC_TESTSTATICRAM_BUTTON   ))->EnableWindow(operation || m_TestingStaticRAM);
	((CButton*  )GetDlgItem(IDC_CLEARSTATICRAM_BUTTON  ))->EnableWindow(operation || m_ClearingStaticRAM);
	
	GetDlgItemText(IDC_GBFILENAME_EDIT, m_buffer);
	((CButton*  )GetDlgItem(IDC_SAVE_BUTTON            ))->
		EnableWindow((operation || m_Saving           ) && !m_buffer.IsEmpty());
	
	GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_buffer);

	((CButton*  )GetDlgItem(IDC_SAVESTATICRAM_BUTTON   ))->
		EnableWindow((operation || m_SavingStaticRAM   ) && !m_buffer.IsEmpty());
	
	((CButton*  )GetDlgItem(IDC_RESTORESTATICRAM_BUTTON))->
		EnableWindow((operation || m_RestoringStaticRAM) && !m_buffer.IsEmpty());
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg message handlers

BOOL CGameboyDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_warnings)
	{
	   if (MessageBox(_T("Before dumping a Gameboy cartridge,\nplease attach the Gameboy extension!\n\nDo you wish to continue?"), 
	      _T("IO-56 Gameboy Warning!"), MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnOK();
		  return TRUE;
	   }
	}

	m_Advanced 		=	m_Analyzing 		=	m_Saving =
	m_TestingStaticRAM 	=  	m_ClearingStaticRAM 	= 	m_SavingStaticRAM = 
	m_RestoringStaticRAM	= FALSE;

	dwExitCode = 0;
	fp = NULL;

	gb_header[0] = NULL;
	
	UpdateDialog();

	return TRUE;  
}

void CGameboyDlg::OnCancel() 
{
	if (!m_Saving && !m_Analyzing && !m_TestingStaticRAM &&
		!m_ClearingStaticRAM  && !m_RestoringStaticRAM)	
		CDialog::OnCancel();
	else
		::Beep((DWORD)-1, (DWORD)-1);
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Command Button message handlers

void CGameboyDlg::OnSaveButton() 
{
	if (m_Saving)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 2);
		return;
	}

    m_Saving = TRUE;	
	
	UpdateDialog();

	pThread = AfxBeginThread(GBSaveThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}

void CGameboyDlg::OnAnalyzeButton() 
{
	if (m_Analyzing)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 1);
		return;
	}
	
	m_Analyzing = TRUE;  
	   
	UpdateDialog();
	 
	pThread = AfxBeginThread(GBAnalyzeThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}

void CGameboyDlg::OnAdvancedButton() 
{
	CRect EditBoxRect;
	
	m_Advanced = !m_Advanced;

	((CEdit *)GetDlgItem(IDC_GBSTATISTICS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_GBSTATISTICS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	((CEdit *)GetDlgItem(IDC_GBSTATUS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_GBSTATUS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	AddToEditBox(IDC_GBSTATUS_EDIT, _T(""), this);

	UpdateDialog();
}

void CGameboyDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;

	dlg.DoModal();	
}

void CGameboyDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUGAMEBOY);
}

BOOL CGameboyDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

void CGameboyDlg::OnMainmenuButton() 
{
	CDialog::OnOK();	
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Static RAM Button message handlers

void CGameboyDlg::OnTestStaticRAMButton() 
{
	if (m_TestingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 3);
		return;
	}

	if (m_warnings)
	   if (MessageBox(_T("Testing a Gameboy cartridge's Static\nRAM, will also erase the Static RAM!\n\nDo you wish to continue?"), 
	         _T("IO-56 Gameboy Warning!"), MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	
	m_TestingStaticRAM = TRUE;
	   
	UpdateDialog();
	   
	pThread = AfxBeginThread(GBTestStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();	
}

void CGameboyDlg::OnClearStaticRAMButton() 
{
	if (m_ClearingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 4);
		return;
	}
	
	if (m_warnings)
	   if (MessageBox(_T("Clearing a Gameboy cartridge's\nStatic RAM cannot be undone.\n\nDo you wish to continue?"), 
	         _T("IO-56 Gameboy Warning!"), MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	
	m_ClearingStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(GBClearStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();		
}

void CGameboyDlg::OnSaveStaticRAMButton() 
{
	if (m_SavingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 5);
		return;
	}
	
	m_SavingStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(GBSaveStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, 					CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();			
}

void CGameboyDlg::OnRestoreStaticRAMButton() 
{
	if (m_RestoringStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 6);
		return;
	}
	
 	if (m_warnings)
	   if (MessageBox(_T("Restoring a Gameboy cartridge's Static\nRAM will overwrite its current Static RAM!\n\nDo you wish to continue?"), 
	         _T("IO-56 Gameboy Warning!"), MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	
	m_RestoringStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(GBRestoreStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, 				CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();			
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg BROWSE Button message handlers

void CGameboyDlg::OnGBFilenameBrowseButton() 
{
	BrowseForFile(IDC_GBFILENAME_EDIT,
		_T("GBCart"), _T("gb"), _T("Gameboy Cartridge"),
		_T("Enter Gameboy Cartridge Image Filename"), this);
	
	UpdateDialog();
}

void CGameboyDlg::OnStaticRAMBrowseButton() 
{	
	BrowseForFile(IDC_STATICRAMFILENAME_EDIT,
		_T("GBSRAM"), _T("grm"), _T("Gameboy Static RAM"),
		_T("Enter Gameboy Static RAM Image Filename"), this);
	
	UpdateDialog();
}

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg Advanced Button message handlers

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg IO-56 GB.H Routines

inline int CGameboyDlg::gb_read_byte(register unsigned int addr)
{
	OUTPORT(A_8255_PB, (addr>>8)&0xFF);
	OUTPORT(A_8255_PA, addr&0xFF);
	return INPORT(A_8255_PC);
}

inline void CGameboyDlg::gb_write_byte(register int val, register unsigned int addr)
{
	GB_IDLE;
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_out|PCh_out);
	OUTPORT(A_8255_PC, val);
	OUTPORT(A_8255_PB, (addr>>8)&0xFF);
	OUTPORT(A_8255_PA, addr&0xFF);
	OUTPORT(B_8255_PROG, CLR_PC(GB_MREQ));
	OUTPORT(B_8255_PROG, CLR_PC(GB_WR));
	OUTPORT(B_8255_PROG, SET_PC(GB_WR));
	OUTPORT(B_8255_PROG, SET_PC(GB_MREQ));
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_in|PCh_in);
	GB_RD_ROM;
}

inline void CGameboyDlg::gb_write_bksw(register int val, register unsigned int addr)
{
	GB_IDLE;
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_out|PCh_out);
	OUTPORT(A_8255_PC, val);
	OUTPORT(A_8255_PB, (addr>>8)&0xFF);
	OUTPORT(A_8255_PA, addr&0xFF);
	OUTPORT(B_8255_PROG, CLR_PC(GB_WR));
	OUTPORT(B_8255_PROG, SET_PC(GB_WR));
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_in|PCh_in);
	GB_RD_ROM;
}

void CGameboyDlg::gb_switch_init()
{
	/*
	 * It seems that the bank-switch IC requires to be written the value
	 * 0x0A at address 0x0000 before being usable...
	 */
	gb_write_bksw(0x0A, 0x0000);
}

void CGameboyDlg::gb_switch_bank(int bank, int type)
{
	GB_IDLE;
	if(type == GB_ROM)
		gb_write_bksw(bank, 0x2100);
	else if(type == GB_SRAM)
		gb_write_bksw(bank, 0x4000);
}

void CGameboyDlg::gb_read_header()
{
	unsigned int addr;

	GB_RD_ROM;
	if(gb_header != NULL)
		return;

	//gb_header = (unsigned char *)malloc(0x50 * sizeof(unsigned char));

	for(addr = 0x0100; addr < 0x0150; addr++)
		gb_header[addr-0x0100] = gb_read_byte(addr);

	gb_header[addr-0x100] = 0;
}

void CGameboyDlg::gb_init()
{	
	OUTPORT(B_8255_PROG, 0x80|PA_in|PB_in|PCl_out|PCh_out);
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_in|PCh_in);
	GB_IDLE;
}

void CGameboyDlg::gb_analyze()
{
	gb_init();

	gb_read_header();

	m_buffer.Format(_T("Game name:\r\n%s\r\n\r\n"), &gb_header[0x34]);
	AddToEditBox(IDC_GBSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format(_T("Cartridge type: %d\r\n(%s)\r\n\r\n"), gb_header[0x47], 					gb_type[gb_header[0x47]]);
	AddToEditBox(IDC_GBSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format(_T("ROM size: %d (%d kB)\r\n"), gb_header[0x48], gb_rom[gb_header[0x48]]);
	AddToEditBox(IDC_GBSTATISTICS_EDIT, m_buffer, this);

	if(gb_sram[gb_header[0x49]] == GB_MBC2)
	{
		m_buffer.Format(_T("RAM size: 256 B\r\n"));
		AddToEditBox(IDC_GBSTATISTICS_EDIT, m_buffer, this);
	}
	else
	{
		m_buffer.Format(_T("RAM size: %d (%d kB)\r\n"), gb_header[0x49], gb_ram[gb_header[0x49]]);
		AddToEditBox(IDC_GBSTATISTICS_EDIT, m_buffer, this);
	}
}

void CGameboyDlg::gb_save(FILE *fp)
{
	int bank, nbbank;
	int sizekB;
	unsigned char val;
	unsigned int addr, min, max;
	unsigned int chk, checksum;

	gb_analyze();

	sizekB = gb_rom[gb_header[0x48]];

	/* One bank is 16kB */
	nbbank = sizekB / 16;
	chk = 0;

	for(bank = 0; bank < nbbank; bank++) {
		m_buffer.Format(_T("Reading bank %d\r\n"), bank);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

		gb_switch_bank(bank, GB_ROM);
		min = (bank ? 0x4000 : 0x0000);
		max = min + 0x4000;
		for(addr = min; addr < max; addr++) {
			if(addr % 0x100 == 0) {
				AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
				//fllush(stdout);
			}
			val = gb_read_byte(addr);
			
			if (fputc(val, fp) == EOF)
			{
			   GetDlgItemText(IDC_GBFILENAME_EDIT, m_filename);
			   m_buffer.Format(_T("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again."), m_filename); 
		       	   MessageBox(m_buffer,_T("IO-56 Gameboy File Error!"), MB_ICONSTOP | MB_OK);

			   SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
			}
			
			chk += val;
		}
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);
	}
	chk -= gb_header[0x4E];
	chk -= gb_header[0x4F];
	chk &= 0xFFFF;
	checksum = ((unsigned int)gb_header[0x4E] << 8) + gb_header[0x4F];;
	if(chk == checksum)
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("Checksum OK!\r\n"), this);
	else
	{
		m_buffer.Format(_T("\r\nWarning: checksum is wrong (waiting for %X, got %X)\r\n"), 				checksum, chk);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);
	}

}

void CGameboyDlg::gb_backup(FILE *fp)
{
	int bank, nbbank, banksize;
	int type, sizekB;
	unsigned int addr, max;

	gb_analyze();

	type = gb_sram[gb_header[0x47]];
	sizekB = gb_ram[gb_header[0x49]];

	if(type == GB_MBC1) {
		/* One bank is 8kB */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else if(type == GB_MBC2) {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	} else {
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("No save-RAM!\r\n"), this);
		return;
	}
	max = 0xA000 + (banksize<<8);

	/* Initialize the bank-switch IC */
	gb_switch_init();
	for(bank = 0; bank < nbbank; bank++) {
		m_buffer.Format(_T("Reading bank %d\r\n"), bank);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);
		if(type == GB_MBC1) {
			gb_switch_bank(bank, GB_SRAM);
		}
		for(addr = 0xA000; addr < max; addr++) {
			if(addr % 0x100 == 0) {
				AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
				//fflush(stdout);
			}

			if (fputc(gb_read_byte(addr), fp) == EOF)
			{
			   GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_filename);
			   m_buffer.Format(_T("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again."), m_filename); 
			   MessageBox(m_buffer,_T("IO-56 Gameboy Static RAM File Error!"), MB_ICONSTOP | 					MB_OK);

		       SendMessage(FINISHEDTHREADMESSAGE, 1, 5L);
		    }

		}
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);
	}
}

void CGameboyDlg::gb_restore(FILE *fp)
{
	int bank, nbbank, banksize;
	int type, sizekB;
	unsigned char val;
	unsigned int addr, max;

	gb_analyze();

	type = gb_sram[gb_header[0x47]];
	sizekB = gb_ram[gb_header[0x49]];

	if(type == GB_MBC1) {
		/* One bank is 8kB */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else if(type == GB_MBC2) {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	} else {
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("No save-RAM!\r\n"), this);
		return;
	}
	max = 0xA000 + (banksize<<8);

	/* Initialize the bank-switch IC */
	gb_switch_init();
	for(bank = 0; bank < nbbank; bank++) {
		m_buffer.Format(_T("Restoring bank %d\r\n"), bank);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

		if(type == GB_MBC1) {
			gb_switch_bank(bank, GB_SRAM);
		}
		for(addr = 0xA000; addr < max; addr++) {	
		   if(feof(fp)) {
		      m_buffer.Format(_T("Unexpected End Of File!\r\n"));
		      AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

		      GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_filename);
		      m_buffer.Format(_T("An error occurred while reading \"%s\"!\n\nPlease correct the problem and try again."), m_filename); 
		      MessageBox(m_buffer,_T("IO-56 Gameboy Static RAM File Error!"), MB_ICONSTOP | 					MB_OK);

		      SendMessage(FINISHEDTHREADMESSAGE, 1, 6L);
		   }
							
		   if(addr % 0x100 == 0) {
				AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
				//fflush(stdout);
		   }
		   val = fgetc(fp);
		   gb_write_byte(val, addr);
		}
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);
	}
}

void CGameboyDlg::gb_clear()
{
	int bank, nbbank, banksize;
	int type, sizekB;
	unsigned int addr, max;

	gb_analyze();

	type = gb_sram[gb_header[0x47]];
	sizekB = gb_ram[gb_header[0x49]];

	if(type == GB_MBC1) {
		/* One bank is 8kB */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else if(type == GB_MBC2) {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	} else {
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("No save-RAM\r\n"), this);
		return;
	}
	max = 0xA000 + (banksize<<8);

	/* Initialize the bank-switch IC */
	gb_switch_init();
	for(bank = 0; bank < nbbank; bank++) {
		m_buffer.Format(_T("Clearing bank %d\r\n"), bank);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

		if(type == GB_MBC1) {
			gb_switch_bank(bank, GB_SRAM);
		}
		for(addr = 0xA000; addr < max; addr++) {
			if(addr % 0x100 == 0) {
				AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
				//fflush(stdout);
			}
			gb_write_byte(0x00, addr);
		}
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);
	}
}

void CGameboyDlg::gb_test()
{
	int bank, nbbank, banksize;
	int type, sizekB;
	int i, test_val;
	unsigned int addr, max;

	gb_analyze();

	type = gb_sram[gb_header[0x47]];
	sizekB = gb_ram[gb_header[0x49]];

	if(type == GB_MBC1) {
		/* One bank is 8kB */
		nbbank = sizekB / 8;
		if(nbbank == 0) {
			nbbank = 1;
			banksize = sizekB << 2;
		} else
			banksize = 0x20;
	} else if(type == GB_MBC2) {
		/* SRAM is 512 * 4 bits */
		nbbank = 1;
		banksize = 0x02;
	} else {
		AddToEditBox(IDC_GBSTATUS_EDIT, _T("No save-RAM\r\n"), this);
		return;
	}
	max = 0xA000 + (banksize<<8);

	/* Initialize the bank-switch IC */
	gb_switch_init();
	for(bank = 0; bank < nbbank; bank++) {
		int j = (type == GB_MBC1 ? 0xFF : 0x0F);
		m_buffer.Format(_T("Testing bank %d\r\n"), bank);
		AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

		if(type == GB_MBC1) {
			gb_switch_bank(bank, GB_SRAM);
		}
		for(i = 0; test_patterns[i] >= 0; i++) {
			test_val = test_patterns[i] & j;
			m_buffer.Format(_T("Writing 0x%02X's\r\n"), test_val);
			AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

			for(addr = 0xA000; addr < max; addr++) {
				if(addr % 0x100 == 0) {
					AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
					//fflush(stdout);
				}
				gb_write_byte(test_val, addr);
			}
			AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);

			m_buffer.Format(_T("Verifying 0x%02X's\r\n"), test_val);
			AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);

			for(addr = 0xA000; addr < max; addr++) {
				if(addr % 0x100 == 0) {
					AddToEditBox(IDC_GBSTATUS_EDIT, _T("."), this);
					//fflush(stdout);
				}
				if((gb_read_byte(addr)|j) != test_val) {
					m_buffer.Format(_T("\r\nError at address 0x%04X\r\n"), addr);
					AddToEditBox(IDC_GBSTATUS_EDIT, m_buffer, this);
					SendMessage(FINISHEDTHREADMESSAGE, 1, 3L);
					//exit(-1);
				}
			}
			AddToEditBox(IDC_GBSTATUS_EDIT, _T("\r\n"), this);
		}
	}
	AddToEditBox(IDC_GBSTATUS_EDIT, _T("OK!\r\n"), this);
}


