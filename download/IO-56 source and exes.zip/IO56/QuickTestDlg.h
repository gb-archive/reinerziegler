// QuickTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg dialog

UINT PerformQuickTest(LPVOID pParam);

class CQuickTestDlg : public CDialog
{
// Construction
public:
	CQuickTestDlg(CWnd* pParent = NULL);   // standard constructor

	BOOL	m_Testing;

	CString m_buffer, m_summary;

	DWORD dwExitCode;
	CWinThread *pThread;

	void UpdateDialog();
	void QuickTest();

// Dialog Data
	//{{AFX_DATA(CQuickTestDlg)
	enum { IDD = IDD_QUICKTEST_DIALOG };
	CAnimateCtrl	m_CardTransfer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuickTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CQuickTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnStartButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnDebugButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnHelpButton();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	virtual void OnCancel();
	//}}AFX_MSG

	afx_msg long OnThreadFinished(WPARAM wParam, LPARAM lParam);
	afx_msg long OnThreadStarted(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
