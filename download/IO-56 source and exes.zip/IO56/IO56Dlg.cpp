// IO56Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "IO56Dlg.h"
#include "GameboyDlg.h"
#include "GamegearDlg.h"
#include "MasterSystemDlg.h"
#include "NESDlg.h"
#include "SNESDlg.h"
#include "PreferencesDlg.h"
#include "GenesisDlg.h"
#include "DebugDlg.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	((CAnimateCtrl *)GetDlgItem(IDC_GRADIUSGAME_AVI))->Open(IDR_GRADIUSGAME_AVI);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CAboutDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	
	WinHelp(IDH_WINVERMAINMENUABOUT);
	return TRUE; 
}

/////////////////////////////////////////////////////////////////////////////
// CIO56Dlg dialog

CIO56Dlg::CIO56Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIO56Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIO56Dlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIO56Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIO56Dlg)
	DDX_Control(pDX, IDC_GAMEBOY_BUTTON, m_GameboyButton);
	DDX_Control(pDX, IDC_SNES_BUTTON, m_SNESButton);
	DDX_Control(pDX, IDC_GENESIS_BUTTON, m_GenesisButton);
	DDX_Control(pDX, IDC_DEBUG_BUTTON, m_DebugButton);
	DDX_Control(pDX, IDC_GAMEGEAR_BUTTON, m_GameGearButton);
	DDX_Control(pDX, IDC_MASTERSYSTEM_BUTTON, m_MasterSystemButton);
	DDX_Control(pDX, IDC_NES_BUTTON, m_NESButton);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIO56Dlg, CDialog)
	//{{AFX_MSG_MAP(CIO56Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_DEBUG_BUTTON, OnDebugButton)
	ON_BN_CLICKED(IDC_GAMEBOY_BUTTON, OnGameboyButton)
	ON_BN_CLICKED(IDC_GAMEGEAR_BUTTON, OnGameGearButton)
	ON_BN_CLICKED(IDC_GENESIS_BUTTON, OnGenesisButton)
	ON_BN_CLICKED(IDC_NES_BUTTON, OnNESButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON, OnPreferencesButton)
	ON_BN_CLICKED(IDC_MASTERSYSTEM_BUTTON, OnMasterSystemButton)
	ON_BN_CLICKED(IDC_SNES_BUTTON, OnSNESButton)
	ON_BN_CLICKED(IDC_ABOUT_BUTTON, OnAboutButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON, OnHelpButton)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIO56Dlg message handlers

BOOL CIO56Dlg::OnInitDialog()
{
	CDialog dlg;
	
	CDialog::OnInitDialog();
	
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString strAboutMenu;
	strAboutMenu.LoadString(IDS_ABOUTBOX);
	if (!strAboutMenu.IsEmpty())
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	}

	((CAnimateCtrl *)GetDlgItem(IDC_GRADIUSGAME_AVI))->Open(IDR_GRADIUSGAME_AVI);

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	         m_NESButton.LoadBitmaps(IDB_NES_BITMAP1, IDB_NES_BITMAP2, 0 ,0);
	     m_GameboyButton.LoadBitmaps(IDB_GAMEBOY_BITMAP1, IDB_GAMEBOY_BITMAP2, 0 ,0);
	        m_SNESButton.LoadBitmaps(IDB_SNES_BITMAP1, IDB_SNES_BITMAP2, 0 ,0);
	
	m_MasterSystemButton.LoadBitmaps(IDB_MASTERSYSTEM_BITMAP1,
					   IDB_MASTERSYSTEM_BITMAP2, 0,
					   IDB_MASTERSYSTEM_BITMAP3);

	    m_GameGearButton.LoadBitmaps(IDB_GAMEGEAR_BITMAP1,
					   IDB_GAMEGEAR_BITMAP2, 0,
					   IDB_GAMEGEAR_BITMAP3);

   	     m_GenesisButton.LoadBitmaps(IDB_GENESIS_BITMAP1,
					   IDB_GENESIS_BITMAP2, 0,
					   IDB_GENESIS_BITMAP3);

	       m_DebugButton.LoadBitmaps(IDB_DEBUG_BITMAP1, IDB_DEBUG_BITMAP2, 0 ,0);

	    m_GameGearButton.EnableWindow(FALSE);
	     m_GenesisButton.EnableWindow(FALSE);
	m_MasterSystemButton.EnableWindow(FALSE);

	m_cardaddress  = AfxGetApp()->GetProfileInt("Preferences", "CardAddress",  0);
	m_pulsatedelay = AfxGetApp()->GetProfileInt("Preferences", "PulsateDelay", 0);
	m_warnings     = AfxGetApp()->GetProfileInt("Preferences", "Warnings",  1);
	
	dlg.Create(IDD_IO56TITLE_DIALOG, NULL);
	CWnd *fgWnd = GetForegroundWindow();
	
	for (int loop = 1; loop < 30; loop++)
	{
		::SetForegroundWindow(*fgWnd);
		dlg.UpdateWindow();
	
		Sleep(50);
	}

	dlg.DestroyWindow();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CIO56Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CIO56Dlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIO56Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIO56Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//---> Debug
void CIO56Dlg::OnDebugButton() 
{
	CDebugDlg dlg;
	dlg.DoModal();
}

//---> Preferences
void CIO56Dlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;
	dlg.DoModal();
}


//---> Super Nintendo
void CIO56Dlg::OnSNESButton() 
{
	CSNESDlg dlg;
	dlg.DoModal();
}

//---> Gameboy
void CIO56Dlg::OnGameboyButton() 
{
	CGameboyDlg dlg;
	dlg.DoModal();	
}

//---> Nintendo Entertainment System
void CIO56Dlg::OnNESButton() 
{
	CNESDlg dlg;
	dlg.DoModal();
}


//---> Sega Genesis
void CIO56Dlg::OnGenesisButton() 
{
	CGenesisDlg dlg;
	dlg.DoModal();
}

//---> Sega GameGear
void CIO56Dlg::OnGameGearButton() 
{
	CGameGearDlg dlg;
	dlg.DoModal();
}

//---> Sega Master System
void CIO56Dlg::OnMasterSystemButton() 
{
	CMasterSystemDlg dlg;
	dlg.DoModal();
}

void CIO56Dlg::OnAboutButton() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}

void CIO56Dlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENU);
}

BOOL CIO56Dlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}


