// DebugTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDebugTestDlg dialog

class CDebugTestDlg : public CDialog
{
// Construction
public:
	CDebugTestDlg(CWnd* pParent = NULL);   // standard constructor

	CIO568255Ctrl ChipACtrl;
	CIO568255Ctrl ChipBCtrl;
	CIO56OutputBufferCtrl OutputBufferCtrl;

	int m_nCurrentTest, m_value;
	CString m_buffer;


// Dialog Data
	//{{AFX_DATA(CDebugTestDlg)
	enum { IDD = IDD_DEBUGTEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDebugTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDebugTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBackButton();
	afx_msg void OnNextButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnDebugButton();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnHelpButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
