// DebugDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg dialog

#include "IO568255Ctrl.h"
#include "IO56OutputBufferCtrl.h"

class CDebugDlg : public CDialog
{
// Construction
public:
	CDebugDlg(CWnd* pParent = NULL);   // standard constructor
	
	CString m_buffer;

	CIO568255Ctrl ChipACtrl;
	CIO568255Ctrl ChipBCtrl;

	CIO56OutputBufferCtrl OutputBufferCtrl;

	void PulseCard();

// Dialog Data
	//{{AFX_DATA(CDebugDlg)
	enum { IDD = IDD_DEBUG_DIALOG };
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDebugDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDebugDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPreferencesButton();
	afx_msg void OnResetButton();
	afx_msg void OnPulseButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnDebugTestButton();
	afx_msg void OnQuicktestButton();
	afx_msg void OnDoubleclickedPulseButton();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnHelpButton();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()

	
};
