// IO568255Ctrl.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "IO568255Ctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIO568255Ctrl dialog

CIO568255Ctrl::CIO568255Ctrl(CWnd* pParent /*=NULL*/)
	: CDialog(CIO568255Ctrl::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIO568255Ctrl)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CIO568255Ctrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIO568255Ctrl)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIO568255Ctrl, CDialog)
	//{{AFX_MSG_MAP(CIO568255Ctrl)
	//}}AFX_MSG_MAP

	ON_BN_CLICKED(IDC_AIN_CHECK,   InOutChanged)
	ON_BN_CLICKED(IDC_AOUT_CHECK,  InOutChanged) 
	ON_BN_CLICKED(IDC_BIN_CHECK,   InOutChanged) 
	ON_BN_CLICKED(IDC_BOUT_CHECK,  InOutChanged) 
	ON_BN_CLICKED(IDC_CHIN_CHECK,  InOutChanged) 
	ON_BN_CLICKED(IDC_CHOUT_CHECK, InOutChanged) 
	ON_BN_CLICKED(IDC_CLIN_CHECK,  InOutChanged) 
	ON_BN_CLICKED(IDC_CLOUT_CHECK, InOutChanged) 

	ON_EN_CHANGE(IDC_A7_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_A6_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_A5_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_A4_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_A3_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_A2_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_A1_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_A0_EDIT, BINChanged) 

	ON_EN_CHANGE(IDC_B7_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_B6_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_B5_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_B4_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_B3_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_B2_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_B1_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_B0_EDIT, BINChanged) 
	
	ON_EN_CHANGE(IDC_C7_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_C6_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_C5_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_C4_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_C3_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_C2_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_C1_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_C0_EDIT, BINChanged) 

	ON_EN_CHANGE(IDC_CH7_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_CH6_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_CH5_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_CH4_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_CL3_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_CL2_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_CL1_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_CL0_EDIT, BINChanged) 

	ON_EN_KILLFOCUS(IDC_A7_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_A6_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_A5_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_A4_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_A3_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_A2_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_A1_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_A0_EDIT, BINLostFocus) 

	ON_EN_KILLFOCUS(IDC_B7_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_B6_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_B5_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_B4_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_B3_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_B2_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_B1_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_B0_EDIT, BINLostFocus) 
	
	ON_EN_KILLFOCUS(IDC_C7_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_C6_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_C5_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_C4_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_C3_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_C2_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_C1_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_C0_EDIT, BINLostFocus) 

	ON_EN_KILLFOCUS(IDC_CH7_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_CH6_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_CH5_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_CH4_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_CL3_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_CL2_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_CL1_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_CL0_EDIT, BINLostFocus) 
	
	ON_EN_CHANGE(IDC_ADEC_EDIT, DECChanged) 
	ON_EN_CHANGE(IDC_BDEC_EDIT, DECChanged)
	ON_EN_CHANGE(IDC_CDEC_EDIT, DECChanged) 
	ON_EN_CHANGE(IDC_CHDEC_EDIT, DECChanged)
	ON_EN_CHANGE(IDC_CLDEC_EDIT, DECChanged)

	ON_EN_KILLFOCUS(IDC_ADEC_EDIT, DECLostFocus) 
	ON_EN_KILLFOCUS(IDC_BDEC_EDIT, DECLostFocus)
	ON_EN_KILLFOCUS(IDC_CDEC_EDIT, DECLostFocus) 
	ON_EN_KILLFOCUS(IDC_CHDEC_EDIT, DECLostFocus)
	ON_EN_KILLFOCUS(IDC_CLDEC_EDIT, DECLostFocus)

	ON_EN_CHANGE(IDC_AHEX_EDIT, HEXChanged) 
	ON_EN_CHANGE(IDC_BHEX_EDIT, HEXChanged)
	ON_EN_CHANGE(IDC_CHEX_EDIT, HEXChanged) 
	ON_EN_CHANGE(IDC_CHHEX_EDIT, HEXChanged)
	ON_EN_CHANGE(IDC_CLHEX_EDIT, HEXChanged)
	
	ON_EN_KILLFOCUS(IDC_AHEX_EDIT, HEXLostFocus) 
	ON_EN_KILLFOCUS(IDC_BHEX_EDIT, HEXLostFocus)
	ON_EN_KILLFOCUS(IDC_CHEX_EDIT, HEXLostFocus) 
	ON_EN_KILLFOCUS(IDC_CHHEX_EDIT, HEXLostFocus)
	ON_EN_KILLFOCUS(IDC_CLHEX_EDIT, HEXLostFocus)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIO568255Ctrl message handlers

BOOL CIO568255Ctrl::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_buffer.Format("(%d .. %d)", m_PinsStart,      m_PinsStart +  7);
	SetDlgItemText(IDC_PINSA_STATIC, m_buffer);

	m_buffer.Format("(%d .. %d)", m_PinsStart +  8, m_PinsStart + 15);
	SetDlgItemText(IDC_PINSB_STATIC, m_buffer);

	m_buffer.Format("(%d .. %d)", m_PinsStart + 16, m_PinsStart + 23);
	SetDlgItemText(IDC_PINSC_STATIC, m_buffer);

	m_buffer.Format("(%d .. %d)", m_PinsStart + 16, m_PinsStart + 19);
	SetDlgItemText(IDC_PINSCH_STATIC, m_buffer);

	m_buffer.Format("(%d .. %d)", m_PinsStart + 20, m_PinsStart + 23);
	SetDlgItemText(IDC_PINSCL_STATIC, m_buffer);

	SetDlgItemText(IDC_8255_STATIC, m_WindowTitle);

	ResetControl();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CIO568255Ctrl::GetValues(int& A, int& B, int& C, int& CH, int& CL)
{
	A = GetDlgItemInt(IDC_ADEC_EDIT, NULL, FALSE);
	B = GetDlgItemInt(IDC_BDEC_EDIT, NULL, FALSE);
	C = GetDlgItemInt(IDC_CDEC_EDIT, NULL, FALSE);

	CH = GetDlgItemInt(IDC_CHDEC_EDIT, NULL, FALSE);
	CL = GetDlgItemInt(IDC_CLDEC_EDIT, NULL, FALSE);
}

void CIO568255Ctrl::SetValues(int A, int B, int C, int CH, int CL)
{
	SetDlgItemInt(IDC_ADEC_EDIT, A, FALSE);
	SetDlgItemInt(IDC_BDEC_EDIT, B, FALSE);
	SetDlgItemInt(IDC_CDEC_EDIT, C, FALSE);

	SetDlgItemInt(IDC_CHDEC_EDIT, CH, FALSE);
	SetDlgItemInt(IDC_CLDEC_EDIT, CL, FALSE);

	ConvertDECToHEX();
	ConvertDECToBIN();
}

void CIO568255Ctrl::GetPorts(int& A, int& B, int& C, int& CH, int& CL)
{
	A = IsDlgButtonChecked(IDC_AIN_CHECK);
	B = IsDlgButtonChecked(IDC_BIN_CHECK);

	CH = IsDlgButtonChecked(IDC_CHIN_CHECK);
	CL = IsDlgButtonChecked(IDC_CLIN_CHECK);
	
	C = (IsDlgButtonChecked(IDC_CHIN_CHECK) && IsDlgButtonChecked(IDC_CLIN_CHECK)); 
}

void CIO568255Ctrl::SetPorts(int A, int B, int C, int CH, int CL)
{
	CheckDlgButton(IDC_AIN_CHECK, A);
	CheckDlgButton(IDC_BIN_CHECK, B);
	CheckDlgButton(IDC_CHIN_CHECK, CH);
	CheckDlgButton(IDC_CLIN_CHECK, CL);

	CheckDlgButton(IDC_AOUT_CHECK, !A);
	CheckDlgButton(IDC_BOUT_CHECK, !B);
	CheckDlgButton(IDC_CHOUT_CHECK, !CH);
	CheckDlgButton(IDC_CLOUT_CHECK, !CL);

	SetValues(0, 0, 0, 0, 0);
}

void CIO568255Ctrl::ResetControl()
{
	m_ReadOnly = FALSE;

	SetPorts(1,1,1,1,1);
	
	UpdateDialog();

	ConvertDECToBIN();
	ConvertDECToHEX();
}

void CIO568255Ctrl::InOutChanged()
{
	CWnd* focusedcontrol;
	int controlID;
	
	focusedcontrol = GetFocus();
	controlID = focusedcontrol -> GetDlgCtrlID();

	UpdateDialog();

	switch(controlID)
	{
		case IDC_CLIN_CHECK:
		case IDC_CLOUT_CHECK:
		case IDC_CHIN_CHECK:
		case IDC_CHOUT_CHECK:
		
			SetDlgItemInt(IDC_CDEC_EDIT, 0, FALSE);
			SetDlgItemInt(IDC_CHDEC_EDIT, 0, FALSE);
			SetDlgItemInt(IDC_CLDEC_EDIT, 0, FALSE);

			break;

		case IDC_AIN_CHECK:
		case IDC_AOUT_CHECK:

			SetDlgItemInt(IDC_ADEC_EDIT, 0, FALSE);

			break;

		default:

			SetDlgItemInt(IDC_BDEC_EDIT, 0, FALSE);
	}

	ConvertDECToBIN();
	ConvertDECToHEX();
}
   
void CIO568255Ctrl::UpdateDialog()
{
   BOOL PortSame;
   int ShoworHide;
   BOOL ReadOnly;
   
   PortSame = (IsDlgButtonChecked(IDC_CHIN_CHECK) == IsDlgButtonChecked(IDC_CLIN_CHECK));

   ShoworHide = (PortSame ? SW_SHOW : SW_HIDE);
	
   ((CStatic *)GetDlgItem(IDC_PINSC_STATIC ))->ShowWindow(ShoworHide);
   ((CStatic *)GetDlgItem(IDC_C_STATIC     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C7_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C6_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C5_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C4_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C3_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C2_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C1_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_C0_EDIT      ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CDEC_EDIT    ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CHEX_EDIT    ))->ShowWindow(ShoworHide);

   ReadOnly = IsDlgButtonChecked(IDC_CHIN_CHECK);

   ((CEdit   *)GetDlgItem(IDC_C7_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C6_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C5_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C4_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C3_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C2_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C1_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_C0_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CDEC_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CHEX_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);

   ((CEdit   *)GetDlgItem(IDC_CH7_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CH6_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CH5_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CH4_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CHDEC_EDIT   ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CHHEX_EDIT   ))->SetReadOnly(m_ReadOnly || ReadOnly);

   ReadOnly = IsDlgButtonChecked(IDC_CLIN_CHECK);

   ((CEdit   *)GetDlgItem(IDC_CL3_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CL2_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CL1_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CL0_EDIT     ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CLDEC_EDIT   ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_CLHEX_EDIT   ))->SetReadOnly(m_ReadOnly || ReadOnly);

   ShoworHide = (PortSame ? SW_HIDE : SW_SHOW);
   
   ((CStatic *)GetDlgItem(IDC_PINSCH_STATIC))->ShowWindow(ShoworHide);
   ((CStatic *)GetDlgItem(IDC_CH_STATIC    ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CH7_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CH6_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CH5_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CH4_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CHDEC_EDIT   ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CHHEX_EDIT   ))->ShowWindow(ShoworHide);

   ((CStatic *)GetDlgItem(IDC_PINSCL_STATIC))->ShowWindow(ShoworHide);
   ((CStatic *)GetDlgItem(IDC_CL_STATIC    ))->ShowWindow(ShoworHide);  
   ((CEdit   *)GetDlgItem(IDC_CL3_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CL2_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CL1_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CL0_EDIT     ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CLDEC_EDIT   ))->ShowWindow(ShoworHide);
   ((CEdit   *)GetDlgItem(IDC_CLHEX_EDIT   ))->ShowWindow(ShoworHide);

   ReadOnly = IsDlgButtonChecked(IDC_AIN_CHECK);

   ((CEdit   *)GetDlgItem(IDC_A7_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A6_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A5_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A4_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A3_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A2_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A1_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_A0_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_ADEC_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_AHEX_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);


   ReadOnly = IsDlgButtonChecked(IDC_BIN_CHECK);

   ((CEdit   *)GetDlgItem(IDC_B7_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B6_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B5_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B4_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B3_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B2_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B1_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_B0_EDIT      ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_BDEC_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_BHEX_EDIT    ))->SetReadOnly(m_ReadOnly || ReadOnly);

   ((CButton *)GetDlgItem(IDC_AIN_CHECK    ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_AOUT_CHECK   ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_BIN_CHECK    ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_BOUT_CHECK   ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_CHIN_CHECK   ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_CHOUT_CHECK  ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_CLIN_CHECK   ))->EnableWindow(!m_ReadOnly);
   ((CButton *)GetDlgItem(IDC_CLOUT_CHECK  ))->EnableWindow(!m_ReadOnly);
}

void CIO568255Ctrl::ConvertDECToBIN()
{
   int value;

   value = GetDlgItemInt(IDC_ADEC_EDIT, 0, FALSE);
   SetDlgItemInt(IDC_A7_EDIT, (value & 0x80) >> 7, FALSE);
   SetDlgItemInt(IDC_A6_EDIT, (value & 0x40) >> 6, FALSE);
   SetDlgItemInt(IDC_A5_EDIT, (value & 0x20) >> 5, FALSE);
   SetDlgItemInt(IDC_A4_EDIT, (value & 0x10) >> 4, FALSE);
   SetDlgItemInt(IDC_A3_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_A2_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_A1_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_A0_EDIT, (value & 0x01),      FALSE);

   value = GetDlgItemInt(IDC_BDEC_EDIT, 0, FALSE);
   SetDlgItemInt(IDC_B7_EDIT, (value & 0x80) >> 7, FALSE);
   SetDlgItemInt(IDC_B6_EDIT, (value & 0x40) >> 6, FALSE);
   SetDlgItemInt(IDC_B5_EDIT, (value & 0x20) >> 5, FALSE);
   SetDlgItemInt(IDC_B4_EDIT, (value & 0x10) >> 4, FALSE);
   SetDlgItemInt(IDC_B3_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_B2_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_B1_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_B0_EDIT, (value & 0x01),      FALSE);

   value = GetDlgItemInt(IDC_CDEC_EDIT, 0, FALSE);
   SetDlgItemInt(IDC_C7_EDIT, (value & 0x80) >> 7, FALSE);
   SetDlgItemInt(IDC_C6_EDIT, (value & 0x40) >> 6, FALSE);
   SetDlgItemInt(IDC_C5_EDIT, (value & 0x20) >> 5, FALSE);
   SetDlgItemInt(IDC_C4_EDIT, (value & 0x10) >> 4, FALSE);
   SetDlgItemInt(IDC_C3_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_C2_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_C1_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_C0_EDIT, (value & 0x01),      FALSE);

   value = GetDlgItemInt(IDC_CHDEC_EDIT, 0, FALSE);
   SetDlgItemInt(IDC_CH7_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_CH6_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_CH5_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_CH4_EDIT, (value & 0x01)     , FALSE);

   value = GetDlgItemInt(IDC_CLDEC_EDIT, 0, FALSE);
   SetDlgItemInt(IDC_CL3_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_CL2_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_CL1_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_CL0_EDIT, (value & 0x01)     , FALSE);
}

void CIO568255Ctrl::ConvertDECToHEX()
{
	m_buffer.Format("%02x", GetDlgItemInt(IDC_ADEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_AHEX_EDIT, m_buffer);

	m_buffer.Format("%02x", GetDlgItemInt(IDC_BDEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_BHEX_EDIT, m_buffer);

	m_buffer.Format("%02x", GetDlgItemInt(IDC_CHDEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_CHHEX_EDIT, m_buffer);

	m_buffer.Format("%02x", GetDlgItemInt(IDC_CLDEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_CLHEX_EDIT, m_buffer);

	m_buffer.Format("%02x", GetDlgItemInt(IDC_CDEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_CHEX_EDIT, m_buffer);
}

void CIO568255Ctrl::ConvertHEXToDEC()
{
	int value;

	GetDlgItemText(IDC_AHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_ADEC_EDIT, value);

	GetDlgItemText(IDC_BHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_BDEC_EDIT, value);

	GetDlgItemText(IDC_CHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_CDEC_EDIT, value);

	GetDlgItemText(IDC_CHHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_CHDEC_EDIT, value);

	GetDlgItemText(IDC_CLHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_CLDEC_EDIT, value);
}

void CIO568255Ctrl::ConvertBINToDEC()
{
	SetDlgItemInt( IDC_ADEC_EDIT, ( GetDlgItemInt(IDC_A7_EDIT, NULL, FALSE) * 0x80 +
		GetDlgItemInt(IDC_A6_EDIT, NULL, FALSE) * 0x40 +
		GetDlgItemInt(IDC_A5_EDIT, NULL, FALSE) * 0x20 +
		GetDlgItemInt(IDC_A4_EDIT, NULL, FALSE) * 0x10 +
		GetDlgItemInt(IDC_A3_EDIT, NULL, FALSE) * 0x08 +
		GetDlgItemInt(IDC_A2_EDIT, NULL, FALSE) * 0x04 +
		GetDlgItemInt(IDC_A1_EDIT, NULL, FALSE) * 0x02 +
		GetDlgItemInt(IDC_A0_EDIT, NULL, FALSE) ) , FALSE );

	SetDlgItemInt( IDC_BDEC_EDIT, ( GetDlgItemInt(IDC_B7_EDIT, NULL, FALSE) * 0x80 +
		GetDlgItemInt(IDC_B6_EDIT, NULL, FALSE) * 0x40 +
		GetDlgItemInt(IDC_B5_EDIT, NULL, FALSE) * 0x20 +
		GetDlgItemInt(IDC_B4_EDIT, NULL, FALSE) * 0x10 +
		GetDlgItemInt(IDC_B3_EDIT, NULL, FALSE) * 0x08 +
		GetDlgItemInt(IDC_B2_EDIT, NULL, FALSE) * 0x04 +
		GetDlgItemInt(IDC_B1_EDIT, NULL, FALSE) * 0x02 +
		GetDlgItemInt(IDC_B0_EDIT, NULL, FALSE) ) , FALSE);

	SetDlgItemInt( IDC_CDEC_EDIT, ( GetDlgItemInt(IDC_C7_EDIT, NULL, FALSE) * 0x80 +
		GetDlgItemInt(IDC_C6_EDIT, NULL, FALSE) * 0x40 +
		GetDlgItemInt(IDC_C5_EDIT, NULL, FALSE) * 0x20 +
		GetDlgItemInt(IDC_C4_EDIT, NULL, FALSE) * 0x10 +
		GetDlgItemInt(IDC_C3_EDIT, NULL, FALSE) * 0x08 +
		GetDlgItemInt(IDC_C2_EDIT, NULL, FALSE) * 0x04 +
		GetDlgItemInt(IDC_C1_EDIT, NULL, FALSE) * 0x02 +
		GetDlgItemInt(IDC_C0_EDIT, NULL, FALSE) ) , FALSE );

	SetDlgItemInt( IDC_CHDEC_EDIT, ( GetDlgItemInt(IDC_CH7_EDIT, NULL, FALSE) * 0x08 +
		GetDlgItemInt(IDC_CH6_EDIT, NULL, FALSE) * 0x04 +
		GetDlgItemInt(IDC_CH5_EDIT, NULL, FALSE) * 0x02 +
		GetDlgItemInt(IDC_CH4_EDIT, NULL, FALSE) ), FALSE );

	SetDlgItemInt( IDC_CLDEC_EDIT, ( GetDlgItemInt(IDC_CL3_EDIT, NULL, FALSE) * 0x08 +
		GetDlgItemInt(IDC_CL2_EDIT, NULL, FALSE) * 0x04 +
		GetDlgItemInt(IDC_CL1_EDIT, NULL, FALSE) * 0x02 +
		GetDlgItemInt(IDC_CL0_EDIT, NULL, FALSE) ), FALSE );
}

void CIO568255Ctrl::BINChanged()
{
	CWnd* focusedcontrol;
	int controlID;
	int value;

	focusedcontrol = GetFocus();
	controlID = focusedcontrol -> GetDlgCtrlID();

	GetDlgItemText(controlID, m_buffer);
	value = GetDlgItemInt(controlID, NULL, FALSE);
	value = 1 * (value != 0);

	if (!m_buffer.IsEmpty())
	{
		SetDlgItemInt(controlID, value, FALSE);
		ConvertBINToDEC();
		ConvertDECToHEX();
	}
}

void CIO568255Ctrl::DECChanged()
{
	CWnd* focusedcontrol;
	int controlID;
	int value;

	focusedcontrol = GetFocus();
	controlID = focusedcontrol -> GetDlgCtrlID();

	GetDlgItemText(controlID, m_buffer);
	value = GetDlgItemInt(controlID, NULL, FALSE);
	
	if (value > 255)
	   SetDlgItemInt(controlID, 255);
	
	if ((controlID == IDC_CHDEC_EDIT || controlID == IDC_CLDEC_EDIT) && value > 15)
	   SetDlgItemInt(controlID, 15);
			
	if (!m_buffer.IsEmpty())
	{
	
		ConvertDECToBIN();
		ConvertDECToHEX();
	}
}

void CIO568255Ctrl::HEXChanged()
{
	CWnd* focusedcontrol;
	int controlID;

	focusedcontrol = GetFocus();
	controlID = focusedcontrol -> GetDlgCtrlID();
				
	FixHexEditBox(0, controlID, 2,
		(controlID == IDC_CHHEX_EDIT || controlID == IDC_CLHEX_EDIT) ? 15 : 255,
		0x00, this);

	GetDlgItemText(controlID, m_buffer);

	if (!m_buffer.IsEmpty())
	{
		if (m_buffer.GetLength() == 2)
		{
		   ConvertHEXToDEC();
		   ConvertDECToBIN();
		}
	}
}

void CIO568255Ctrl::BINLostFocus()
{
	ConvertDECToBIN();
	ConvertDECToHEX();
}

void CIO568255Ctrl::DECLostFocus()
{
	ConvertHEXToDEC();
	ConvertDECToBIN();
}
	
void CIO568255Ctrl::HEXLostFocus()
{
	ConvertDECToHEX();
	ConvertDECToBIN();
}

void CIO568255Ctrl::OnCancel() 
{
	return;
}
