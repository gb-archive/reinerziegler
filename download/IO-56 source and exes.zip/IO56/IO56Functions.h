// IO56Functions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIO56Functions window

BOOL    CheckFileExtension(UINT, CString, CString&, CWnd*);
BOOL    BrowseForFile(UINT, CString, CString, CString, CString, CWnd*);
void    AddToEditBox(UINT, CString, CWnd*);
void    FixHexEditBox(int, UINT, int, unsigned long, unsigned long, CWnd*);
CString GetTime(void);
