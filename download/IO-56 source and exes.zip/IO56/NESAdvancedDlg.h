// NESAdvancedDlg.h : header file
//

UINT NESAdvancedSaveThread(LPVOID);

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg dialog

class CNESAdvancedDlg : public CDialog
{
// Construction
public:
	CNESAdvancedDlg(CWnd* pParent = NULL);   // standard constructor

	int m_mode;

	BOOL m_Saving, m_ProgramChecked;
	unsigned int m_value, m_length;
	unsigned long m_address;
	CString m_buffer, m_windowtext, m_filename;

	FILE *fp;
	
	DWORD        dwExitCode;
	CWinThread   *pThread;
	
	void UpdateDialog();

	void nes_advanced_write();
	void nes_advanced_read(); 
	void nes_advanced_save(FILE *fp);

// Dialog Data
	//{{AFX_DATA(CNESAdvancedDlg)
	enum { IDD = IDD_NESADVANCED_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNESAdvancedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNESAdvancedDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPreferencesButton();
	afx_msg void OnChangeFilenameEdit();
	afx_msg void OnNESAdvancedBrowseButton();
	afx_msg void OnChangeValueEdit();
	afx_msg void OnCommandButton();
	afx_msg void OnChangeAddressEdit();
	afx_msg void OnKillfocusAddressEdit();
	afx_msg void OnKillfocusValueEdit();
	afx_msg void OnHelpButton();
	virtual void OnCancel();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG

	afx_msg long OnThreadFinished(WPARAM wParam, LPARAM lParam);
	afx_msg long OnThreadStarted(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
