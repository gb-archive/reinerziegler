// MasterSystemDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "MasterSystemDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMasterSystemDlg dialog


CMasterSystemDlg::CMasterSystemDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMasterSystemDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMasterSystemDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CMasterSystemDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMasterSystemDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMasterSystemDlg, CDialog)
	//{{AFX_MSG_MAP(CMasterSystemDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMasterSystemDlg message handlers
