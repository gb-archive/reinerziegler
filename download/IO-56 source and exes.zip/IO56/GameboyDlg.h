// GameboyDlg.h : header file
//

#define GB_WR		0
#define GB_RD		1
#define GB_MREQ 	2

#define GB_IDLE	OUTPORT(B_8255_PC, 0xFF)
#define GB_RD_ROM	OUTPORT(B_8255_PROG, CLR_PC(GB_RD))

#define GB_NO_MBC	0
#define GB_MBC1	1
#define GB_MBC2	2

#define GB_NO_SRAM	0

#define GB_ROM		0
#define GB_SRAM	1

static char *gb_type[] = {
	"ROM ONLY", "ROM+MBC1", "ROM+MBC1+RAM", "ROM+MBC1+RAM+BATTERY",
	"UNKNOWN", "ROM+MBC2", "ROM+MBC2+BATTERY"
};

static int gb_rom[]  = { 32, 64, 128, 256, 512 };
static int gb_ram[]  = { 0, 2, 8, 32 };
static int gb_mbc[]  = { GB_NO_MBC, GB_MBC1, GB_MBC1, GB_MBC1, GB_MBC2, GB_MBC2, GB_MBC2 };
static int gb_sram[] = { GB_NO_SRAM, GB_NO_SRAM, GB_NO_SRAM, GB_MBC1, GB_NO_SRAM, GB_NO_SRAM, GB_MBC2 };

static unsigned char gb_header[100] = { 0 };

UINT GBAnalyzeThread(LPVOID pParam);
UINT GBSaveThread(LPVOID pParam);
UINT GBTestStaticRAMThread(LPVOID pParam);
UINT GBClearStaticRAMThread(LPVOID pParam);
UINT GBSaveStaticRAMThread(LPVOID pParam);
UINT GBRestoreStaticRAMThread(LPVOID pParam);

/////////////////////////////////////////////////////////////////////////////
// CGameboyDlg dialog

class CGameboyDlg : public CDialog
{
// Construction
public:
	CGameboyDlg(CWnd* pParent = NULL);   // standard constructor
	
	FILE *fp;
	
	inline int gb_read_byte(register unsigned int);
	inline void gb_write_byte(register int, register unsigned int);
	inline void gb_write_bksw(register int, register unsigned int);

	void gb_switch_init();
	void gb_switch_bank(int, int);
	void gb_read_header();
	void gb_init();
	void gb_analyze();
	void gb_save(FILE *fp);
	void gb_backup(FILE *fp);
	void gb_restore(FILE *fp);
	void gb_clear();
	void gb_test();

// Dialog Data
	//{{AFX_DATA(CGameboyDlg)
	enum { IDD = IDD_GAMEBOY_DIALOG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGameboyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	BOOL m_Advanced, m_Analyzing, m_Saving, m_TestingStaticRAM,
	     m_ClearingStaticRAM, m_SavingStaticRAM, m_RestoringStaticRAM;
	
	CString m_buffer, m_filename;

	DWORD        dwExitCode;
	CWinThread   *pThread;

	CString GetOperation(LPARAM lParam);
	void UpdateDialog();

	// Generated message map functions
	//{{AFX_MSG(CGameboyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSaveButton();
	afx_msg void OnAnalyzeButton();
	afx_msg void OnAdvancedButton();
	afx_msg void OnStaticRAMBrowseButton();
	afx_msg void OnGBFilenameBrowseButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnHelpButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnTestStaticRAMButton();
	afx_msg void OnClearStaticRAMButton();
	afx_msg void OnSaveStaticRAMButton();
	afx_msg void OnRestoreStaticRAMButton();
	virtual void OnCancel();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	afx_msg long OnThreadFinished(WPARAM wParam, LPARAM lParam);
	afx_msg long OnThreadStarted(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
