// IO56OutputBufferCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIO56OutputBufferCtrl dialog

class CIO56OutputBufferCtrl : public CDialog
{
// Construction
public:
	CIO56OutputBufferCtrl(CWnd* pParent = NULL);   // standard constructor

	CString m_buffer, m_WindowTitle;
	int m_PinsStart;
	
	BOOL m_ReadOnly;

	int  GetValue();
	void SetValue(int value);

	void ResetControl();
	void UpdateDialog();
	void ConvertDECToBIN();
	void ConvertDECToHEX();
	void ConvertHEXToDEC();
	void ConvertBINToDEC();

	void BINChanged();
	void DECChanged();
	void HEXChanged();
	
	void BINLostFocus();
	void DECLostFocus();
	void HEXLostFocus();

// Dialog Data
	//{{AFX_DATA(CIO56OutputBufferCtrl)
	enum { IDD = IDD_OUTPUTBUFFERCTRL_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIO56OutputBufferCtrl)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIO56OutputBufferCtrl)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()
};
