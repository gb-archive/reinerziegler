IO-56 for Windows Source Code
-----------------------------

Hello! This is the first source code (of any kind)
that I have released on the Internet. Since this
was my first attempt at Windows programming, it
is not very good and quite messy. However, over
the last 4 years, I have learned quite a bit, and
maybe someday I'll clean it up and make it more
modular.

I am releasing the source code with the hopes that
someone will modify it and make it run on Windows
2000, or possible make it dump GBA cartridges. :)

If you do plan on modifying the code, please e-mail
me at jsm174@psualum.com. I would really appreciate
it!


Disclaimer:
-----------

I am in no way held responsible for the results of
using the IO-56 hardware and this software.

This source code should not be modified in anyway
without my consent. 

Credits and thanks:
-------------------

Special thanks goes out to Pascal Felber. Without his
help and support, IO-56 for Windows would never have
made it out the door!

Also, special thanks goes out to Reiner Ziegler for
hosting the IO-56 software on his web site!


-- Jason Millard
   July 8, 2001

