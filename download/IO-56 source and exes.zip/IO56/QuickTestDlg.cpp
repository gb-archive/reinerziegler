// QuickTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "QuickTestDlg.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg dialog

CQuickTestDlg::CQuickTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQuickTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQuickTestDlg)
	//}}AFX_DATA_INIT
}

void CQuickTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQuickTestDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CQuickTestDlg, CDialog)
	//{{AFX_MSG_MAP(CQuickTestDlg)
	ON_BN_CLICKED(IDC_START_BUTTON,       OnStartButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON, OnPreferencesButton)
	ON_BN_CLICKED(IDC_DEBUG_BUTTON,       OnDebugButton)
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,    OnMainmenuButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON,        OnHelpButton)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FINISHEDTHREADMESSAGE, OnThreadFinished)
	ON_MESSAGE(STARTEDTHREADMESSAGE,  OnThreadStarted)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg Thread Message Handlers

UINT PerformQuickTest(LPVOID pParam)
{
	CQuickTestDlg *pDlg = (CQuickTestDlg *)pParam;
	
	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 0);
	pDlg->QuickTest();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 0);

	return(0);
}
/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg Thread Message Handlers

long CQuickTestDlg::OnThreadStarted(WPARAM wParam, LPARAM lParam)
{
	m_Testing = TRUE;
	UpdateDialog();

	((CEdit *)GetDlgItem(IDC_QUICKTEST_EDIT))->SetWindowText("");

	m_buffer.Format(_T("-------- Quick Test started at %s --------\r\n\r\n"), GetTime());	
	AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);

	m_summary.Empty();

	return(0L);
}

long CQuickTestDlg::OnThreadFinished(WPARAM wParam, LPARAM lParam)
{
	m_Testing = FALSE;
	UpdateDialog();

	if (wParam)
	{
		if (dwExitCode)
		   TerminateThread(pThread->m_hThread, dwExitCode);

		dwExitCode = 0;

		m_buffer.Format(_T("\r\n\r\n-------- Quick Test terminated at %s --------\r\n\r\n"), 
		   GetTime());	
	}
	else
	{
		m_buffer.Format(_T("\r\n-------- Quick Test finished at %s --------\r\n"),
		   GetTime()); 
	}

	AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		
	return (0L);
}

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg Thread Update Window Function

void CQuickTestDlg::UpdateDialog() 
{
	((CButton*)GetDlgItem(IDC_PREFERENCES_BUTTON))->EnableWindow(!m_Testing);
	((CButton*)GetDlgItem(IDC_HELP_BUTTON       ))->EnableWindow(!m_Testing);
	((CButton*)GetDlgItem(IDC_MAINMENU_BUTTON   ))->EnableWindow(!m_Testing);
	((CButton*)GetDlgItem(IDC_DEBUG_BUTTON      ))->EnableWindow(!m_Testing);	
	
	((CButton*)GetDlgItem(IDC_START_BUTTON      ))->SetWindowText(m_Testing ? "Stop" : "Start");	
}

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg message handlers

BOOL CQuickTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_warnings)
	{
	   if (MessageBox("Before performing a Quick Test,\nplease attach the Test extension!\n\nDo you wish to continue?", 
	      "IO-56 Quick Test Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnCancel();
		  return TRUE;
	   }
	}
	
	m_Testing = FALSE;

	((CAnimateCtrl *)GetDlgItem(IDC_DEBUGTESTING_AVI))->Open(IDR_DEBUGTESTING_AVI);

	AddToEditBox(IDC_QUICKTEST_EDIT,
		"---------------------------\r\nIO-56 Quick Test\r\n---------------------------\r\n\r\nAfter attaching the Test connector, click\r\nthe Start button to begin the Quick Test.\r\n\r\n", this);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CQuickTestDlg::OnCancel() 
{
	if (!m_Testing)	
		CDialog::OnCancel();
	else
		::Beep((DWORD)-1, (DWORD)-1);
}

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg Command Buttons message handlers

void CQuickTestDlg::OnStartButton() 
{
	if (m_Testing)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 0);
		return;
	}

		
	pThread = AfxBeginThread(PerformQuickTest, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();   
}

void CQuickTestDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;
	dlg.DoModal();
}

void CQuickTestDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUDEBUGSYSTEMQUICKTEST);
}

BOOL CQuickTestDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

void CQuickTestDlg::OnMainmenuButton() 
{
	OnOK();	
}
void CQuickTestDlg::OnDebugButton() 

{
	OnCancel();	
}

/////////////////////////////////////////////////////////////////////////////
// CQuickTestDlg IO-56 Test.h Routines

void CQuickTestDlg::QuickTest()
{
	//
	// Test 1
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 1...\r\n--------------------------------\r\n",this);

	OUTPORT(B_8255_PROG, 0x80 | PA_in  | PB_out | PCl_in  | PCh_in);
	OUTPORT(A_8255_PROG, 0x80 | PA_out | PB_in  | PCl_out | PCh_in);

	int i, b, errors, data;

	for (errors = 0, i=0x01; i < 0x100; i<<=1)
	{
		OUTPORT(BUFFER, i);
		data = INPORT(B_8255_PA);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this); 

		}

		::Sleep(m_pulsatedelay);
	} 

	if (errors)
		m_buffer.Format("Test 1 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
		m_buffer.Format("Test 1 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 2
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 2...\r\n--------------------------------\r\n",this);
	
	for (errors = 0, i=0x01; i < 0x100; i<<=1)
	{
		OUTPORT(B_8255_PB, i);
		data = INPORT(B_8255_PC);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}

		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 2 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 2 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 3
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 3...\r\n--------------------------------\r\n",this);

	for (errors = 0, i=0x01; i < 0x100; i<<=1)
	{
		OUTPORT(A_8255_PA, i);
		data = INPORT(A_8255_PB);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}
		
		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 3 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 3 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 4
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 4...\r\n--------------------------------\r\n",this);

	for (errors = 0, i=0x01; i < 0x10; i<<=1)
	{
		OUTPORT(A_8255_PC, i);
		data = INPORT(A_8255_PC) >> 4;
		data = TEST_REVERT_4(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}

		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 4 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 4 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 5
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 5...\r\n--------------------------------\r\n",this);

	OUTPORT(A_8255_PC, 0x00);

	for (errors = 0, i=0x01, b = 0; i < 0x10; i<<=1, b++)
	{
		OUTPORT(A_8255_PROG, SET_PC(b));
		data = INPORT(A_8255_PC) >> 4;
		data = TEST_REVERT_4(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}
		OUTPORT(A_8255_PROG, CLR_PC(b));
		
		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 5 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 5 passed!\r\n");

	m_summary += m_buffer;


	OUTPORT(B_8255_PROG, 0x80 | PA_in | PB_in  | PCl_out | PCh_out);
	OUTPORT(A_8255_PROG, 0x80 | PA_in | PB_out | PCl_in  | PCh_out);

	//
	// Test 6
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 6...\r\n--------------------------------\r\n",this);

	OUTPORT(A_8255_PC, 0x00);

	for (errors = 0, i=0x01; i < 0x100; i<<=1)
	{
		OUTPORT(B_8255_PC, i);
		data = INPORT(B_8255_PB);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}
		
		::Sleep(m_pulsatedelay);
	} 
	
	if (errors)
	   m_buffer.Format("Test 6 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 6 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 7
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 7...\r\n--------------------------------\r\n",this);

	OUTPORT(B_8255_PC, 0x00);

	for (errors = 0, i=0x01, b = 0; i < 0x100; i<<=1, b++)
	{
		OUTPORT(B_8255_PROG, SET_PC(b));
		data = INPORT(B_8255_PB);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}
		OUTPORT(B_8255_PROG, CLR_PC(b));

		::Sleep(m_pulsatedelay);
	}
	
	if (errors)
	   m_buffer.Format("Test 7 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 7 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 8
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 8...\r\n--------------------------------\r\n",this);

	for (errors = 0, i=0x01; i < 0x100; i<<=1)
	{
		OUTPORT(A_8255_PB, i);
		data = INPORT(A_8255_PA);
		data = TEST_REVERT_8(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}

		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 8 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 8 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 9
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "--------------------------------\r\nPerforming Test 9...\r\n--------------------------------\r\n",this);

	for (errors = 0, i=0x01; i < 0x10; i<<=1)
	{
		OUTPORT(A_8255_PC, i << 4);
		data = INPORT(A_8255_PC) & 0x0F;
		data = TEST_REVERT_4(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}

		::Sleep(m_pulsatedelay);
	} 

	if (errors)
	   m_buffer.Format("Test 9 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 9 passed!\r\n");

	m_summary += m_buffer;

	//
	// Test 10
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "---------------------------------\r\nPerforming Test 10...\r\n---------------------------------\r\n",this);

	OUTPORT(A_8255_PC, 0x00);

	for (errors = 0, i=0x01, b = 4; i < 0x10; i<<=1, b++)
	{
		OUTPORT(A_8255_PROG, SET_PC(b));
		data = INPORT(A_8255_PC) & 0x0F;
		data = TEST_REVERT_4(data);
		if(data != i)
		{
			errors++;

			m_buffer.Format("ERROR --> Expected: 0x%02X - Got: 0x%02X\r\n",i,data);
			AddToEditBox(IDC_QUICKTEST_EDIT, m_buffer, this);
		}
		OUTPORT(A_8255_PROG, CLR_PC(b));

		::Sleep(m_pulsatedelay);
	}
	
	if (errors)
	   m_buffer.Format("Test 10 had %d error%s.\r\n", errors, (errors > 1) ? "s" : ""); 
	else
	   m_buffer.Format("Test 10 passed!\r\n");

	m_summary += m_buffer;

	//
	// Summary
	//
	
	AddToEditBox(IDC_QUICKTEST_EDIT, "\r\n------------------\r\nSummary...\r\n------------------\r\n", this);

	AddToEditBox(IDC_QUICKTEST_EDIT, m_summary, this);
}


