// PreferencesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "PreferencesDlg.h"
#include "globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg dialog

CPreferencesDlg::CPreferencesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPreferencesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPreferencesDlg)
	m_PulsateDelay = 0;
	m_CardAddress = -1;
	m_Warnings = FALSE;
	//}}AFX_DATA_INIT
}

void CPreferencesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPreferencesDlg)
	DDX_Text(pDX, IDC_PULSATEDELAY_EDIT, m_PulsateDelay);
	DDX_Radio(pDX, IDC_CARDADDRESS300_RADIO, m_CardAddress);
	DDX_Check(pDX, IDC_WARNINGS_CHECK, m_Warnings);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPreferencesDlg, CDialog)
	//{{AFX_MSG_MAP(CPreferencesDlg)
	ON_WM_HELPINFO()
	ON_BN_CLICKED(IDC_HELP_BUTTON, OnHelpButton)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPreferencesDlg message handlers

BOOL CPreferencesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_CardAddress = m_cardaddress;
	m_PulsateDelay = m_pulsatedelay;
	m_Warnings = m_warnings;

	((CAnimateCtrl *)GetDlgItem(IDC_CARDADDRESS_AVI))->Open(IDR_CARDADDRESS_AVI);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPreferencesDlg::OnOK() 
{
	CString buffer;
	GetDlgItemText(IDC_PULSATEDELAY_EDIT, buffer);

	if (buffer.IsEmpty())
		SetDlgItemInt(IDC_PULSATEDELAY_EDIT, 0, FALSE);
	
	UpdateData(TRUE);

	m_cardaddress = m_CardAddress;
	m_pulsatedelay = m_PulsateDelay;
	m_warnings = m_Warnings;

	AfxGetApp()->WriteProfileInt("Preferences", "CardAddress", m_cardaddress);
	AfxGetApp()->WriteProfileInt("Preferences", "PulsateDelay", m_pulsatedelay);
	AfxGetApp()->WriteProfileInt("Preferences", "Warnings", m_warnings);
	
	CDialog::OnOK();
}

void CPreferencesDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUPREFERENCES);
}

BOOL CPreferencesDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}


