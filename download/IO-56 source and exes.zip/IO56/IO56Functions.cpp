// IO56Functions.cpp  : implementation file 
// 

#include "stdafx.h"
#include "IO56.h"
#include "IO56Functions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////////////
// IO-56 For Windows Custom 

BOOL CheckFileExtension(UINT control, CString extension, CString &filename, CWnd *pParent)
{
	BOOL bCorrectExtension = FALSE;
	CEdit *pEditBox = ((CEdit *)pParent->GetDlgItem(control));

	pParent->GetDlgItemText(control, filename);
	filename.MakeLower();
	extension.MakeLower();

	extension = "." + extension;

	if (filename.Right(extension.GetLength()) != extension)
		filename += extension;
	else
		bCorrectExtension = TRUE;

	pParent->SetDlgItemText(control, filename);
	pEditBox->SetSel(0, filename.GetLength(), TRUE);
	pParent->UpdateWindow();

	return(bCorrectExtension);
}

BOOL BrowseForFile(UINT control, CString defaultname, CString extension, CString filedescription,
    		    CString title, CWnd *pParent)
{
	CString wildcardname, filename;

	defaultname.MakeLower();
	extension.MakeLower();

	pParent->GetDlgItemText(control, filename);

	if (filename.IsEmpty())
		filename = defaultname + "." + extension;
	else
		filename.MakeLower();

	wildcardname = "*." + extension;
	filedescription += " (" + wildcardname + ") | " + wildcardname + "||";
	title = "IO-56: " + title;

	CFileDialog fileDialog(FALSE, wildcardname, NULL, OFN_HIDEREADONLY | OFN_SHAREAWARE |
		OFN_OVERWRITEPROMPT | OFN_EXTENSIONDIFFERENT, filedescription, pParent);
	
	fileDialog.m_ofn.nFilterIndex = 0;
	fileDialog.m_ofn.lpstrTitle = title;
	fileDialog.m_ofn.lpstrFile = filename.GetBuffer(_MAX_PATH);
	fileDialog.m_ofn.lpstrDefExt = extension;

	BOOL bResult = fileDialog.DoModal() == IDOK ? TRUE : FALSE;
	
	filename.ReleaseBuffer();

	if (!bResult)
		return (FALSE);

	pParent->SetDlgItemText(control, filename);

	CheckFileExtension(control, extension, filename, pParent);
	
	return (TRUE);
}

void AddToEditBox(UINT control, CString m_buffer, CWnd *pParent)
{ 
	CString buffer;
	CEdit *pEditBox = ((CEdit *)pParent->GetDlgItem(control));

	pEditBox->GetWindowText(buffer);	
	pEditBox->SetSel(buffer.GetLength(),buffer.GetLength());
	pEditBox->ReplaceSel(m_buffer);
}

CString GetTime(void)
{
	CTime CurrentTime = CTime::GetCurrentTime();

	CString buffer;
	
	buffer.Format("%02d:%02d:%02d", CurrentTime.GetHour(), CurrentTime.GetMinute(),
		CurrentTime.GetSecond());

	return(buffer);
}
		
void FixHexEditBox(int mode, UINT control, int length, unsigned long max,
    unsigned long min, CWnd *pParent)
{
	int loop, bufferlength;
	unsigned long value;
	CString buffer;

	pParent->GetDlgItemText(control, buffer); 

	if (mode)
	{
		if (buffer.IsEmpty())
		   bufferlength = 0;
		else	
		   bufferlength = buffer.GetLength();

		for (loop = 0; loop < (length - bufferlength); loop++)
		   buffer = "0" + buffer;
	}

	if (!buffer.IsEmpty())
	{
	   if (buffer.GetLength() > (length - 1))
	   {
		   buffer.MakeUpper();

		   for (loop = 0; loop < length; loop++)
		      if (buffer.GetAt(loop) < _T('0') || buffer.GetAt(loop) > _T('9') && 
			      buffer.GetAt(loop) < _T('A') || buffer.GetAt(loop) > _T('F'))
			      buffer.SetAt(loop, 'F');
		   
		   sscanf(buffer, "%09x", &value);
		  
		   if (value > max)
			   value = max;

		   if (value < min)
			   value = min;

		   buffer.Format(_T("%0*x"), length, value); 
		   buffer.MakeUpper();

		   pParent->SetDlgItemText(control, buffer);		 
	   }
	}
}
