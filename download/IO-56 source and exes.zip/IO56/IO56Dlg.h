// IO56Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIO56Dlg dialog

class CIO56Dlg : public CDialog
{
// Construction
public:
	CIO56Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CIO56Dlg)
	enum { IDD = IDD_IO56_DIALOG };
	CBitmapButton	m_GameboyButton;
	CBitmapButton	m_SNESButton;
	CBitmapButton	m_GenesisButton;
	CBitmapButton	m_DebugButton;
	CBitmapButton	m_GameGearButton;
	CBitmapButton	m_MasterSystemButton;
	CBitmapButton	m_NESButton;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIO56Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CIO56Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDebugButton();
	afx_msg void OnGameboyButton();
	afx_msg void OnGameGearButton();
	afx_msg void OnGenesisButton();
	afx_msg void OnNESButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnMasterSystemButton();
	afx_msg void OnSNESButton();
	afx_msg void OnAboutButton();
	afx_msg void OnHelpButton();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
