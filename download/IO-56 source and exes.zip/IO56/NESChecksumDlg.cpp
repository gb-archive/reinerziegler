// NESChecksumDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "IO56Functions.h"
#include "NESDlg.h"
#include "PreferencesDlg.h"
#include "NESChecksumDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNESChecksumDlg dialog

CNESChecksumDlg::CNESChecksumDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNESChecksumDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNESChecksumDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_hIcon = AfxGetApp()->LoadIcon(IDR_CALCULATOR);
}

void CNESChecksumDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNESChecksumDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNESChecksumDlg, CDialog)
	//{{AFX_MSG_MAP(CNESChecksumDlg)
	ON_BN_CLICKED(IDC_PROGRAMBANKS_BUTTON, OnProgrambanksButton)
	ON_BN_CLICKED(IDC_CHARACTERBANKS_BUTTON, OnCharacterbanksButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON, OnHelpButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON, OnPreferencesButton)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNESChecksumDlg message handlers

BOOL CNESChecksumDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CRect rcClient, rcParent;
	((CWnd*)GetParent())->GetWindowRect(rcParent);
	GetWindowRect(rcClient);

	MoveWindow((((rcParent.Width() - rcClient.Width()) / 2) + rcParent.left),
		       (rcParent.top + 30), rcClient.Width(), rcClient.Height(), TRUE);
	
	SetIcon(m_hIcon, TRUE);		// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	return TRUE;  
}

void CNESChecksumDlg::OnProgrambanksButton() 
{
	m_buffer.Format("\r\n\r\nProgram Checksum is:\r\n%06X %06X %06X %06X (4x8kb)\r\n",
				((CNESDlg *)GetParent())->nes_checksum(0x0000, 0x2000, NES_PRG),
				((CNESDlg *)GetParent())->nes_checksum(0x2000, 0x2000, NES_PRG),
				((CNESDlg *)GetParent())->nes_checksum(0x4000, 0x2000, NES_PRG),
				((CNESDlg *)GetParent())->nes_checksum(0x6000, 0x2000, NES_PRG));

	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
}

void CNESChecksumDlg::OnCharacterbanksButton() 
{
	m_buffer.Format("\r\n\r\nCharacter Checksum is:\r\n%06X %06X %06X %06X\r\n%06X %06X %06X %06X (8x1kb)\r\n",
				((CNESDlg *)GetParent())->nes_checksum(0x0000, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x0400, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x0800, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x0C00, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x1000, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x1400, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x1800, 0x0400, NES_CHR),
				((CNESDlg *)GetParent())->nes_checksum(0x1C00, 0x0400, NES_CHR));
	
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
}

void CNESChecksumDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;

	dlg.DoModal();	
}	

void CNESChecksumDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUNESADVANCEDCHECKSUM);	
}

BOOL CNESChecksumDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}
