// IO56OutputBufferCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "IO56OutputBufferCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIO56OutputBufferCtrl dialog


CIO56OutputBufferCtrl::CIO56OutputBufferCtrl(CWnd* pParent /*=NULL*/)
	: CDialog(CIO56OutputBufferCtrl::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIO56OutputBufferCtrl)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CIO56OutputBufferCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIO56OutputBufferCtrl)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIO56OutputBufferCtrl, CDialog)
	//{{AFX_MSG_MAP(CIO56OutputBufferCtrl)
	//}}AFX_MSG_MAP

	ON_EN_CHANGE(IDC_OUTPUTBUFFER7_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_OUTPUTBUFFER6_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_OUTPUTBUFFER5_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_OUTPUTBUFFER4_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_OUTPUTBUFFER3_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_OUTPUTBUFFER2_EDIT, BINChanged) 
	ON_EN_CHANGE(IDC_OUTPUTBUFFER1_EDIT, BINChanged)
	ON_EN_CHANGE(IDC_OUTPUTBUFFER0_EDIT, BINChanged)
	
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER7_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER6_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER5_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER4_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER3_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER2_EDIT, BINLostFocus) 
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER1_EDIT, BINLostFocus)
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFER0_EDIT, BINLostFocus) 
	
	ON_EN_CHANGE(IDC_OUTPUTBUFFERDEC_EDIT, DECChanged) 
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFERDEC_EDIT, DECLostFocus)
	
	ON_EN_CHANGE(IDC_OUTPUTBUFFERHEX_EDIT, HEXChanged) 
	ON_EN_KILLFOCUS(IDC_OUTPUTBUFFERHEX_EDIT, HEXLostFocus)
	
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CIO56OutputBufferCtrl message handlers

BOOL CIO56OutputBufferCtrl::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_buffer.Format("%s (%d .. %d)", m_WindowTitle, m_PinsStart, m_PinsStart + 7);
	SetDlgItemText(IDC_OUTPUTBUFFER_STATIC, m_buffer);

	ResetControl();
	
	return TRUE; 
}

int CIO56OutputBufferCtrl::GetValue()
{
	return (GetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, NULL, FALSE));	
}

void CIO56OutputBufferCtrl::SetValue(int value)
{
	SetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, value, FALSE);
	
	ConvertDECToHEX();
	ConvertDECToBIN();
}

void CIO56OutputBufferCtrl::ResetControl()
{
	SetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, 0, FALSE);
	
	m_ReadOnly = FALSE;

	UpdateDialog();

	ConvertDECToBIN();
	ConvertDECToHEX();
}

void CIO56OutputBufferCtrl::UpdateDialog()
{
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER7_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER6_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER5_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER4_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER3_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER2_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER1_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFER0_EDIT  ))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFERDEC_EDIT))->SetReadOnly(m_ReadOnly);
   ((CEdit   *)GetDlgItem(IDC_OUTPUTBUFFERHEX_EDIT))->SetReadOnly(m_ReadOnly);
}

void CIO56OutputBufferCtrl::ConvertDECToBIN()
{
   int value;

   value = GetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, 0, FALSE);

   SetDlgItemInt(IDC_OUTPUTBUFFER7_EDIT, (value & 0x80) >> 7, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER6_EDIT, (value & 0x40) >> 6, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER5_EDIT, (value & 0x20) >> 5, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER4_EDIT, (value & 0x10) >> 4, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER3_EDIT, (value & 0x08) >> 3, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER2_EDIT, (value & 0x04) >> 2, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER1_EDIT, (value & 0x02) >> 1, FALSE);
   SetDlgItemInt(IDC_OUTPUTBUFFER0_EDIT, (value & 0x01),      FALSE);
}

void CIO56OutputBufferCtrl::ConvertDECToHEX()
{
	m_buffer.Format("%02x", GetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT));
	m_buffer.MakeUpper();
	SetDlgItemText(IDC_OUTPUTBUFFERHEX_EDIT, m_buffer);
}

void CIO56OutputBufferCtrl::ConvertHEXToDEC()
{
	int value;

	GetDlgItemText(IDC_OUTPUTBUFFERHEX_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &value);
	SetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, value);
}

void CIO56OutputBufferCtrl::ConvertBINToDEC()
{
	SetDlgItemInt( IDC_OUTPUTBUFFERDEC_EDIT,
		( GetDlgItemInt(IDC_OUTPUTBUFFER7_EDIT, NULL, FALSE) * 0x80 +						  GetDlgItemInt(IDC_OUTPUTBUFFER6_EDIT, NULL, FALSE) * 0x40 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER5_EDIT, NULL, FALSE) * 0x20 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER4_EDIT, NULL, FALSE) * 0x10 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER3_EDIT, NULL, FALSE) * 0x08 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER2_EDIT, NULL, FALSE) * 0x04 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER1_EDIT, NULL, FALSE) * 0x02 +
		  GetDlgItemInt(IDC_OUTPUTBUFFER0_EDIT, NULL, FALSE) ) , FALSE );
}

void CIO56OutputBufferCtrl::BINChanged()
{
	CWnd* focusedcontrol;
	int controlID;
	int value;

	focusedcontrol = GetFocus();
	controlID = focusedcontrol -> GetDlgCtrlID();

	GetDlgItemText(controlID, m_buffer);
	value = GetDlgItemInt(controlID, NULL, FALSE);
	value = 1 * (value != 0);

	if (!m_buffer.IsEmpty())
	{
		SetDlgItemInt(controlID, value, FALSE);
		ConvertBINToDEC();
		ConvertDECToHEX();
	}
}

void CIO56OutputBufferCtrl::DECChanged()
{
	int value;
	
	GetDlgItemText(IDC_OUTPUTBUFFERDEC_EDIT, m_buffer);
	value = GetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, NULL, FALSE);
	
	if (value > 255)
	   SetDlgItemInt(IDC_OUTPUTBUFFERDEC_EDIT, 255);
				
	if (!m_buffer.IsEmpty())
	{
		ConvertDECToBIN();
		ConvertDECToHEX();
	}
}

void CIO56OutputBufferCtrl::HEXChanged()
{
	FixHexEditBox(0, IDC_OUTPUTBUFFERHEX_EDIT, 2, 0xFF, 0x00, this);

	GetDlgItemText(IDC_OUTPUTBUFFERHEX_EDIT, m_buffer);
	
	if (!m_buffer.IsEmpty())
	{
		if (m_buffer.GetLength() == 2)
		{
		   ConvertHEXToDEC();
		   ConvertDECToBIN();
		}
	}
}

void CIO56OutputBufferCtrl::BINLostFocus()
{
	ConvertDECToBIN();
	ConvertDECToHEX();
}

void CIO56OutputBufferCtrl::DECLostFocus()
{
	ConvertHEXToDEC();
	ConvertDECToBIN();
}
	
void CIO56OutputBufferCtrl::HEXLostFocus()
{
	ConvertDECToHEX();
	ConvertDECToBIN();
}

void CIO56OutputBufferCtrl::OnCancel()
{
	return;
}
