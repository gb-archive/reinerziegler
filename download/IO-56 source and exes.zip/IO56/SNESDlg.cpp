// SNESDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "SNESDlg.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg dialog

CSNESDlg::CSNESDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSNESDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSNESDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CSNESDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSNESDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSNESDlg, CDialog)
	//{{AFX_MSG_MAP(CSNESDlg)
	ON_BN_CLICKED(IDC_ADVANCED_BUTTON,           OnAdvancedButton          )
	ON_BN_CLICKED(IDC_ANALYZE_BUTTON,            OnAnalyzeButton           )
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON,        OnPreferencesButton       )
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,           OnMainmenuButton          ) 
	ON_BN_CLICKED(IDC_SAVE_BUTTON,               OnSaveButton              )
	ON_BN_CLICKED(IDC_SNESFILENAMEBROWSE_BUTTON, OnSNESFilenameBrowseButton)
	ON_BN_CLICKED(IDC_STATICRAMBROWSE_BUTTON,    OnStaticRAMBrowseButton   )
	ON_BN_CLICKED(IDC_TESTSTATICRAM_BUTTON,      OnTestStaticRAMButton     )
	ON_BN_CLICKED(IDC_CLEARSTATICRAM_BUTTON,     OnClearStaticRAMButton    )
	ON_BN_CLICKED(IDC_SAVESTATICRAM_BUTTON,      OnSaveStaticRAMButton     )
	ON_BN_CLICKED(IDC_RESTORESTATICRAM_BUTTON,   OnRestoreStaticRAMButton  )
	ON_BN_CLICKED(IDC_HELP_BUTTON, 		OnHelpButton              )
	ON_BN_CLICKED(IDC_SETCOMMANDBITS_BUTTON,     OnSetcommandbitsButton    )
	ON_BN_CLICKED(IDC_SETADDRESS_BUTTON,         OnSetaddressButton        )
	ON_EN_CHANGE(IDC_ADDRESS_EDIT,               OnChangeAddressEdit       )
	ON_EN_KILLFOCUS(IDC_ADDRESS_EDIT,            OnKillfocusAddressEdit    )
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FINISHEDTHREADMESSAGE, OnThreadFinished)
	ON_MESSAGE(STARTEDTHREADMESSAGE,  OnThreadStarted )

	ON_EN_CHANGE(IDC_SNESFILENAME_EDIT,      UpdateDialog)
	ON_EN_CHANGE(IDC_STATICRAMFILENAME_EDIT, UpdateDialog)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Threads 

UINT SNESAnalyzeThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 1L);	
	pDlg->snes_analyze();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 1L);

	return 0;
}

UINT SNESSaveThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;
	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 2L);	

	CheckFileExtension(IDC_SNESFILENAME_EDIT, "smc", filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
	   buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", filename); 
	
	   pDlg->MessageBox(buffer, "IO-56 SNES File Error!", MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
	   return 0;
	}
	
	pDlg->snes_save(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 2L);

	return 0;
}

UINT SNESSaveStaticRAMThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;
	CString filename, buffer;
	
	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 5L);	
	
	CheckFileExtension(IDC_STATICRAMFILENAME_EDIT, "srm", filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
	   buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", filename); 
	
	   pDlg->MessageBox(buffer,"IO-56 SNES File Error!", MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 5L);
	   return 0;
	}

	pDlg->snes_backup(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 5L);

	return 0;
}

UINT SNESRestoreStaticRAMThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;
	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 6L);	
	
	CheckFileExtension(IDC_STATICRAMFILENAME_EDIT, "srm", filename, pDlg);

	if ((pDlg->fp = fopen(filename, "rb")) == NULL)
	{
	   buffer.Format("An error occurred while reading \"%s\"!\n\nPlease correct the problem and try again.", filename); 
	
	   pDlg->MessageBox(buffer,"IO-56 SNES File Error!", MB_ICONSTOP | MB_OK);

	   pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 6L);
	   return 0;
	}

	pDlg->snes_restore(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 6L);

	return 0;
}

UINT SNESTestStaticRAMThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;
	
	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 3L);	
	pDlg->snes_test();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 3L);

	return 0;
}

UINT SNESClearStaticRAMThread(LPVOID pParam)
{
	CSNESDlg *pDlg = (CSNESDlg *)pParam;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 4L);	
	pDlg->snes_clear();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 4L);

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Thread Message Handlers

long CSNESDlg::OnThreadStarted(WPARAM wParam, LPARAM lParam)
{
	((CEdit *)GetDlgItem(IDC_SNESSTATISTICS_EDIT))->SetWindowText("");
	((CEdit *)GetDlgItem(IDC_SNESSTATUS_EDIT    ))->SetWindowText("");

	fp = NULL;

	m_buffer.Format("-------- %s started at %s --------\r\n\r\n", 
			GetOperation(lParam), GetTime());
		
	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
	
	return(0L);
}

long CSNESDlg::OnThreadFinished(WPARAM wParam, LPARAM lParam)
{
	switch (lParam)
	{
		case 1:          m_Analyzing	= FALSE; break;
		case 2:	            m_Saving	= FALSE; break;
		case 3:   m_TestingStaticRAM	= FALSE; break;
		case 4:  m_ClearingStaticRAM	= FALSE; break;
		case 5:    m_SavingStaticRAM	= FALSE; break;
		case 6: m_RestoringStaticRAM	= FALSE; break;
	}

	if (fp)
		fclose(fp);

	if (wParam)
	{
		if (dwExitCode)
		   TerminateThread(pThread->m_hThread, dwExitCode);

		dwExitCode = 0;

		m_buffer.Format("\r\n\r\n-------- %s terminated at %s --------\r\n\r\n", 
			GetOperation(lParam), GetTime());	
	}
	else
	{
		m_buffer.Format("\r\n-------- %s finished at %s --------\r\n",
		GetOperation(lParam), GetTime()); 
	}

	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
		
	UpdateDialog();

	return (0L);
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Custom Functions

CString CSNESDlg::GetOperation(LPARAM lParam)
{
	CString buffer;

	switch (lParam)
	{
		case 1:	buffer = "Analyzing";             break;
		case 2:	buffer = "Saving";                break;
		case 3:	buffer = "Testing";               break;
		case 4:	buffer = "Clearing";              break;
		case 5:	buffer = "Saving Static RAM";     break;
		case 6:	buffer = "Restoring Static RAM";  break;
	}

	return(buffer);
}

void CSNESDlg::UpdateDialog()
{	
	// UpdateData(TRUE);   Uncomment When Verify Has Been Added
	
	SetDlgItemText(IDC_ADVANCED_BUTTON,         m_Advanced           ? "Standard" : "Advanced"         );
	SetDlgItemText(IDC_SAVE_BUTTON,             m_Saving             ? "Stop"     : "Save"             );
	SetDlgItemText(IDC_ANALYZE_BUTTON,          m_Analyzing          ? "Stop"     : "Analyze"          );
	SetDlgItemText(IDC_TESTSTATICRAM_BUTTON,    m_TestingStaticRAM   ? "Stop"     : "Test Static RAM" );
	SetDlgItemText(IDC_CLEARSTATICRAM_BUTTON,   m_ClearingStaticRAM  ? "Stop"     : "Clear Static RAM");
	SetDlgItemText(IDC_SAVESTATICRAM_BUTTON,    m_SavingStaticRAM    ? "Stop"     : "Save Static RAM" );
	SetDlgItemText(IDC_RESTORESTATICRAM_BUTTON, m_RestoringStaticRAM
		? "Stop"     : "Restore Static RAM");

	int operation = (m_Advanced) ? SW_SHOW : SW_HIDE;

	((CButton*   )GetDlgItem(IDC_SETCOMMANDBITS_BUTTON     ))->ShowWindow(operation);
	((CButton*   )GetDlgItem(IDC_SETADDRESS_BUTTON         ))->ShowWindow(operation);
	((CComboBox* )GetDlgItem(IDC_COMMANDBIT_COMBO          ))->ShowWindow(operation);
	((CEdit*     )GetDlgItem(IDC_ADDRESS_EDIT              ))->ShowWindow(operation);
	((CStatic*   )GetDlgItem(IDC_COMMANDBIT_STATIC         ))->ShowWindow(operation);
	((CStatic*   )GetDlgItem(IDC_ADDRESS_STATIC            ))->ShowWindow(operation);
	((CStatic*   )GetDlgItem(IDC_HEX_STATIC                ))->ShowWindow(operation);
	
	operation = !(  	   m_Analyzing	||             m_Saving ||
			   m_TestingStaticRAM	||  m_ClearingStaticRAM ||
			    m_SavingStaticRAM	|| m_RestoringStaticRAM   );

	((CButton*  )GetDlgItem(IDC_SETCOMMANDBITS_BUTTON    ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_SETADDRESS_BUTTON        ))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_COMMANDBIT_COMBO         ))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_ADDRESS_EDIT             ))->EnableWindow(operation);

	((CButton*  )GetDlgItem(IDC_PREFERENCES_BUTTON       ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_HELP_BUTTON              ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_MAINMENU_BUTTON          ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_ADVANCED_BUTTON          ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_SNESFILENAMEBROWSE_BUTTON))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_SNESFILENAME_EDIT        ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_STATICRAMBROWSE_BUTTON   ))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_STATICRAMFILENAME_EDIT   ))->EnableWindow(operation);

	  //((CButton*  )GetDlgItem(IDC_VERIFYNONE_CHECK        ))->EnableWindow(operation);
	  //((CButton*  )GetDlgItem(IDC_VERIFY_CHECK            ))->EnableWindow(operation);
	  //((CButton*  )GetDlgItem(IDC_VERIFYX2_CHECK          ))->EnableWindow(operation);
	
	((CButton*  )GetDlgItem(IDC_ANALYZE_BUTTON         ))->EnableWindow(operation || m_Analyzing);
	((CButton*  )GetDlgItem(IDC_TESTSTATICRAM_BUTTON   ))->EnableWindow(operation || m_TestingStaticRAM);
	((CButton*  )GetDlgItem(IDC_CLEARSTATICRAM_BUTTON  ))->
		EnableWindow(operation || m_ClearingStaticRAM);
	
	GetDlgItemText(IDC_SNESFILENAME_EDIT, m_buffer);
	((CButton*  )GetDlgItem(IDC_SAVE_BUTTON             ))->
		EnableWindow((operation || m_Saving           ) && !m_buffer.IsEmpty());
	
	GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_buffer);
	((CButton*  )GetDlgItem(IDC_SAVESTATICRAM_BUTTON   ))->
		EnableWindow((operation || m_SavingStaticRAM   ) && !m_buffer.IsEmpty());
	
	((CButton*  )GetDlgItem(IDC_RESTORESTATICRAM_BUTTON))->
		EnableWindow((operation || m_RestoringStaticRAM) && !m_buffer.IsEmpty());
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg message handlers

BOOL CSNESDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_warnings)
	{
	   if (MessageBox("Before dumping a SNES cartridge,\nplease attach the SNES extension!\n\nDo you wish to continue?", 
	      "IO-56 SNES Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnOK();
		  return TRUE;
	   }
	}

	    	   m_Advanced	= 		m_Analyzing	=           m_Saving	=
	   m_TestingStaticRAM 	= 	m_ClearingStaticRAM	=  m_SavingStaticRAM 	= 	 	 	 	 m_RestoringStaticRAM	= FALSE;

	dwExitCode = 0;
	fp = NULL;
	
	((CComboBox *)GetDlgItem(IDC_COMMANDBIT_COMBO))->SetCurSel(0);
	SetDlgItemText(IDC_ADDRESS_EDIT, "000000");

	UpdateDialog();

	snes_header[0] = 0;

	return TRUE;  
}

void CSNESDlg::OnCancel() 
{
	if (!m_Saving && !m_Analyzing && !m_TestingStaticRAM &&
		!m_ClearingStaticRAM  && !m_RestoringStaticRAM)	
		CDialog::OnCancel();
	else
		::Beep((DWORD)-1, (DWORD)-1);
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Command Button message handlers

void CSNESDlg::OnSaveButton() 
{
	if (m_Saving)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 2);
		return;
	}

    	m_Saving = TRUE;	
	
	UpdateDialog();

	pThread = AfxBeginThread(SNESSaveThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}

void CSNESDlg::OnAnalyzeButton() 
{
	if (m_Analyzing)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 1);
		return;
	}
	
	m_Analyzing = TRUE;  
	   
	UpdateDialog();
	 
	pThread = AfxBeginThread(SNESAnalyzeThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}

void CSNESDlg::OnAdvancedButton() 
{
	CRect EditBoxRect;
	
	m_Advanced = !m_Advanced;

	((CEdit *)GetDlgItem(IDC_SNESSTATISTICS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_SNESSTATISTICS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	((CEdit *)GetDlgItem(IDC_SNESSTATUS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_SNESSTATUS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	AddToEditBox(IDC_SNESSTATUS_EDIT, "", this);

	UpdateDialog();
}

void CSNESDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;

	dlg.DoModal();	
}

void CSNESDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUSNES);
}

BOOL CSNESDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

void CSNESDlg::OnMainmenuButton() 
{
	CDialog::OnOK();	
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Static RAM Button message handlers

void CSNESDlg::OnTestStaticRAMButton() 
{
	if (m_TestingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 3);
		return;
	}

	if (m_warnings)
	   if (MessageBox("Testing a SNES cartridge's Static\nRAM, will also erase the Static RAM!\n\nDo you wish to continue?", 
	         "IO-56 SNES Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	
	m_TestingStaticRAM = TRUE;
	   
	UpdateDialog();
	   
	pThread = AfxBeginThread(SNESTestStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();	
}

void CSNESDlg::OnClearStaticRAMButton() 
{
	if (m_ClearingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 4);
		return;
	}
	
	if (m_warnings)
	   if (MessageBox("Clearing a SNES cartridge's\nStatic RAM cannot be undone.\n\nDo you wish to continue?", 
	         "IO-56 SNES Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	
    	m_ClearingStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(SNESClearStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0,
CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();		
}

void CSNESDlg::OnSaveStaticRAMButton() 
{
	if (m_SavingStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 5);
		return;
	}
	
m_SavingStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(SNESSaveStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();			
}

void CSNESDlg::OnRestoreStaticRAMButton() 
{
	if (m_RestoringStaticRAM)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 6);
		return;
	}
	
    	if (m_warnings)
	   if (MessageBox("Restoring a SNES cartridge's Static RAM\nwill overwrite its current Static RAM!\n\nDo you wish to continue?", 
	         "IO-56 SNES Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
		     return;
	       
	m_RestoringStaticRAM = TRUE;
	
	UpdateDialog();
	
	pThread = AfxBeginThread(SNESRestoreStaticRAMThread, this, THREAD_PRIORITY_NORMAL, 0,
CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();			
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg BROWSE Button message handlers

void CSNESDlg::OnSNESFilenameBrowseButton() 
{
	BrowseForFile(IDC_SNESFILENAME_EDIT,
		"SNESCart", "smc", "SNES Cartridge",
		"Enter SNES Cartridge Image Filename", this);
	
	UpdateDialog();
}

void CSNESDlg::OnStaticRAMBrowseButton() 
{	
	BrowseForFile(IDC_STATICRAMFILENAME_EDIT,
		"SNESSRAM", "srm", "SNES Static RAM",
		"Enter SNES Static RAM Image Filename", this);
	
	UpdateDialog();
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg Advanced Button message handlers

void CSNESDlg::OnSetcommandbitsButton() 
{
	int selection, value;
	CString buffer;
	
	selection = ((CComboBox*)GetDlgItem(IDC_COMMANDBIT_COMBO))->GetCurSel();
	GetDlgItemText(IDC_COMMANDBIT_COMBO, buffer);

	switch(selection)
	{
		case 0: value = 1; break;
		case 1: value = 2; break;
		case 2: value = 4; break;
		case 3: value = 8; break;
	}
	
 	value |= 0xF0;

	m_buffer.Format("\r\nCommand Bit %s Set\r\n", buffer);
	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
	
	OUTPORT(A_8255_PC, value);

}

void CSNESDlg::OnSetaddressButton() 
{
	unsigned long addr;

	GetDlgItemText(IDC_ADDRESS_EDIT, m_buffer);
	sscanf(m_buffer, "%06X", &addr);
	
	m_buffer.Format("\r\nAddress Set To %06X\r\n", addr);
	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
	
	OUTPORT(B_8255_PB,
	 	  ((addr>>11)&0x01) |
		  ((addr>>11)&0x02) |
		  ((addr>>8 )&0x04) |
		  ((addr>>10)&0x08) |
		  ((addr>>5 )&0x10) |
		  ((addr>>9 )&0x20) |
		  ((addr>>2 )&0x40) |
		  ((addr>>8 )&0x80));
	OUTPORT(B_8255_PC,
  		  ((addr>>7 )&0x01) |
		  ((addr>>15)&0x02) |
		  ((addr>>4 )&0x04) |
		  ((addr>>14)&0x08) |
		  ((addr>>1 )&0x10) |
		  ((addr>>13)&0x20) |
		  ((addr<<2 )&0x40) |
		  ((addr>>12)&0x80));
	OUTPORT(A_8255_PA,
	 	  ((addr>>3 )&0x01) |
		  ((addr>>19)&0x02) |
		  ( addr     &0x04) |
		  ((addr>>18)&0x08) |
		  ((addr<<3 )&0x10) |
		  ((addr>>17)&0x20) |
		  ((addr<<6 )&0x40) |
		  ((addr>>16)&0x80));
}

void CSNESDlg::OnChangeAddressEdit() 
{
	FixHexEditBox(0, IDC_ADDRESS_EDIT, 6, 0xFFFFFF, 0x000000, this);	
}

void CSNESDlg::OnKillfocusAddressEdit() 
{
	FixHexEditBox(1, IDC_ADDRESS_EDIT, 6, 0xFFFFFF, 0x000000, this);	
}


/////////////////////////////////////////////////////////////////////////////
// CSNESDlg IO-56 SNES.H Routines

inline int CSNESDlg::snes_read_byte(register unsigned long addr)
{
	register int i;

	OUTPORT(B_8255_PB,
		((addr>>11)&0x01) |
		((addr>>11)&0x02) |
		((addr>>8 )&0x04) |
		((addr>>10)&0x08) |
		((addr>>5 )&0x10) |
		((addr>>9 )&0x20) |
		((addr>>2 )&0x40) |
		((addr>>8 )&0x80));
	OUTPORT(B_8255_PC,
		((addr>>7 )&0x01) |
		((addr>>15)&0x02) |
		((addr>>4 )&0x04) |
		((addr>>14)&0x08) |
		((addr>>1 )&0x10) |
		((addr>>13)&0x20) |
		((addr<<2 )&0x40) |
		((addr>>12)&0x80));
	OUTPORT(A_8255_PA,
		((addr>>3 )&0x01) |
		((addr>>19)&0x02) |
		( addr     &0x04) |
		((addr>>18)&0x08) |
		((addr<<3 )&0x10) |
		((addr>>17)&0x20) |
		((addr<<6 )&0x40) |
		((addr>>16)&0x80));
	
	::Sleep(m_pulsatedelay);
	
	i = INPORT(A_8255_PB);

	return
		( i&0x01    ) |
		((i&0x02)<<3) |
		((i&0x04)>>1) |
		((i&0x08)<<2) |
		((i&0x10)>>2) |
		((i&0x20)<<1) |
		((i&0x40)>>3) |
		( i&0x80 );
}

inline void CSNESDlg::snes_write_byte(register int val, register unsigned long addr)
{
	SNES_IDLE;
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_out|PCh_in);
	/* Reconfiguring the 8255 may modify the PC register! */
	if(SNES_LOROM) {
		SNES_WR_LORAM;
	} else {
		SNES_WR_HIRAM;
	}
	OUTPORT(B_8255_PB,
		((addr>>11)&0x01) |
		((addr>>11)&0x02) |
		((addr>>8 )&0x04) |
		((addr>>10)&0x08) |
		((addr>>5 )&0x10) |
		((addr>>9 )&0x20) |
		((addr>>2 )&0x40) |
		((addr>>8 )&0x80));
	OUTPORT(B_8255_PC,
		((addr>>7 )&0x01) |
		((addr>>15)&0x02) |
		((addr>>4 )&0x04) |
		((addr>>14)&0x08) |
		((addr>>1 )&0x10) |
		((addr>>13)&0x20) |
		((addr<<2 )&0x40) |
		((addr>>12)&0x80));
	OUTPORT(A_8255_PA,
		((addr>>3 )&0x01) |
		((addr>>19)&0x02) |
		( addr     &0x04) |
		((addr>>18)&0x08) |
		((addr<<3 )&0x10) |
		((addr>>17)&0x20) |
		((addr<<6 )&0x40) |
		((addr>>16)&0x80));
	OUTPORT(A_8255_PB,
		( val&0x01    ) |
		((val>>3)&0x02) |
		((val<<1)&0x04) |
		((val>>2)&0x08) |
		((val<<2)&0x10) |
		((val>>1)&0x20) |
		((val<<3)&0x40) |
		( val&0x80 ));
	OUTPORT(A_8255_PROG, CLR_PC(SNES_WR));
	OUTPORT(A_8255_PROG, SET_PC(SNES_WR));
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_in|PCl_out|PCh_in);

	::Sleep(m_pulsatedelay);
}

void CSNESDlg::snes_read_header()
{
	int byte;

	SNES_RD_ROM;
	if(snes_header != NULL)
		return;

	//snes_header = (unsigned char *)malloc(0x40 * sizeof(unsigned char));

	for(byte = 0; byte < 0x40; byte++) {
		snes_header[byte] = snes_read_byte(0xFFC0 + byte);
	}
	snes_header[byte] = 0;
}

void CSNESDlg::snes_init()
{
	OUTPORT(B_8255_PROG, 0x80|PA_in|PB_out|PCl_out|PCh_out);
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_in|PCl_out|PCh_in);
	SNES_IDLE;
}

void CSNESDlg::snes_analyze()
{
	char name[22];
	char *s;
	unsigned int checksum;
	
	snes_init();
	
	snes_read_header();

	strncpy(name, (const char *) &snes_header[0], 21);
	name[21] = 0;
	
	m_buffer.Format("Cartridge name:\r\n%s\r\n\r\n", name);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);

	switch((snes_header[21]&0xF0)>>4) {
	case 0:
		s = "SlowROM";
		break;
	case 3:
		s = "FastROM";
		break;
	default:
		s = "Unknown";
		break;
	}
	
	switch(snes_header[21]&0x0F) {
	case 0:
		s = "LoROM (32 kB banks)";
		break;
	case 1:
		s = "HiROM (64 kB banks)";
		break;
	default:
		s = "Unknown";
		break;
	}
	
	m_buffer.Format("Bank size: %s\r\n", s);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);
	
	m_buffer.Format("ROM speed: %s\r\n", s);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);

	switch(snes_header[22]) {
	case 0:
		s = "ROM only";
		break;
	case 1:
		s = "ROM and RAM";
		break;
	case 2:
		s = "ROM and Save RAM";
		break;
	case 3:
		s = "ROM and DSP1 chip";
		break;
	case 4:
		s = "ROM, RAM and DSP1 chip";
		break;
	case 5:
		s = "ROM, Save RAM and DSP1 chip";
		break;
	case 19:
		s = "ROM and Super FX chip";
		break;
	case 227:
		s = "ROM, RAM and GameBoy data";
		break;
	case 246:
		s = "ROM and DSP2 chip";
		break;
	default:
		s = "Unknown";
		break;
	}
	
	m_buffer.Format("ROM type: %d (%s)\r\n", snes_header[22], s);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("ROM size: %d (%d kB)\r\n", snes_header[23], 1 << snes_header[23]);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("SRAM size: %d (%d kB)\r\n", snes_header[24], snes_header[24] == 0 ? 0 : 1 <<
snes_header[24]);
	
AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);

	if(snes_header[24] > 0 && snes_sram_addr == 0) {
		if(SNES_LOROM)
			snes_sram_addr = 0x700000;
		else
			snes_sram_addr = 0x206000;
		
		m_buffer.Format("SRAM addr: %06lX\r\n", snes_sram_addr);
		AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);
	}
	
	checksum = snes_header[30]+(snes_header[31]<<8);
	
	m_buffer.Format("Checksum: %02X\r\n", checksum);
	AddToEditBox(IDC_SNESSTATISTICS_EDIT, m_buffer, this);
}

void CSNESDlg::snes_save(FILE *fp)
{
	unsigned long addr, min, max, sizekB, chunk;
	unsigned long *checksums;
	unsigned int checksum, chk;
	
	unsigned long nbchunk, i;

	snes_analyze();
	
	sizekB = 1 << snes_header[23];

	/* One chunk is 4Mbit = 512kB */
	nbchunk = sizekB / 512;
	checksums = (unsigned long *)calloc(nbchunk, sizeof(long));

	SNES_RD_ROM;
 	for(chunk = 0; chunk < nbchunk; chunk++) {
		m_buffer.Format("Reading chunk %ld\r\n", chunk);
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

		min = chunk << 19;
		max = (chunk + 1) << 19;
		if(SNES_LOROM) {
			min <<= 1;
			max <<= 1;
		}
		for(addr = min; addr < max; addr++) {
			if(addr % 0x1000 == 0) {
				AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
				//fflush(stdout);
			}
			i = snes_read_byte(addr);
			checksums[chunk] += i;
			
			if (fputc(i, fp) == EOF)
			{
			   GetDlgItemText(IDC_SNESFILENAME_EDIT, m_filename);
			   m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		       
   MessageBox(m_buffer,"IO-56 SNES File Error!", MB_ICONSTOP | MB_OK);

			   SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
			}

			if(SNES_LOROM && (addr % 0x8000 == 0x7FFF))
				addr += 0x8000;
		}
		AddToEditBox(IDC_SNESSTATUS_EDIT, "\r\n", this);
	}

	chk = 0;
	for(i = 0; i < nbchunk; i++)
		chk += checksums[i];
	chk &= 0xFFFF;
	checksum = snes_header[30]+(snes_header[31]<<8);
	if(chk == checksum)
		AddToEditBox(IDC_SNESSTATUS_EDIT, "Checksum OK!\r\n", this);
	else
	{
		m_buffer.Format("Warning: checksum is wrong (waiting for %X, got %X)\r\n", checksum, chk);
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
	}			
		
	free(checksums);
}

void CSNESDlg::snes_backup(FILE *fp)
{
	unsigned long addr, max, sizekB;
	int i;

	snes_analyze();
	
	if(snes_header[24] == 0) {
		m_buffer.Format("No save-RAM\r\n");
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
		return;
	}
	sizekB = 1 << snes_header[24];

	if(SNES_LOROM) {
		SNES_RD_LORAM;
	} else {
		SNES_RD_HIRAM;
	}
	
	m_buffer.Format("Reading SRAM\r\n");
	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
	
	max = snes_sram_addr+(sizekB<<10);
	for(addr = snes_sram_addr; addr < max; addr++) {
		if(addr % 0x1000 == 0) {
			AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
			//fflush(stdout);
		}
		i = snes_read_byte(addr);
		
		if (fputc(i, fp) == EOF)
		{
		   GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_filename);
		   m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		   
   MessageBox(m_buffer,"IO-56 SNES Static RAM File Error!", MB_ICONSTOP | MB_OK);

		   SendMessage(FINISHEDTHREADMESSAGE, 1, 5L);
		}

	}

	AddToEditBox(IDC_SNESSTATUS_EDIT, "\r\n", this);
			
}

void CSNESDlg::snes_restore(FILE *fp)
{
	unsigned long addr, max, sizekB;
	unsigned char val;

	snes_analyze();

	if(snes_header[24] == 0) {
		m_buffer.Format("No save-RAM\r\n");
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

		return;
	}
	sizekB = 1 << snes_header[24];

	m_buffer.Format("Restoring SRAM\r\n");
	AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

	max = snes_sram_addr+(sizekB<<10);
	for(addr = snes_sram_addr; addr < max; addr++) {
		if(feof(fp)) {
		   m_buffer.Format("Unexpected End Of File!\r\n");
		   AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

		   GetDlgItemText(IDC_STATICRAMFILENAME_EDIT, m_filename);
		   m_buffer.Format("An error occurred while reading \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		   
   MessageBox(m_buffer,"IO-56 SNES Static RAM File Error!", MB_ICONSTOP | MB_OK);

		   SendMessage(FINISHEDTHREADMESSAGE, 1, 6L);
		}
		if(addr % 0x1000 == 0) {
			AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
			//fflush(stdout);
		}
		val = fgetc(fp);
		snes_write_byte(val, addr);
	}
	
	AddToEditBox(IDC_SNESSTATUS_EDIT, "\r\n", this);
}

void CSNESDlg::snes_clear()
{
	unsigned long addr, max, sizekB;

	snes_analyze();

	if(snes_header[24] == 0) {
		AddToEditBox(IDC_SNESSTATUS_EDIT, "No Static RAM!\r\n", this);
		return;
	}
	sizekB = 1 << snes_header[24];

	AddToEditBox(IDC_SNESSTATUS_EDIT, "Clearing Static RAM:\r\n\r\n", this);
	max = snes_sram_addr+(sizekB<<10);
	for(addr = snes_sram_addr; addr < max; addr++) {
		if(addr % 0x1000 == 0) {
			AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
		}
		snes_write_byte(0x00, addr);
	}
	AddToEditBox(IDC_SNESSTATUS_EDIT, "\r\n", this);
}

void CSNESDlg::snes_test()
{
	unsigned long addr, max, sizekB;
	int i, test_val;

	snes_analyze();

	if(snes_header[24] == 0) {
		AddToEditBox(IDC_SNESSTATUS_EDIT,"No Static RAM!\r\n", this);
		return;
	}
	sizekB = 1 << snes_header[24];

	AddToEditBox(IDC_SNESSTATUS_EDIT,"Testing Static RAM:\r\n\r\n", this);
	max = snes_sram_addr+(sizekB<<10);

	for(i = 0; test_patterns[i] >= 0; i++) {
		test_val = test_patterns[i];
		m_buffer.Format("Writing 0x%02X's\r\n", test_val);
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
		for(addr = snes_sram_addr; addr < max; addr++) {
			if(addr % 0x1000 == 0) {
				AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
			}
			snes_write_byte(test_val, addr);
		}
		AddToEditBox(IDC_SNESSTATUS_EDIT, "\r\n", this);

		if(SNES_LOROM) {
			SNES_RD_LORAM;
		} else {
			SNES_RD_HIRAM;
		}
		m_buffer.Format("Verifying 0x%02X's\r\n", test_val);
		AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);

		for(addr = snes_sram_addr; addr < max; addr++) {
			if(addr % 0x1000 == 0) {
				AddToEditBox(IDC_SNESSTATUS_EDIT, ".", this);
			}
			if(snes_read_byte(addr) != test_val) {
				m_buffer.Format("\r\n\r\nError at address 0x%06lX\r\n", addr);
				AddToEditBox(IDC_SNESSTATUS_EDIT, m_buffer, this);
				SendMessage(FINISHEDTHREADMESSAGE, 1, 3L);
			
				//exit(-1);
			}
		}
		AddToEditBox(IDC_SNESSTATUS_EDIT,"\r\n", this);
	}
	AddToEditBox(IDC_SNESSTATUS_EDIT,"OK!\r\n", this);
}
