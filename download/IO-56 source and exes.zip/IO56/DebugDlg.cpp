// DebugDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "PreferencesDlg.h"
#include "globals.h"
#include "DebugDlg.h"
#include "DebugTestDlg.h"
#include "QuickTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////////////////////////////////////////////////////////////
// CDebugDlg dialog


CDebugDlg::CDebugDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDebugDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDebugDlg)
	//}}AFX_DATA_INIT
}

void CDebugDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDebugDlg, CDialog)
	//{{AFX_MSG_MAP(CDebugDlg)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON, OnPreferencesButton)
	ON_BN_CLICKED(IDC_RESET_BUTTON,       OnResetButton)
	ON_BN_CLICKED(IDC_PULSE_BUTTON,       OnPulseButton)
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,    OnMainmenuButton)
	ON_BN_CLICKED(IDC_DEBUGTEST_BUTTON,   OnDebugTestButton)
	ON_BN_CLICKED(IDC_QUICKTEST_BUTTON,   OnQuicktestButton)
	ON_BN_DOUBLECLICKED(IDC_PULSE_BUTTON, OnDoubleclickedPulseButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON, OnHelpButton)
	ON_WM_TIMER()	
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	
    END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg message handlers

BOOL CDebugDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if (m_warnings)
	{
	   if (MessageBox("Before debugging an IO-56 card, it is\nrecommended that any attached IO-56\nextension be removed!\n\nDo you wish to continue?", 
	      "IO-56 Debug Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnOK();
		  return TRUE;
	   }
	}

	CRect CtrlBLocation(15,   5, 504, 137);
	ChipBCtrl.m_PinsStart = 9;
	ChipBCtrl.m_WindowTitle = _T("Harris CP8255B");
	ChipBCtrl.Create(IDD_8255CTRL_DIALOG, this);
	ChipBCtrl.MoveWindow(CtrlBLocation, TRUE);

	CRect CtrlALocation(15, 141, 504, 273);
	ChipACtrl.m_PinsStart = 33;
	ChipACtrl.m_WindowTitle = _T("Harris CP8255A");
	ChipACtrl.Create(IDD_8255CTRL_DIALOG, this);
	ChipACtrl.MoveWindow(CtrlALocation, TRUE);	
	
	CRect CtrlOutputBuffer(15, 277, 279, 349 );
	OutputBufferCtrl.m_PinsStart = 1;
	OutputBufferCtrl.m_WindowTitle = _T("Output Buffer");
	OutputBufferCtrl.Create(IDD_OUTPUTBUFFERCTRL_DIALOG, this);
	OutputBufferCtrl.MoveWindow(CtrlOutputBuffer, TRUE);
	
	return TRUE; 
}

void CDebugDlg::OnCancel() 
{
	KillTimer(1);
	
	CDialog::OnCancel();
}

void CDebugDlg::OnTimer(UINT nIDEvent) 
{
	PulseCard();
	
	CDialog::OnTimer(nIDEvent);
}

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg Command Buttons message handlers

void CDebugDlg::OnQuicktestButton() 
{
	CQuickTestDlg dlg;
	
	if (dlg.DoModal() == IDOK)
		OnOK();	
}

void CDebugDlg::OnDebugTestButton() 
{
	CDebugTestDlg dlg;
	
	if (dlg.DoModal() == IDOK)
		OnOK();
}

void CDebugDlg::OnPulseButton() 
{
	((CButton *)GetDlgItem(IDC_PULSE_BUTTON))->GetWindowText(m_buffer);

	if (m_buffer == _T("Pulse"))
	{
		PulseCard();
		return;
	}

	((CButton *)GetDlgItem(IDC_PULSE_BUTTON))->SetWindowText(_T("Pulse"));
	
	if (KillTimer(1))
	{
	   ChipACtrl.m_ReadOnly = FALSE;
	   ChipACtrl.UpdateDialog();

	   ChipBCtrl.m_ReadOnly = FALSE;
	   ChipBCtrl.UpdateDialog();

	   OutputBufferCtrl.m_ReadOnly = FALSE;
	   OutputBufferCtrl.UpdateDialog();

	   ((CButton *)GetDlgItem(IDC_QUICKTEST_BUTTON  ))->EnableWindow(TRUE);
	   ((CButton *)GetDlgItem(IDC_DEBUGTEST_BUTTON  ))->EnableWindow(TRUE);
	   ((CButton *)GetDlgItem(IDC_RESET_BUTTON      ))->EnableWindow(TRUE);
	   ((CButton *)GetDlgItem(IDC_PREFERENCES_BUTTON))->EnableWindow(TRUE);
	   ((CButton *)GetDlgItem(IDC_HELP_BUTTON       ))->EnableWindow(TRUE);
	   ((CButton *)GetDlgItem(IDC_MAINMENU_BUTTON   ))->EnableWindow(TRUE);
	}
}

void CDebugDlg::OnDoubleclickedPulseButton() 
{
	((CButton *)GetDlgItem(IDC_PULSE_BUTTON))->GetWindowText(m_buffer);

	if (m_buffer == _T("Stop!"))
		return;
	
	((CButton *)GetDlgItem(IDC_PULSE_BUTTON      ))->SetWindowText(_T("Stop!"));
	
	((CButton *)GetDlgItem(IDC_QUICKTEST_BUTTON  ))->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_DEBUGTEST_BUTTON  ))->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_RESET_BUTTON      ))->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_PREFERENCES_BUTTON))->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_HELP_BUTTON       ))->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_MAINMENU_BUTTON   ))->EnableWindow(FALSE);
	
	ChipACtrl.m_ReadOnly = TRUE;
	ChipACtrl.UpdateDialog();

	ChipBCtrl.m_ReadOnly = TRUE;
	ChipBCtrl.UpdateDialog();

	OutputBufferCtrl.m_ReadOnly = TRUE;
	OutputBufferCtrl.UpdateDialog();

	SetTimer(1, m_pulsatedelay, NULL);
}

void CDebugDlg::OnResetButton() 
{
	ChipACtrl.ResetControl();
	ChipBCtrl.ResetControl();
	
	OutputBufferCtrl.ResetControl();
}

void CDebugDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;
	dlg.DoModal();
}

void CDebugDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUDEBUGSYSTEM);
}

BOOL CDebugDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}


void CDebugDlg::OnMainmenuButton() 
{
	OnOK();
}

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg Custom Functions

void CDebugDlg::PulseCard()
{
	int AIn, BIn, CIn, CHIn, CLIn;
	int AValue, BValue, CValue, CHValue, CLValue;
	int portconfig;
	
	// ---> Chip A
	
	ChipACtrl.GetPorts(AIn, BIn, CIn, CHIn, CLIn);
	ChipACtrl.GetValues(AValue, BValue, CValue, CHValue, CLValue);
	
	portconfig = ( 0x80 | (AIn  ?  PA_in  :  PB_out)
		| (BIn  ?  PB_in  :  PB_out)
		| (CHIn ? PCh_in  : PCh_out)
		| (CLIn ? PCl_in  : PCl_out) );

	OUTPORT(A_8255_PROG, portconfig);

	if (AIn)
		AValue = INPORT(A_8255_PA);
	else
		OUTPORT(A_8255_PA, AValue);
		
	if (BIn)
		BValue = INPORT(A_8255_PB);
	else
		OUTPORT(A_8255_PB, BValue);

	if (CIn)
		CValue = INPORT(A_8255_PC);
	else
	{
		if (!CHIn && !CLIn)
			OUTPORT(A_8255_PC, CValue);
		else
		{
		   if (CHIn)
		   {
		      CHValue = INPORT(A_8255_PC);
			  CHValue &= 0xF0;
			  CHValue >>= 4;
		   }
		   else
		   {
			  CHValue <<= 4;
			  OUTPORT(A_8255_PC, CHValue);
			  CHValue >>= 4;
		   }

		   if (CLIn)
		   {
		      CLValue = INPORT(A_8255_PC);
			  CLValue &= 0x0F;
		   }
		   else
			  OUTPORT(A_8255_PC, CLValue);
		}
	}

	ChipACtrl.SetValues(AValue, BValue, CValue, CHValue, CLValue);
	
// ---> Chip B
	
	ChipBCtrl.GetPorts(AIn, BIn, CIn, CHIn, CLIn);
	ChipBCtrl.GetValues(AValue, BValue, CValue, CHValue, CLValue);
	
	portconfig = ( 0x80 | (AIn  ?  PA_in  :  PB_out)
		| (BIn  ?  PB_in  :  PB_out)
		| (CHIn ? PCh_in  : PCh_out)
		| (CLIn ? PCl_in  : PCl_out) );

	OUTPORT(B_8255_PROG, portconfig);

	if (AIn)
		AValue = INPORT(B_8255_PA);
	else
		OUTPORT(B_8255_PA, AValue);
		
	if (BIn)
		BValue = INPORT(B_8255_PB);
	else
		OUTPORT(B_8255_PB, BValue);

	if (CIn)
		CValue = INPORT(B_8255_PC);
	else
	{
		if (!CHIn && !CLIn)
			OUTPORT(B_8255_PC, CValue);
		else
		{
		   if (CHIn)
		   {
		      CHValue = INPORT(B_8255_PC);
			  CHValue &= 0xF0;
			  CHValue >>= 4;
		   }
		   else
		   {
			  CHValue <<= 4;
			  OUTPORT(B_8255_PC, CHValue);
			  CHValue >>= 4;
		   }

		   if (CLIn)
		   {
		      CLValue = INPORT(B_8255_PC);
			  CLValue &= 0x0F;
		   }
		   else
			  OUTPORT(B_8255_PC, CLValue);
		}
	}

	ChipBCtrl.SetValues(AValue, BValue, CValue, CHValue, CLValue);
	
	OUTPORT(BUFFER, OutputBufferCtrl.GetValue());
}



