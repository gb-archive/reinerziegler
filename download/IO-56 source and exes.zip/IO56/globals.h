// IO-56 For Windows Global Variables

extern int m_cardaddress;
extern int m_pulsatedelay;
extern int m_warnings;

#ifndef __IO56VARS
#define __IO56VARS

// Thead Messages

#define FINISHEDTHREADMESSAGE		WM_USER + 101
#define STARTEDTHREADMESSAGE		WM_USER + 102

// Help Identifiers

#define IDH_WINVERMAINMENU				19
#define IDH_WINVERMAINMENUPREFERENCES          	20
#define IDH_WINVERMAINMENUABOUT 			21
#define IDH_WINVERMAINMENUNES                  	23
#define IDH_WINVERMAINMENUNESADVANCEDREAD      	27
#define IDH_WINVERMAINMENUNESADVANCEDWRITE     	28
#define IDH_WINVERMAINMENUNESADVANCEDCHECKSUM  	29
#define IDH_WINVERMAINMENUNESADVANCEDSAVE      	30
#define IDH_WINVERMAINMENUSNES                 	34
#define IDH_WINVERMAINMENUGAMEBOY              	47
#define IDH_WINVERMAINMENUDEBUGSYSTEM          	58
#define IDH_WINVERMAINMENUDEBUGSYSTEMQUICKTEST 	59
#define IDH_WINVERMAINMENUDEBUGSYSTEMDEBUGTEST 	65

// Compatibility with DOS IO-56

#define OUTPORT		_outp
#define INPORT			_inp

#define A8255   		((0x300) + (0x10 * m_cardaddress))
#define B8255   		A8255 + 4

#define A_8255_PA    		A8255
#define A_8255_PB    		A8255 + 1
#define A_8255_PC    		A8255 + 2
#define A_8255_PROG  		A8255 + 3
#define B_8255_PA    		A8255 + 4
#define B_8255_PB    		A8255 + 5
#define B_8255_PC    		A8255 + 6
#define B_8255_PROG  		A8255 + 7

#define BUFFER       		A8255 + 8

#define PA_in			0x10
#define PA_out			0x00
#define PB_in			0x02
#define PB_out			0x00
#define PCl_in			0x01
#define PCl_out		0x00
#define PCh_in			0x08
#define PCh_out		0x00

#define SET_PC(bit)		(0x01|((bit&0x07)<<1))
#define CLR_PC(bit)		((bit&0x07)<<1)

#define TEST_REVERT_8(i)	(((i&0x01)<<7)|((i&0x02)<<5)|((i&0x04)<<3)|((i&0x08)<<1)| \
				 ((i&0x10)>>1)|((i&0x20)>>3)|((i&0x40)>>5)|((i&0x80)>>7))

#define TEST_REVERT_4(i)   	(((i&0x1)<<3)|((i&0x2)<<1)|((i&0x4)>>1)|((i&0x8)>>3))

static int test_patterns[] = {
	0xFF,
	0x00,
	-1
};

#endif
