// NESDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "NESDlg.h"
#include "NESChecksumDlg.h"
#include "NESAdvancedDlg.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNESDlg dialog

CNESDlg::CNESDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNESDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNESDlg)
	m_SaveFormat = 0;
	m_Verify = 0;
	//}}AFX_DATA_INIT
}

void CNESDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNESDlg)
	DDX_Radio(pDX, IDC_SAVEFORMATINES_CHECK, m_SaveFormat);
	DDX_Radio(pDX, IDC_VERIFYNONE_CHECK, m_Verify);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNESDlg, CDialog)
	//{{AFX_MSG_MAP(CNESDlg)
	ON_BN_CLICKED(IDC_ANALYZE_BUTTON,          OnAnalyzeButton)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON,      OnPreferencesButton)
	ON_BN_CLICKED(IDC_ADVANCED_BUTTON,         OnAdvancedButton)
	ON_BN_CLICKED(IDC_MAINMENU_BUTTON,         OnMainmenuButton)
	ON_BN_CLICKED(IDC_SAVE_BUTTON,             OnSaveButton)
	ON_BN_CLICKED(IDC_BROWSE_BUTTON,           OnNESFilenameBrowseButton)
	ON_BN_CLICKED(IDC_WRITEPRGCHR_BUTTON,      OnWriteprgchrButton)
	ON_BN_CLICKED(IDC_READPRGCHR_BUTTON,       OnReadprgchrButton)
	ON_BN_CLICKED(IDC_CHECKSUMPRGCHR_BUTTON,   OnChecksumprgchrButton)
	ON_BN_CLICKED(IDC_SAVEPRGCHR_BUTTON,       OnSaveprgchrButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON,             OnHelpButton)
	ON_BN_CLICKED(IDC_SAVEFORMATINES_CHECK,    UpdateDialog)
	ON_BN_CLICKED(IDC_SAVEFORMATRAW_CHECK,     UpdateDialog)
	ON_CBN_SELCHANGE(IDC_INESMM_COMBO,         OnSelchangeInesmmCombo)	
	ON_CBN_KILLFOCUS(IDC_CHARACTERBANKS_COMBO, OnKillfocusCharacterbanksCombo)
	ON_CBN_KILLFOCUS(IDC_PROGRAMBANKS_COMBO,   OnKillfocusProgrambanksCombo)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FINISHEDTHREADMESSAGE, OnThreadFinished)
	ON_MESSAGE(STARTEDTHREADMESSAGE,  OnThreadStarted)

	ON_EN_CHANGE(IDC_NESFILENAME_EDIT, UpdateDialog)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Threads

UINT NESAnalyzeThread(LPVOID pParam)
{
	CNESDlg *pDlg = (CNESDlg *)pParam;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 1L);
	pDlg->nes_analyze();
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 1L);

	return 0;
}

UINT NESSaveThread(LPVOID pParam)
{
	CNESDlg *pDlg = (CNESDlg *)pParam;

	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 2L);

	CheckFileExtension(IDC_NESFILENAME_EDIT, _T("nes"), filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
		buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", filename);

		pDlg->MessageBox(buffer, "IO-56 NES File Error!", MB_ICONSTOP | MB_OK);
		pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
		return 0;
	}
	
	pDlg->nes_save(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 2L);

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Thread Message Handlers

long CNESDlg::OnThreadStarted(WPARAM wParam, LPARAM lParam)
{
	((CEdit *)GetDlgItem(IDC_NESSTATISTICS_EDIT))->SetWindowText(_T(""));
	((CEdit *)GetDlgItem(IDC_NESSTATUS_EDIT    ))->SetWindowText(_T(""));

	fp = NULL;

	m_buffer.Format(_T("-------- %s started at %s --------\r\n\r\n"), 
			GetOperation(lParam), GetTime());
		
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
	
	return(0L);
}

long CNESDlg::OnThreadFinished(WPARAM wParam, LPARAM lParam)
{
	switch (lParam)
	{
		case 1:          m_Analyzing = FALSE; break;
		case 2:	            m_Saving = FALSE; break;
	}

	if (fp)
		fclose(fp);

	if (wParam)
	{
		if (dwExitCode)
		   TerminateThread(pThread->m_hThread, dwExitCode);

		dwExitCode = 0;

		m_buffer.Format(_T("\r\n\r\n-------- %s terminated at %s --------\r\n\r\n"), 
			GetOperation(lParam), GetTime());	
	}
	else
	{
		m_buffer.Format(_T("\r\n-------- %s finished at %s --------\r\n"),
		GetOperation(lParam), GetTime()); 
	}

	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		
	UpdateDialog();

	return (0L);
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Custom Functions

CString CNESDlg::GetOperation(LPARAM lParam)
{
	CString buffer;

	switch (lParam)
	{
		case 1: buffer = _T("Analyzing");             break;
		case 2:	buffer = _T("Saving");                break;
	}

	return(buffer);
}

void CNESDlg::UpdateDialog()
{
	UpdateData(TRUE);
	
	SetDlgItemText(IDC_ADVANCED_BUTTON, m_Advanced  ? "Standard" : "Advanced");
	SetDlgItemText(IDC_SAVE_BUTTON,     m_Saving    ? "Stop"     : "Save"    );
	SetDlgItemText(IDC_ANALYZE_BUTTON,  m_Analyzing ? "Stop"     : "Analyze" );

	int operation = (m_Advanced) ? SW_SHOW : SW_HIDE;

	((CButton*)GetDlgItem(IDC_READPRGCHR_BUTTON    ))->ShowWindow(operation);
	((CButton*)GetDlgItem(IDC_WRITEPRGCHR_BUTTON   ))->ShowWindow(operation);
	((CButton*)GetDlgItem(IDC_CHECKSUMPRGCHR_BUTTON))->ShowWindow(operation);
	((CButton*)GetDlgItem(IDC_SAVEPRGCHR_BUTTON    ))->ShowWindow(operation);
	
	operation = (m_Saving || m_Analyzing) ? FALSE : TRUE;

	((CStatic*  )GetDlgItem(IDC_MMC_STATIC             ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_PREFERENCES_BUTTON     ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_HELP_BUTTON            ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_MAINMENU_BUTTON        ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_ADVANCED_BUTTON        ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_READPRGCHR_BUTTON      ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_WRITEPRGCHR_BUTTON     ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_CHECKSUMPRGCHR_BUTTON  ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_SAVEPRGCHR_BUTTON      ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_VERIFYNONE_CHECK       ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_VERIFY_CHECK           ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_VERIFYX2_CHECK         ))->EnableWindow(operation);
	((CEdit*    )GetDlgItem(IDC_NESFILENAME_EDIT       ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_SAVEFORMATINES_CHECK   ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_SAVEFORMATRAW_CHECK    ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_BROWSE_BUTTON          ))->EnableWindow(operation);
	((CButton*  )GetDlgItem(IDC_ANALYZE_BUTTON         ))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDC_512KTRAINER_CHECK      ))->EnableWindow(operation && !m_SaveFormat);
	((CButton*  )GetDlgItem(IDC_BATTERYRAM_CHECK       ))->EnableWindow(operation && !m_SaveFormat);
	((CButton*  )GetDlgItem(IDC_FOURSCREENVRAM_CHECK   ))->EnableWindow(operation && !m_SaveFormat);
	((CComboBox*)GetDlgItem(IDC_MIRRORING_COMBO        ))->EnableWindow(operation && !m_SaveFormat);
	((CComboBox*)GetDlgItem(IDC_PROGRAMBANKS_COMBO     ))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_CHARACTERBANKS_COMBO   ))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_PROGRAMBANKSIZE_COMBO  ))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_CHARACTERBANKSIZE_COMBO))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_VIDEOMEMORY_COMBO      ))->EnableWindow(operation);
	((CComboBox*)GetDlgItem(IDC_INESMM_COMBO           ))->EnableWindow(operation);
	
	GetDlgItemText(IDC_NESFILENAME_EDIT, m_buffer);
	((CButton *)GetDlgItem(IDC_SAVE_BUTTON             ))->
		EnableWindow(!m_buffer.IsEmpty() && !m_Analyzing);
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Message Handlers 

BOOL CNESDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if (m_warnings)
	{
	   if (MessageBox("Before dumping a NES cartridge,\nplease attach the NES extension!\n\nDo you wish to continue?", 
	      "IO-56 NES Warning!", MB_ICONEXCLAMATION | MB_YESNO) == IDNO)
	   {
		  OnOK();
		  return TRUE;
	   }
	}

	m_Advanced = m_Saving = m_Analyzing = FALSE;

	dwExitCode = 0;
	fp = NULL;

	((CComboBox *)GetDlgItem(IDC_INESMM_COMBO           ))->SetCurSel(1);
	((CComboBox *)GetDlgItem(IDC_PROGRAMBANKS_COMBO     ))->SetCurSel(0);
	((CComboBox *)GetDlgItem(IDC_CHARACTERBANKS_COMBO   ))->SetCurSel(0);
	((CComboBox *)GetDlgItem(IDC_VIDEOMEMORY_COMBO      ))->SetCurSel(1);
	((CComboBox *)GetDlgItem(IDC_MIRRORING_COMBO        ))->SetCurSel(1);
	((CComboBox *)GetDlgItem(IDC_PROGRAMBANKSIZE_COMBO  ))->SetCurSel(2);
	((CComboBox *)GetDlgItem(IDC_CHARACTERBANKSIZE_COMBO))->SetCurSel(2);
	((CButton   *)GetDlgItem(IDC_SAVE_BUTTON            ))->EnableWindow(FALSE);

	OnSelchangeInesmmCombo();

	UpdateDialog();

	return TRUE;  
}

void CNESDlg::OnSelchangeInesmmCombo() 
{
	GetDlgItemText(IDC_INESMM_COMBO, m_buffer);

	int mapper = atoi(m_buffer);

	switch (mapper)
	{
		case  0: m_buffer = "No Memory Mapper";                      break;
		case  1: m_buffer = "MMC1\n(Megaman 2)";                     break;
		case  2: m_buffer = "74HC161/74HC32\n(Konami)";              break;
		case  3: m_buffer = "VROM Switch\n(Goonies)";                break;
		case  4: m_buffer = "MMC4\n(Tecmo Super Bowl)";              break;
		case  5: m_buffer = "MMC5\n(Castlevania III)";               break;
		case  6: m_buffer = "FFE F4xxx\n(Konami World)";             break;
		case  7: m_buffer = "ROM Switch\n(Deadly Towers)";           break;
		case  8: m_buffer = "FFE F3xxx\n(No Information)";           break;
		case  9: m_buffer = "MMC2\n(Punchout!)";                     break;
		case 10: m_buffer = "MMC4\n(Japeneese Punchout!)";           break;
		case 11: m_buffer = "Color Dreams\n(Crystal Mines)";         break;
		case 12: m_buffer = "FFE F6xxx\n(No Information)";           break;  
		case 15: m_buffer = "100-in-1\n(No Information)";            break;
		case 16: m_buffer = "Bandai\n(No Information)";              break;			
		case 17: m_buffer = "FFE F8xxx\n(No Information)";           break;
		case 18: m_buffer = "Jaleco SS8806\n(No Information)";       break;
		case 19: m_buffer = "Namcot 106\n(No Information)";          break;
		case 21: m_buffer = "Konami VRC4\n(No Information)";         break;
		case 22: m_buffer = "Konami VRC2 #1\n(No Information)";      break;
		case 23: m_buffer = "Konami VRC2 #2\n(No Information)";      break;
		case 24: m_buffer = "Konami VRC6\n(No Information)";         break;
		case 32: m_buffer = "Irem G-101\n(No Information)";          break;
		case 33: m_buffer = "Taito TC0190/TC0350\n(No Information)"; break;
		default: m_buffer = "Unknown";				 break;
	}

	((CStatic *)GetDlgItem(IDC_MMC_STATIC))->SetWindowText(m_buffer);
}


void CNESDlg::OnKillfocusCharacterbanksCombo() 
{
	GetDlgItemText(IDC_CHARACTERBANKS_COMBO, m_buffer);
	
	if (m_buffer.IsEmpty())
		SetDlgItemText(IDC_CHARACTERBANKS_COMBO, "??");
	else
	{			
		if (m_buffer == "?")
			SetDlgItemText(IDC_CHARACTERBANKS_COMBO, "??");
		else
		if (m_buffer != "??")
		{
			nes.nb_chr = atoi(m_buffer);
			SetDlgItemInt(IDC_CHARACTERBANKS_COMBO, nes.nb_chr, FALSE);
		}
	}
}

void CNESDlg::OnKillfocusProgrambanksCombo() 
{
	GetDlgItemText(IDC_PROGRAMBANKS_COMBO, m_buffer);
	
	if (m_buffer.IsEmpty())
		SetDlgItemText(IDC_PROGRAMBANKS_COMBO, "??");
	else
	{			
		if (m_buffer == "?")
			SetDlgItemText(IDC_PROGRAMBANKS_COMBO, "??");
		else
		if (m_buffer != "??")
		{
			nes.nb_prg = atoi(m_buffer);
			SetDlgItemInt(IDC_PROGRAMBANKS_COMBO, nes.nb_prg, FALSE);
		}
	}
}

void CNESDlg::OnCancel() 
{
	if (!m_Saving && !m_Analyzing)
		CDialog::OnCancel();
	else
		::Beep((DWORD)-1, (DWORD)-1);
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Command Button message handlers

void CNESDlg::OnSaveButton() 
{	
	if (m_Saving)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
		return;
	}
			
	GetDlgItemText(IDC_INESMM_COMBO, m_buffer);
	nes.type = atoi(m_buffer);
   
	switch(nes.type)
	{
	   case 0: case 1:
	   case 2: case 3:
	   case 4: case 7: break;

	   default: m_buffer.Format("\r\n\r\niNES Memory Mapper #%d Not Supported Yet!",nes.type);
				AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
				return;
	}

	m_Saving = TRUE;
	
	UpdateDialog();
	   
	pThread = AfxBeginThread(NESSaveThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}

void CNESDlg::OnAnalyzeButton() 
{
	if (m_Analyzing)
	{
		SendMessage(FINISHEDTHREADMESSAGE, 1, 1L);
		return;
	}

	UpdateDialog();
		
	GetDlgItemText(IDC_INESMM_COMBO, m_buffer);
	nes.type = atoi(m_buffer);
	 
	switch(nes.type)
	{
	   case 0: case 1:
	   case 2: case 3:
	   case 4: case 7: break;

	   default: m_buffer.Format("\r\n\r\niNES Memory Mapper #%d Not Supported Yet!",nes.type);
	   	    AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		    return;
	}

	m_Analyzing = TRUE;

	UpdateDialog();
	   
	pThread = AfxBeginThread(NESAnalyzeThread, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED);
	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
	pThread->ResumeThread();
}
	
void CNESDlg::OnAdvancedButton() 
{
	CRect EditBoxRect;
	
	m_Advanced = !m_Advanced;

	((CEdit *)GetDlgItem(IDC_NESSTATISTICS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_NESSTATISTICS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	((CEdit *)GetDlgItem(IDC_NESSTATUS_EDIT))->GetWindowRect(&EditBoxRect);
	ScreenToClient(EditBoxRect);
	EditBoxRect.bottom += (-32 * m_Advanced) + (32 * !m_Advanced);
	((CEdit *)GetDlgItem(IDC_NESSTATUS_EDIT))->MoveWindow(EditBoxRect, TRUE);

	UpdateDialog();
}

void CNESDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;

	dlg.DoModal();	
}

void CNESDlg::OnHelpButton() 
{
	WinHelp(IDH_WINVERMAINMENUNES);
}

BOOL CNESDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

void CNESDlg::OnMainmenuButton() 
{
	CDialog::OnOK();	
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Browse Button message handlers

void CNESDlg::OnNESFilenameBrowseButton() 
{
	BrowseForFile(IDC_NESFILENAME_EDIT,
		_T("NESCart"), _T("nes"), _T("NES Cartridge"),
		_T("Enter NES Cartridge Image Filename"), this);

	UpdateDialog();
}

/////////////////////////////////////////////////////////////////////////////
// CNESDlg Advanced Button message handlers

void CNESDlg::OnReadprgchrButton() 
{
	CNESAdvancedDlg dlg;

	dlg.m_mode = 2;
	dlg.DoModal();
}

void CNESDlg::OnWriteprgchrButton() 
{
	CNESAdvancedDlg dlg;

	dlg.m_mode = 1;
	dlg.DoModal();
}

void CNESDlg::OnChecksumprgchrButton() 
{
	CNESChecksumDlg dlg;
	
	int tempVerify = m_Verify;
	
	m_Verify = 0;

	dlg.DoModal();

	m_Verify = tempVerify;
}

void CNESDlg::OnSaveprgchrButton() 
{
	CNESAdvancedDlg dlg;

	dlg.m_mode = 3;
	dlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CSNESDlg IO-56 NES.H Routines

void CNESDlg::nes_init()
{
	OUTPORT(B_8255_PROG, 0x80|PA_in|PB_in|PCl_out|PCh_out);
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_in|PCh_in);
	NES_IDLE;
}

void CNESDlg::nes_read_info()
{
	nes_switch_init();
	
	if (nes.nb_prg < 0)
		nes_count_prg_banks();

	if (nes.prg_bank_size < 0)
		nes_find_prg_bank_size();

	if (nes.nb_chr < 0)
		nes_count_chr_banks();

	if (nes.chr_bank_size < 0)
		nes_find_chr_bank_size();

	if (nes.has_vram < 0)
		nes_test_vram();		
}

void CNESDlg::nes_analyze()
{
	nes_init();

	GetDlgItemText(IDC_INESMM_COMBO, m_buffer);
	nes.type = atoi(m_buffer);
	
	GetDlgItemText(IDC_PROGRAMBANKS_COMBO, m_buffer);
	
	if (m_buffer == "??")
		nes.nb_prg = -1;
	else
		nes.nb_prg = atoi(m_buffer);

	GetDlgItemText(IDC_PROGRAMBANKSIZE_COMBO, m_buffer);
	
	if (m_buffer == "??")
		nes.prg_bank_size = -1;
	else
		nes.prg_bank_size = atoi(m_buffer);

	GetDlgItemText(IDC_CHARACTERBANKS_COMBO, m_buffer);
	
	if (m_buffer == "??")
		nes.nb_chr = -1;
	else
		nes.nb_chr = atoi(m_buffer);

	GetDlgItemText(IDC_CHARACTERBANKSIZE_COMBO, m_buffer);
	
	if (m_buffer == "??")
		nes.chr_bank_size = -1;
	else
		nes.chr_bank_size = atoi(m_buffer);

	GetDlgItemText(IDC_VIDEOMEMORY_COMBO, m_buffer);
	
	if (m_buffer == "   ?????")
		nes.has_vram = -1;
	else
	if (m_buffer == "   VRAM")
		nes.has_vram = 1;
	else
		nes.has_vram = 0;

	nes_read_info();
	
	m_buffer.Format("iNES Memory Mapper: %d\r\n", nes.type);
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("Number Of Program Banks: %d\r\n", nes.nb_prg);
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("Size Of Program Banks: %d\r\n", nes.prg_bank_size);
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("Number Of Character Banks: %d\r\n", nes.nb_chr);
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("Size Of Character Banks: %d\r\n", nes.chr_bank_size);
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);

	m_buffer.Format("Type Of Character Banks: %s\r\n", nes.has_vram ? "VRAM" : "VROM");
	AddToEditBox(IDC_NESSTATISTICS_EDIT, m_buffer, this);
}

void CNESDlg::nes_save(FILE *fp) 
{	
	nes_analyze();
	
	if (m_SaveFormat)
	{
		nes_read_prg(fp);
		if (!nes.has_vram)
			nes_read_chr(fp);
	}
	else
	{
		unsigned char hdr[16];

		memset(hdr, 0, 16);
		strcpy((char*) hdr, "NES\032");

		hdr[4] = (unsigned char)((nes.nb_prg*nes.prg_bank_size)>>4);

		if (nes.has_vram)
			hdr[5]=0;
		else
			hdr[5] = (unsigned char)((nes.nb_chr*nes.chr_bank_size)>>3);
		
		hdr[6] = (unsigned char)(nes.type<<4);
		
		if (IsDlgButtonChecked(IDC_BATTERYRAM_CHECK))
			hdr[6] |= 0x02;

		if (IsDlgButtonChecked(IDC_FOURSCREENVRAM_CHECK))
			hdr[6] |= 0x08;

		GetDlgItemText(IDC_MIRRORING_COMBO, m_buffer);
		
		if (m_buffer == "  Vertical")
			hdr[6] |= 0x01;

		if (IsDlgButtonChecked(IDC_512KTRAINER_CHECK))
			hdr[6] |= 0x04;
		
		fwrite(hdr, 16, 1, fp);

		if (IsDlgButtonChecked(IDC_512KTRAINER_CHECK))
		   for (int loop = 0; loop < 512; loop++)
				if (fputc(0,fp) == EOF)
		        {
					GetDlgItemText(IDC_NESFILENAME_EDIT, m_filename);
					m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename);
			
					MessageBox(m_buffer, "IO-56 NES File Error!", MB_ICONSTOP | MB_OK);

					SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
				}
		
		nes_read_prg(fp);
		
		if(!nes.has_vram)
			nes_read_chr(fp);
	}

	fclose(fp);
} 

inline int CNESDlg::nes_read_byte(register unsigned int addr, int mem)
{
	register int i;

	OUTPORT(A_8255_PB, addr>>8);
	OUTPORT(A_8255_PA, addr&0xFF);
	i = INPORT(mem == NES_PRG ? A_8255_PC : B_8255_PB);
	if(m_Verify >= 2) {
		::Sleep(m_pulsatedelay);
		if(i != INPORT(mem == NES_PRG ? A_8255_PC : B_8255_PB)) {
			m_buffer.Format("\r\n\r\nError reading address 0x%06X\r\n", addr);
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			
			SendMessage(FINISHEDTHREADMESSAGE, 1, (m_Analyzing) ? 1L : 2L);

			//exit(1);
		}
	}
	return i;
}

unsigned int CNESDlg::nes_checksum(unsigned int start, unsigned int length, int mem)
{
	unsigned int chk = 0;
	unsigned int i, max;

	if(mem == NES_PRG) {
		NES_READ_PRG;
	} else if(mem == NES_CHR) {
		NES_READ_CHR;
	}

	max = start+length;
	for(i = start; i < max; i++)
		chk += nes_read_byte(i, mem);
	if(m_Verify >= 1) {
		unsigned int chk2 = 0;
		for(i = start; i < max; i++)
			chk2 += nes_read_byte(i, mem);
		if(chk != chk2) {
			
			m_buffer.Format("\r\n\r\nError while verifying checksum:\r\n1st checksum = 0x%06X - 2nd checksum = 0x%06X\r\n", chk, chk2);
			
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			
			SendMessage(FINISHEDTHREADMESSAGE, 1, (m_Analyzing) ? 1L : 2L);

			//exit(1);
		}
	}
	return chk;
}

void CNESDlg::nes_switch_init()
{
	switch(nes.type) {
	case 1:
		/* Reset registers */
		NES_WR_PRG(0x87, 0x9FFF);
		NES_WR_PRG(0x00, 0xBFFF);
		NES_WR_PRG(0x21, 0xDFFF);
		NES_WR_PRG(0xC8, 0xFFFF);
		/* Set CHR pages to 4kB */
		NES_WR_PRG(0x1E, 0x9FFF);
		NES_WR_PRG(0x0F, 0x9FFF);
		NES_WR_PRG(0x07, 0x9FFF);
		NES_WR_PRG(0x03, 0x9FFF);
		NES_WR_PRG(0x01, 0x9FFF);
		break;
	}
}

void CNESDlg::nes_switch_bank(int bank, int mem)
{
	switch(nes.type) {
	case 1:
		/* 16kB PRG banks switched at 0x8000
		 *
		 * 8kB of CHR banks switched at 0x0000
		 *  or
		 * 2x4kB of CHR banks switched separately at 0x0000 and 0x1000
		 */
		if(mem == NES_PRG) {
			NES_WR_PRG(bank, 0xFFFF);
			NES_WR_PRG(bank>>1, 0xFFFF);
			NES_WR_PRG(bank>>2, 0xFFFF);
			NES_WR_PRG(bank>>3, 0xFFFF);
			NES_WR_PRG(bank>>4, 0xFFFF);
		} else if(mem == NES_CHR) {
			NES_WR_PRG(bank, 0xBFFF);
			NES_WR_PRG(bank>>1, 0xBFFF);
			NES_WR_PRG(bank>>2, 0xBFFF);
			NES_WR_PRG(bank>>3, 0xBFFF);
			NES_WR_PRG(bank>>4, 0xBFFF);
			NES_WR_PRG(bank, 0xDFFF);
			NES_WR_PRG(bank>>1, 0xDFFF);
			NES_WR_PRG(bank>>2, 0xDFFF);
			NES_WR_PRG(bank>>3, 0xDFFF);
			NES_WR_PRG(bank>>4, 0xDFFF);
		}
		break;
	case 2:
		/* 16kB PRG banks switched at 0x8000
		 *
		 * No CHR switch
		 */
		if(mem == NES_PRG) {
			unsigned int addr;
			/* Find address where value == bank (avoid bus conflict) */
			NES_READ_PRG;
			for(addr = 0xC000; addr <= 0xFFFF; addr++) {
				if(nes_read_byte(addr, mem) == bank) {
					
					m_buffer.Format("%06X <- %d\r\n", addr, bank);
					AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

					NES_WR_PRG(bank, addr);
					break;
				}
			}
		}
		break;
	case 3:
		/* No PRG switch
		 *
		 * 8kB of CHR banks switched at 0x0000
		 */
		if(mem == NES_CHR) {
			NES_WR_PRG(bank, 0x8000);
		}
		break;
	case 4:
		/* 2x8kB PRG banks switched at 0x8000 and 0xA000
		 *
		 * 2x2kB of CHR banks switched separately at 0x0000 and 0x0800
		 *  or
		 * 4x1kB of CHR banks switched separately at 0x0000, 0x0400, 0x0800, and 0x0C00
		 */
		if(mem == NES_PRG) {
			NES_WR_PRG(6, 0x8000);
			NES_WR_PRG(bank<<1, 0x8000+1);
			NES_WR_PRG(7, 0x8000);
			NES_WR_PRG((bank<<1)+1, 0x8000+1);
		} else if(mem == NES_CHR) {
			NES_WR_PRG(0x00, 0x8000);
			NES_WR_PRG(bank<<3, 0x8000+1);
			NES_WR_PRG(0x01, 0x8000);
			NES_WR_PRG((bank<<3)+2, 0x8000+1);
			NES_WR_PRG(0x02, 0x8000);
			NES_WR_PRG((bank<<3)+4, 0x8000+1);
			NES_WR_PRG(0x03, 0x8000);
			NES_WR_PRG((bank<<3)+5, 0x8000+1);
			NES_WR_PRG(0x04, 0x8000);
			NES_WR_PRG((bank<<3)+6, 0x8000+1);
			NES_WR_PRG(0x05, 0x8000);
			NES_WR_PRG((bank<<3)+7, 0x8000+1);
		}
		break;
	case 7:
		/* 32kB PRG banks switched at 0x8000
		 *
		 * No CHR switch
		 */
		if(mem == NES_PRG) {
			NES_WR_PRG(bank, 0x8000+bank);
		}
		break;
	}
	if(mem == NES_PRG) {
		NES_READ_PRG;
	} else if(mem == NES_CHR) {
		NES_READ_CHR;
	}
}

void CNESDlg::nes_count_prg_banks()
{
	int bank;
	unsigned int first, last, chk;

	if(nes.type == 0) {
		nes.nb_prg = 1;
		return;
	}
	for(bank = 0; bank < MAXBANKS; bank++) {
		nes_switch_bank(bank, NES_PRG);
		
		m_buffer.Format("Testing program bank %03d...", bank);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		
		chk = nes_checksum(0x0000, 0x4000, NES_PRG);

		m_buffer.Format(" (%06X)\r\n", chk);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

		if(bank == 0)
			first = last = chk;
		else {
			if(chk == first || chk == last) {
				nes.nb_prg = bank;
				break;
			}
			last = chk;
		}
	}
	if(bank == MAXBANKS)
		nes.nb_prg = 0;

	AddToEditBox(IDC_NESSTATUS_EDIT, "\r\n", this);
}

void CNESDlg::nes_count_chr_banks()
{
	int bank;
	unsigned int first, last, chk;

	if(nes.type == 0) {
		nes.nb_chr = 1;
		return;
	}

	for(bank = 0; bank < MAXBANKS; bank++) {
		nes_switch_bank(bank, NES_CHR);
		
		m_buffer.Format("Testing character bank %03d...", bank);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

		chk = nes_checksum(0x0000, 0x2000, NES_CHR);
		
		m_buffer.Format(" (%06X)\r\n", chk);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

		if(bank == 0)
			first = last = chk;
		else {
			if(chk == first || chk == last) {
				nes.nb_chr = bank;
				break;
			}
			last = chk;
		}
	}
	if(bank == MAXBANKS)
		nes.nb_chr = 0;

	AddToEditBox(IDC_NESSTATUS_EDIT, "\r\n", this);
}

void CNESDlg::nes_test_vram()
{
	int i;

	nes_switch_bank(0, NES_CHR);

	OUTPORT(A_8255_PB, 0x00);
	OUTPORT(A_8255_PA, 0x00);
	i = INPORT(B_8255_PB);

	NES_WR_CHR(0x00, 0x0000);
	if(INPORT(B_8255_PB) != 0x00) {
		nes.has_vram = 0;
		return;
	}

	NES_WR_CHR(0xFF, 0x0000);
	if(INPORT(B_8255_PB) != 0xFF) {
		nes.has_vram = 0;
		return;
	}

	NES_WR_CHR(i, 0x0000);
	nes.has_vram = 1;
}

void CNESDlg::nes_find_prg_bank_size()
{
	/* 16kB or 32kB */
	if(nes.type == 0) {
		unsigned int chk1, chk2;
		chk1 = nes_checksum(0x0000, 0x4000, NES_PRG);
		chk2 = nes_checksum(0x4000, 0x4000, NES_PRG);
		if(chk1 == chk2)
			nes.prg_bank_size = 16;
		else
			nes.prg_bank_size = 32;
	} else if(nes.type == 1) {
		/* Some games only use the MMC for CHR, and have 1*32kB PRG */
		if(nes.nb_prg == 1) {
			unsigned int chk1, chk2;
			chk1 = nes_checksum(0x0000, 0x4000, NES_PRG);
			chk2 = nes_checksum(0x4000, 0x4000, NES_PRG);
			if(chk1 == chk2)
				nes.prg_bank_size = 16;
			else
				nes.prg_bank_size = 32;
		} else
			nes.prg_bank_size = 16;
	} else if(nes.type == 7)
		nes.prg_bank_size = 32;
	else
		nes.prg_bank_size = 16;
}

void CNESDlg::nes_find_chr_bank_size()
{
	/* 4kB or 8kB */
	if(nes.type == 1)
		nes.chr_bank_size = 4;
	else
		nes.chr_bank_size = 8;
}

void CNESDlg::nes_read_prg(FILE *fp)
{
	int bank, i;
	unsigned int addr, chk;
	unsigned int banksize;

	banksize = nes.prg_bank_size<<10;

	for(bank = 0; bank < nes.nb_prg; bank++) {
		m_buffer.Format("Reading PRG bank %03d ", bank);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		nes_switch_bank(bank, NES_PRG);
		chk = 0;
		for(addr = 0x0000; addr < banksize; addr++) {
			if((addr&0xFF) == 0) {
				m_buffer.Format(".");
				AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			}
			
			i = nes_read_byte(addr, NES_PRG);
			chk += i;
			if (fputc(i, fp) == EOF)
			{
			   m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		       
			   MessageBox(m_buffer,"IO-56 NES File Error!", MB_ICONSTOP | MB_OK);

			   SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
			}
			
		}
		m_buffer.Format(" (%06X)\r\n", chk);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		if(m_Verify >= 1) {
			unsigned int chk2 = 0;
			m_buffer.Format("Verifying bank %03d\r\n", bank);
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

			for(addr = 0x0000; addr < banksize; addr++) {
				if((addr&0xFF) == 0) {
					m_buffer.Format(".");
					AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);					
				}
				chk2 += nes_read_byte(addr, NES_PRG);
			}
			
			m_buffer.Format(" (%06X)\r\n", chk2);
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			if(chk != chk2) {
			m_buffer.Format("\r\n\r\nError while verifying:\r\n1st checksum = 0x%06X - 2nd checksum = 0x%06X\r\n", chk, chk2);
			
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);

			SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);

			//	exit(1);
			}
		}
	}
}

void CNESDlg::nes_read_chr(FILE *fp)
{
	int bank, i;
	unsigned int addr, chk;
	unsigned int banksize;

	banksize = nes.chr_bank_size<<10;

	for(bank = 0; bank < nes.nb_chr; bank++) {
		m_buffer.Format("Reading CHR bank %03d ", bank);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		nes_switch_bank(bank, NES_CHR);
		chk = 0;
		for(addr = 0x0000; addr < banksize; addr++) {
			if((addr&0xFF) == 0) {
				m_buffer.Format(".");
				AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			}
			i = nes_read_byte(addr, NES_CHR);
			chk += i;
			if (fputc(i, fp) == EOF)
			{
			   m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		       
			   MessageBox(m_buffer,"IO-56 NES File Error!", MB_ICONSTOP | MB_OK);

			   SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
			}
		}
		m_buffer.Format(" (%06X)\r\n", chk);
		AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
		if(m_Verify >= 1) {
			unsigned int chk2 = 0;
			m_buffer.Format("Verifying bank %03d\r\n", bank);
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			for(addr = 0x0000; addr < banksize; addr++) {
				if((addr&0xFF) == 0) {
					m_buffer.Format(".");
					AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
				}
				chk2 += nes_read_byte(addr, NES_CHR);
			}
			m_buffer.Format(" (%06X)\r\n", chk2);
			AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, this);
			if(chk != chk2) {
				m_buffer.Format("\r\n\r\nError while verifying:\r\n1st checksum = 0x%06X - 2nd checksum = 0x%06X\r\n", chk, chk2);
				
				SendMessage(FINISHEDTHREADMESSAGE, 1, 2L);
							
				//exit(1);
			}
		}
	}
}


