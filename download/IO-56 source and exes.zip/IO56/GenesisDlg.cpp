// GenesisDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56.h"
#include "GenesisDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGenesisDlg dialog

CGenesisDlg::CGenesisDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGenesisDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGenesisDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CGenesisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGenesisDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGenesisDlg, CDialog)
	//{{AFX_MSG_MAP(CGenesisDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGenesisDlg message handlers
