// NESChecksumDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNESChecksumDlg dialog

class CNESChecksumDlg : public CDialog
{
// Construction
public:
	CNESChecksumDlg(CWnd* pParent = NULL);   // standard constructor

	CString m_buffer;
	HICON m_hIcon;

// Dialog Data
	//{{AFX_DATA(CNESChecksumDlg)
	enum { IDD = IDD_NESCHECKSUM_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNESChecksumDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNESChecksumDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnProgrambanksButton();
	afx_msg void OnCharacterbanksButton();
	afx_msg void OnHelpButton();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnPreferencesButton();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
