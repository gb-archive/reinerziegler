// IO568255Ctrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIO568255Ctrl dialog

class CIO568255Ctrl : public CDialog
{
// Construction
public:
	CIO568255Ctrl(CWnd* pParent = NULL);   // standard constructor

	CString m_buffer, m_WindowTitle;
	int m_PinsStart;
	
	BOOL m_ReadOnly;

	void SetValues(int A, int B, int C, int CH, int CL);
	void GetValues(int& A, int& B, int& C, int& CH, int& CL);

	void SetPorts(int A, int B, int C, int CH, int CL);
	void GetPorts(int& A, int& B, int& C, int& CH, int& CL);
	
	void ResetControl();
	void UpdateDialog();

	void ConvertDECToBIN();
	void ConvertDECToHEX();
	void ConvertHEXToDEC();
	void ConvertBINToDEC();

// Dialog Data
	//{{AFX_DATA(CIO568255Ctrl)
	enum { IDD = IDD_8255CTRL_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIO568255Ctrl)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CIO568255Ctrl)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	virtual void OnCancel();
	virtual void BINChanged();
	virtual void DECChanged();
	virtual void HEXChanged();
	virtual void InOutChanged();
	virtual void BINLostFocus();
	virtual void DECLostFocus();
	virtual void HEXLostFocus();
	
	DECLARE_MESSAGE_MAP()
};


