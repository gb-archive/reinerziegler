// NESAdvancedDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IO56Functions.h"
#include "IO56.h"
#include "NESDlg.h"
#include "NESAdvancedDlg.h"
#include "PreferencesDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg dialog

CNESAdvancedDlg::CNESAdvancedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNESAdvancedDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNESAdvancedDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CNESAdvancedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNESAdvancedDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNESAdvancedDlg, CDialog)
	//{{AFX_MSG_MAP(CNESAdvancedDlg)
	ON_BN_CLICKED(IDC_PREFERENCES_BUTTON,      OnPreferencesButton)
	ON_BN_CLICKED(IDC_BROWSE_BUTTON,           OnNESAdvancedBrowseButton)
	ON_BN_CLICKED(IDC_COMMAND_BUTTON,          OnCommandButton)
	ON_BN_CLICKED(IDC_HELP_BUTTON,             OnHelpButton)
	ON_EN_CHANGE(IDC_NESADVANCEDFILENAME_EDIT, OnChangeFilenameEdit)
	ON_EN_CHANGE(IDC_VALUE_EDIT,               OnChangeValueEdit)
	ON_EN_CHANGE(IDC_ADDRESS_EDIT,             OnChangeAddressEdit)
	ON_EN_KILLFOCUS(IDC_ADDRESS_EDIT,          OnKillfocusAddressEdit)
	ON_EN_KILLFOCUS(IDC_VALUE_EDIT,            OnKillfocusValueEdit)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
	ON_MESSAGE(FINISHEDTHREADMESSAGE, OnThreadFinished)
	ON_MESSAGE(STARTEDTHREADMESSAGE,  OnThreadStarted)
	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg Threads

UINT NESAdvancedSaveThread(LPVOID pParam)
{
	CNESAdvancedDlg *pDlg = (CNESAdvancedDlg *)pParam;

	CString filename, buffer;

	pDlg->SendMessage(STARTEDTHREADMESSAGE, 0, 1L);

	CheckFileExtension(IDC_NESADVANCEDFILENAME_EDIT, _T("bnk"), filename, pDlg);

	if ((pDlg->fp = fopen(filename, "wb")) == NULL)
	{
		buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", filename);

		pDlg->MessageBox(buffer, "IO-56 NES File Error!", MB_ICONSTOP | MB_OK);
		pDlg->SendMessage(FINISHEDTHREADMESSAGE, 1, 1L);
		return 0;
	}
	
	pDlg->nes_advanced_save(pDlg->fp);
	pDlg->SendMessage(FINISHEDTHREADMESSAGE, 0, 1L);

	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg Thread Message Handlers

long CNESAdvancedDlg::OnThreadStarted(WPARAM wParam, LPARAM lParam)
{
	fp = NULL;
	m_Saving = TRUE;

	UpdateDialog();
	m_buffer.Format(_T("\r\n-------- Saving started at %s --------\r\n\r\n"), GetTime());
		
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
	
	return(0L);
}

long CNESAdvancedDlg::OnThreadFinished(WPARAM wParam, LPARAM lParam)
{
	m_Saving = FALSE;

	UpdateDialog();

	if (fp)
		fclose(fp);

	if (wParam)
	{
		if (dwExitCode)
		   TerminateThread(pThread->m_hThread, dwExitCode);

		dwExitCode = 0;

		m_buffer.Format(_T("\r\n\r\n-------- Saving terminated at %s --------\r\n\r\n"), 
		   GetTime());	
	}
	else
	{
		m_buffer.Format(_T("\r\n-------- Saving finished at %s --------\r\n"),
		   GetTime()); 
	}

	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
		
	return (0L);
}

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg Thread Update Window Function

void CNESAdvancedDlg::UpdateDialog() 
{
	((CComboBox*)GetDlgItem(IDC_LENGTH_COMBO            ))->EnableWindow(!m_Saving);
	((CStatic*  )GetDlgItem(IDC_BANKFILENAME_STATIC     ))->EnableWindow(!m_Saving);
	((CStatic*  )GetDlgItem(IDC_LENGTH_STATIC           ))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDC_BROWSE_BUTTON           ))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDC_PREFERENCES_BUTTON      ))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDC_PROGRAM_RADIO           ))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDC_CHARACTER_RADIO         ))->EnableWindow(!m_Saving);
	((CEdit *   )GetDlgItem(IDC_NESADVANCEDFILENAME_EDIT))->EnableWindow(!m_Saving);
	((CButton*  )GetDlgItem(IDOK                        ))->EnableWindow(!m_Saving);

	((CButton*  )GetDlgItem(IDC_COMMAND_BUTTON          ))->
		SetWindowText(m_Saving ? "Stop" : "Save");	
}

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg message handlers

BOOL CNESAdvancedDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CRect rcClient, rcParent;
	((CWnd*)GetParent())->GetWindowRect(rcParent);
	GetWindowRect(rcClient);

	MoveWindow((((rcParent.Width() - rcClient.Width()) / 2) + rcParent.left),
		    (rcParent.top + 30), rcClient.Width(), rcClient.Height(), TRUE);

	switch(m_mode)
	{
		case 1:
		   m_windowtext = "IO-56 NES Write PRG/CHR";
		   m_buffer = "Write";			
		   break;

		case 2:
		   m_windowtext = "IO-56 NES Read PRG/CHR";
		   ((CEdit*)GetDlgItem(IDC_VALUE_EDIT))->SetReadOnly(TRUE);
		   m_buffer = "Read"; 
		   break;

		case 3:
		   m_windowtext = "IO-56 NES Save PRG/CHR";
		   m_buffer = "Save";
		   ((CEdit  *)GetDlgItem(IDC_COMMAND_BUTTON))->EnableWindow(FALSE);
		   ((CStatic*)GetDlgItem(IDC_ADDRESS_STATIC))->EnableWindow(FALSE);
		   ((CStatic*)GetDlgItem(IDC_ADDRESS_EDIT  ))->EnableWindow(FALSE);
		   ((CStatic*)GetDlgItem(IDC_VALUE_EDIT    ))->EnableWindow(FALSE);		
		   ((CStatic*)GetDlgItem(IDC_VALUE_STATIC  ))->EnableWindow(FALSE);
		   break;
	}

	SetWindowText(m_windowtext);

	((CComboBox*)GetDlgItem(IDC_LENGTH_COMBO))->SetCurSel(0);
	
	SetDlgItemText(IDC_VALUE_EDIT,         "00");
	SetDlgItemText(IDC_ADDRESS_EDIT,     "0000");
	
	SetDlgItemText(IDC_COMMAND_BUTTON, m_buffer);
	CheckDlgButton(IDC_PROGRAM_RADIO,         1);	

	if (m_mode != 3)
	{
		((CComboBox*)GetDlgItem(IDC_LENGTH_COMBO            ))->EnableWindow(FALSE);
		((CStatic*  )GetDlgItem(IDC_BANKFILENAME_STATIC     ))->EnableWindow(FALSE);
		((CStatic*  )GetDlgItem(IDC_LENGTH_STATIC           ))->EnableWindow(FALSE);
		((CButton*  )GetDlgItem(IDC_BROWSE_BUTTON           ))->EnableWindow(FALSE);
		((CEdit *   )GetDlgItem(IDC_NESADVANCEDFILENAME_EDIT))->EnableWindow(FALSE);
	}

	m_Saving = FALSE;

	return TRUE; 
}

void CNESAdvancedDlg::OnCancel() 
{
	if (!m_Saving)
		CDialog::OnCancel();
	else
		::Beep((DWORD)-1, (DWORD)-1);
}

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg Command Buttons message handlers

void CNESAdvancedDlg::OnCommandButton() 
{
	m_ProgramChecked = IsDlgButtonChecked(IDC_PROGRAM_RADIO);

	((CNESDlg *)GetParent())->nes_init();
	GetDlgItemText(IDC_ADDRESS_EDIT, m_buffer);
	sscanf(m_buffer, "%04x", &m_address);

	GetDlgItemText(IDC_VALUE_EDIT, m_buffer);
	sscanf(m_buffer, "%02x", &m_value);

	m_length = GetDlgItemInt(IDC_LENGTH_COMBO, FALSE);
	
	((CNESDlg *)GetParent())->nes_init();
	
	switch (m_mode)
	{
		case 1: nes_advanced_write(); break;
		case 2: nes_advanced_read();  break;

		case 3:
			
			if (m_Saving)
			{
			   SendMessage(FINISHEDTHREADMESSAGE, 1, 1L);
			   break;
			}
		
			pThread = AfxBeginThread(NESAdvancedSaveThread, this, THREAD_PRIORITY_NORMAL, 0,
									 CREATE_SUSPENDED);
		    	::GetExitCodeThread(pThread->m_hThread, &dwExitCode);
		    	pThread->ResumeThread();
			
			break;
	}
}

void CNESAdvancedDlg::OnPreferencesButton() 
{
	CPreferencesDlg dlg;

	dlg.DoModal();	
}

void CNESAdvancedDlg::OnHelpButton() 
{
	switch(m_mode)
	{
		case 1: WinHelp(IDH_WINVERMAINMENUNESADVANCEDWRITE); break;
		case 2: WinHelp(IDH_WINVERMAINMENUNESADVANCEDREAD);  break;
		case 3: WinHelp(IDH_WINVERMAINMENUNESADVANCEDSAVE);  break;
	}
}

BOOL CNESAdvancedDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	OnHelpButton();
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CNESAdvancedDlg Browse and Editbox message handlers

void CNESAdvancedDlg::OnNESAdvancedBrowseButton() 
{
	BrowseForFile(IDC_NESADVANCEDFILENAME_EDIT,
		(IsDlgButtonChecked(IDC_PROGRAM_RADIO))
		? "NESPRG" : "NESCHR", "bnk", 
		(IsDlgButtonChecked(IDC_PROGRAM_RADIO))
		? "NES Program Bank" : "NES Character Bank",
		(IsDlgButtonChecked(IDC_PROGRAM_RADIO))
		? "Enter Program Bank Image Filename" : "Enter Character Bank Image Filename", this);
}

void CNESAdvancedDlg::OnChangeFilenameEdit() 
{
	GetDlgItemText(IDC_NESADVANCEDFILENAME_EDIT, m_buffer);
	((CEdit  *)GetDlgItem(IDC_COMMAND_BUTTON))->EnableWindow(!m_buffer.IsEmpty());	
}

void CNESAdvancedDlg::OnChangeAddressEdit() 
{
	FixHexEditBox(0, IDC_ADDRESS_EDIT, 4, 0xFFFF, 0x0000, this);	
}
	
void CNESAdvancedDlg::OnKillfocusAddressEdit() 
{
	FixHexEditBox(1, IDC_ADDRESS_EDIT, 4, 0xFFFF, 0x0000, this);
}

void CNESAdvancedDlg::OnChangeValueEdit() 
{
	FixHexEditBox(0, IDC_VALUE_EDIT, 2, 0xFFFF, 0x0000, this);
}

void CNESAdvancedDlg::OnKillfocusValueEdit() 
{
	FixHexEditBox(1, IDC_VALUE_EDIT, 2, 0xFFFF, 0x0000, this);
}

/////////////////////////////////////////////////////////////////////////////
// CSAdvancedNESDlg IO-56 NES.H Routines

void CNESAdvancedDlg::nes_advanced_write()
{
	if (m_ProgramChecked)
	{
	   NES_WR_PRG(m_value, m_address);
	}
	else
	{
	   NES_WR_CHR(m_value, m_address);
	}

	m_buffer.Format("\r\nWrite To %s Memory: %02Xh --> (%04X)", 
	m_ProgramChecked ? "PRG" : "CHR", m_value, m_address);
	
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
}

void CNESAdvancedDlg::nes_advanced_read()
{
	if (m_ProgramChecked)
	{
		NES_READ_PRG;
		m_value = _inp(A_8255_PC);
	}
	else
	{
		NES_READ_CHR;
		m_value = _inp(B_8255_PB);
	}

	m_buffer.Format("\r\nRead From %s Memory: (%04X) --> %02Xh ", 
	m_ProgramChecked ? "PRG" : "CHR", m_address, m_value);
	
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());
		
	m_buffer.Format("%02X", m_value);
	SetDlgItemText(IDC_VALUE_EDIT, m_buffer);
}

void CNESAdvancedDlg::nes_advanced_save(FILE *fp)
{
	unsigned int chk;
	unsigned long addr;

	GetDlgItemText(IDC_NESADVANCEDFILENAME_EDIT, m_filename);

	m_buffer.Format("Saving %dkb of %s memory to \"%s\" .", m_length, 
		         m_ProgramChecked ? "PRG" : "CHR", m_filename);
	   
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());

	m_length <<= 10;
	chk = 0;
	  
	for(addr = 0x0000; addr < m_length; addr++)
	{
	   if((addr&0xFF) == 0)
	   AddToEditBox(IDC_NESSTATUS_EDIT, ".", GetParent());
		  
	   m_value = ((CNESDlg *)GetParent())->nes_read_byte(addr,
		       (m_ProgramChecked ? NES_PRG : NES_CHR));
	   
	   chk += m_value;
	   if (fputc(m_value, fp) == EOF)
	   {
	       m_buffer.Format("An error occurred while creating \"%s\"!\n\nPlease correct the problem and try again.", m_filename); 
		
	       MessageBox(m_buffer,"IO-56 NES File Error!", MB_ICONSTOP | MB_OK);

	       SendMessage(FINISHEDTHREADMESSAGE, 1, 1L);		
	   }
	}	
	
	m_buffer.Format(" (%04X)\r\n",chk);
	AddToEditBox(IDC_NESSTATUS_EDIT, m_buffer, GetParent());	
}

