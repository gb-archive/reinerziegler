// NESDlg.h : header file
//

#define MAXBANKS		0x100

#define NES_CRD	 	0
#define NES_CWR		1
#define NES_POE		2
#define NES_RW			3
#define NES_CLK		4

#define NES_PRG		0
#define NES_CHR		1

#define NES_IDLE		OUTPORT(B_8255_PC, 0xFF)
#define NES_READ_PRG		OUTPORT(B_8255_PC, 0xFF-(0x01<<NES_POE))
#define NES_READ_CHR		OUTPORT(B_8255_PC, 0xFF-(0x01<<NES_CRD))

#define NES_WR_CHR(val, addr) \
	OUTPORT(B_8255_PC, 0xFF); \
	OUTPORT(B_8255_PROG, 0x80|PA_in|PB_out|PCl_out|PCh_out); \
	OUTPORT(B_8255_PC, 0xFF); \
	OUTPORT(A_8255_PB, ((addr)>>8)&0xFF); \
	OUTPORT(A_8255_PA, (addr)&0xFF); \
	OUTPORT(B_8255_PB, val); \
	OUTPORT(B_8255_PROG, CLR_PC(NES_CWR)); \
	OUTPORT(B_8255_PROG, SET_PC(NES_CWR)); \
	OUTPORT(B_8255_PROG, 0x80|PA_in|PB_in|PCl_out|PCh_out); \
	OUTPORT(B_8255_PC, 0xFF)

#define NES_WR_PRG(val, addr) \
	OUTPORT(B_8255_PC, 0xFF-(0x01<<NES_CLK)); \
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_out|PCh_out); \
	OUTPORT(A_8255_PB, ((addr)>>8)&0xFF); \
	OUTPORT(A_8255_PA, (addr)&0xFF); \
	OUTPORT(A_8255_PC, val); \
	OUTPORT(B_8255_PROG, CLR_PC(NES_RW)); \
	OUTPORT(B_8255_PROG, SET_PC(NES_CLK)); \
	OUTPORT(B_8255_PROG, CLR_PC(NES_POE)); \
	OUTPORT(B_8255_PROG, CLR_PC(NES_CLK)); \
	OUTPORT(B_8255_PROG, SET_PC(NES_POE)); \
	OUTPORT(B_8255_PROG, SET_PC(NES_RW)); \
	OUTPORT(A_8255_PROG, 0x80|PA_out|PB_out|PCl_in|PCh_in); \
	OUTPORT(B_8255_PROG, SET_PC(NES_CLK))

/////////////////////////////////////////////////////////////////////////////
// CNESDlg dialog

typedef struct Nes_info_ {
	int type;
	int nb_prg;
	int prg_bank_size;
	int nb_chr;
	int chr_bank_size;
	int has_vram;
} Nes_info;

UINT NESAnalyzeThread(LPVOID);
UINT NESSaveThread(LPVOID);

class CNESDlg : public CDialog
{
// Construction
public:
	CNESDlg(CWnd* pParent = NULL);   // standard constructor

	BOOL         m_Advanced, m_Saving, m_Analyzing;

	Nes_info     nes;
	CString      m_buffer, m_filename;
	
	DWORD        dwExitCode;
	CWinThread   *pThread;
	
	FILE	     	*fp;

	void         	nes_init();
	void         	nes_read_info();
	void         	nes_analyze();
	void	    	nes_save(FILE*);
	void         	nes_switch_init();
	void         	nes_count_prg_banks();
	void         	nes_count_chr_banks();
	void         	nes_switch_bank(int, int);
	inline int   	nes_read_byte(register unsigned int, int);
	unsigned int 	nes_checksum(unsigned int, unsigned int, int);
	void         	nes_find_prg_bank_size();
	void         	nes_find_chr_bank_size();
	void         	nes_test_vram();
	void         	nes_read_prg(FILE *fp);
	void         	nes_read_chr(FILE *fp);
	
	CString      	GetOperation(LPARAM lParam);
	void         	UpdateDialog();
	
// Dialog Data
	//{{AFX_DATA(CNESDlg)
	enum { IDD = IDD_NES_DIALOG };
	CComboBox	m_MMC;
	int		m_SaveFormat;
	int		m_Verify;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNESDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNESDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnAnalyzeButton();
	afx_msg void OnPreferencesButton();
	afx_msg void OnAdvancedButton();
	afx_msg void OnMainmenuButton();
	afx_msg void OnSaveButton();
	afx_msg void OnSelchangeInesmmCombo();
	afx_msg void OnNESFilenameBrowseButton();
	afx_msg void OnWriteprgchrButton();
	afx_msg void OnReadprgchrButton();
	afx_msg void OnChecksumprgchrButton();
	afx_msg void OnSaveprgchrButton();
	afx_msg void OnKillfocusCharacterbanksCombo();
	afx_msg void OnKillfocusProgrambanksCombo();
	afx_msg void OnHelpButton();
	virtual void OnCancel();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG

	afx_msg long OnThreadFinished(WPARAM wParam, LPARAM lParam);
	afx_msg long OnThreadStarted(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};
