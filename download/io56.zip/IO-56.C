/* Pinout of ISA card:
   BUFFER (8)
   B_8255 PORT A (8)
   B_8255 PORT B (8)
   B_8255 PORT Cl (4)
   B_8255 PORT Ch (4)
   A_8255 PORT A (8)
   A_8255 PORT B (8)
   A_8255 PORT Cl (4)
   A_8255 PORT Ch (4)
   GND,VCC... (8)
 */

/*
   0x0400 bytes = 1kB
   0x0800 bytes = 2kB
   0x1000 bytes = 4kB
   0x2000 bytes = 8kB
   0x4000 bytes = 16kB
   0x8000 bytes = 32kB
   0x10000 bytes = 64kB
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#ifdef __DJGPP__
#include <dos.h>
#include <pc.h>
#endif

#define A_8255			card_address
#define B_8255			(card_address+4)
#ifndef IO48
#define BUFFER			(card_address+8)
#endif
#define A_8255_PA		card_address
#define A_8255_PB		(card_address+1)
#define A_8255_PC		(card_address+2)
#define A_8255_PROG		(card_address+3)
#define B_8255_PA		(card_address+4)
#define B_8255_PB		(card_address+5)
#define B_8255_PC		(card_address+6)
#define B_8255_PROG		(card_address+7)

#define PA_in	0x10
#define PA_out	0x00
#define PB_in	0x02
#define PB_out	0x00
#define PCl_in	0x01
#define PCl_out 0x00
#define PCh_in	0x08
#define PCh_out 0x00

#define SET_PC(bit)		(0x01|((bit&0x07)<<1))
#define CLR_PC(bit)		((bit&0x07)<<1)

typedef struct Extension_ {
	char *name;							/* Extension name */
	void (*init)(void);					/* Invoked upon initialization */
	void (*no_flag)(void);				/* Invoked when no flag is specified */
	void (*analyze)(void);				/* Invoked when the '-a' flag is specified */
	void (*save)(FILE *);				/* Invoked when the '-s' flag is specified */
	void (*backup)(FILE *);				/* Invoked when the '-b' flag is specified */
	void (*restore)(FILE *);			/* Invoked when the '-r' flag is specified */
	void (*clear)();			        /* Invoked when the '-c' flag is specified */
	void (*test)();					/* Invoked when the '-t' flag is specified */
	void (*debug)(void);				/* Invoked when the '-d' flag is specified */
	int (*extra)(char **, int);			/* Invoked when an extra flag is specified */
	void (*usage)();				/* Print usage about extra flags */
} Extension;

unsigned int wait_delay;

#ifdef __DJGPP__
#define DELAY	delay(wait_delay)
#else
#define DELAY
#endif

#ifdef __GNUC__
#define INLINE inline
#else
#define INLINE static
#endif

/* Change those defines to match your compiler */
#ifdef __DJGPP__
#define OUTPORT(port, val)		outportb(port, val); DELAY
#define INPORT(port)			inportb(port)
#else
#define OUTPORT(port, val)
#define INPORT(port)			0
#endif

void usage(void);
void check_extension(char *);

#ifdef IO48
int card_address = 0x210;
#else
int card_address = 0x300;
#endif

int test_patterns[] = {
	0xFF,
	0x00,
	-1
};

#include "debug.h"
#include "test.h"
#include "gb.h"
#include "nes.h"
#include "snes.h"
#include "sms.h"
#include "vb.h"

Extension* extensions[] = {
	&debug_ext,
	&test_ext,
	&gb_ext,
	&nes_ext,
	&snes_ext,
	&sms_ext,
	&vb_ext,
	NULL
};

void reset_8255()
{
		/* Configure 8255's as input only. */
		OUTPORT(B_8255_PROG, 0x80|PA_in|PB_in|PCl_in|PCh_in);
		OUTPORT(A_8255_PROG, 0x80|PA_in|PB_in|PCl_in|PCh_in);
}

void check_extension(char *name)
{
	printf("Make sure you have connected the %s extension to the ISA card\n", name);
	printf("Press RETURN (Control-C to abort)...\n");
	getchar();
}

char *build_string(char *s, char *separator)
{
	static char buf[256];
	static int idx = 0;

	if(!s) {
		idx = 0;
		return buf;
	}
	if(idx && separator) {
		strcpy(&buf[idx], separator);
		idx += strlen(separator);
	}
	strcpy(&buf[idx], s);
	idx += strlen(s);
	return buf;
}

void usage(void)
{
	int e;

	build_string(NULL, NULL);
	for(e = 0; extensions[e]; e++)
		build_string(extensions[e]->name, " | ");
	printf("Usage: IO-56 {%s} [glob_opt...] [ext_opt...] [command...]\n", build_string(NULL, NULL));
	printf("\n"
	"Global options:\n"
	"    -p nb     Specify the address of the card: 0 = 0x300, 1 = 0x310 (default: 0)\n"
	"    -w nb     Specify the time in ms. to wait between I/O accesses (default: %d)\n"
	"\n"
	"Commands:\n", wait_delay);
	for(e = 0; extensions[e]; e++) if(extensions[e]->analyze) build_string(extensions[e]->name, ", ");
	printf(
	"    -a        Analyze the cartridge and print informations\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->save) build_string(extensions[e]->name, ", ");
	printf(
	"    -s file   Save cartridge ROM in a file\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->backup) build_string(extensions[e]->name, ", ");
	printf(
	"    -b file   Backup cartridge save-RAM in a file\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->restore) build_string(extensions[e]->name, ", ");
	printf(
	"    -r file   Restore cartridge save-RAM from a file\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->clear) build_string(extensions[e]->name, ", ");
	printf(
	"    -c        Clear cartridge save-RAM\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->test) build_string(extensions[e]->name, ", ");
	printf(
	"    -t        Test cartridge save-RAM (WARNING: save-RAM will be cleared)\n"
	"              Supported by: %s\n", build_string(NULL, NULL));
	for(e = 0; extensions[e]; e++) if(extensions[e]->debug) build_string(extensions[e]->name, ", ");
	printf(
	"    -d        Debug the extension\n"
	"              Supported by: %s\n", build_string(NULL, NULL));

	for(e = 0; extensions[e]; e++)
		if(extensions[e]->usage) {
			printf("Press <RETURN>...\n");
			getchar();
			extensions[e]->usage();
		}
	exit(1);
}

void main(int argc, char **argv)
{
	int arg, e, i;
	FILE *fp;

	wait_delay = 0;

	if(argc < 2)
		usage();

	/* Find extension */
	for(e = 0; extensions[e]; e++)
		if(!strcasecmp(argv[1], extensions[e]->name))
			break;
	if(!extensions[e])
		usage();

	/* Global options */
	for(arg = 2; arg < argc; arg++) {
		if(argv[arg][0] != '-')
			usage();
		switch(toupper(argv[arg][1])) {
			case 'P':
#ifdef IO48
				switch(atoi(argv[++arg])) {
					case 0:
						card_address = 0x210;
						break;
					case 1:
						card_address = 0x220;
						break;
					case 2:
						card_address = 0x230;
						break;
					case 3:
						card_address = 0x300;
						break;
					case 4:
						card_address = 0x310;
						break;
					case 5:
						card_address = 0x320;
						break;
					case 6:
						card_address = 0x330;
						break;
				}
#else
				card_address = (atoi(argv[++arg]) == 1 ? 0x310 : 0x300);
#endif
				continue;
			case 'W':
				wait_delay = atoi(argv[++arg]);
				continue;
		}
		break;
	}

	printf("\n"
	"Card address : 0x%03X\n"
	"Wait delay   : %u\n"
	"\n", card_address, wait_delay);


	reset_8255();
	if(extensions[e]->init)
		extensions[e]->init();

	/* Options */
	if(arg == argc) {
		if(!extensions[e]->no_flag)
			usage();
		extensions[e]->no_flag();
	} else
	for(; arg < argc; arg++) {
		if(argv[arg][0] != '-')
			usage();
		switch(toupper(argv[arg][1])) {
			case 'A':
				if(!extensions[e]->analyze)
					usage();
				extensions[e]->analyze();
				break;
			case 'S':
				if(!extensions[e]->save)
					usage();
				if((fp = fopen(argv[++arg], "wb")) == NULL) {
					printf("Error opening file %s\n", argv[arg]);
					exit(1);
				}
				extensions[e]->save(fp);
				fclose(fp);
				break;
			case 'B':
				if(!extensions[e]->backup)
					usage();
				if((fp = fopen(argv[++arg], "wb")) == NULL) {
					printf("Error opening file %s\n", argv[arg]);
					exit(1);
				}
				extensions[e]->backup(fp);
				fclose(fp);
				break;
			case 'R':
				if(!extensions[e]->restore)
					usage();
				if((fp = fopen(argv[++arg], "rb")) == NULL) {
					printf("Error opening file %s\n", argv[arg]);
					exit(1);
				}
				extensions[e]->restore(fp);
				fclose(fp);
				break;
			case 'C':
				if(!extensions[e]->clear)
					usage();
				extensions[e]->clear();
				break;
			case 'T':
				if(!extensions[e]->test)
					usage();
				extensions[e]->test();
				break;
			case 'D':
				if(!extensions[e]->debug)
					usage();
				extensions[e]->debug();
				break;
			default:
				if(!extensions[e]->extra)
					usage();
				i = extensions[e]->extra(&argv[arg], argc-arg);
				if(i < 0)
				  usage();
				arg += i;
				break;
		}
	}
	reset_8255();
}
