/************************************************/
/*												*/
/*	    definition file for ReadPlus V1.7       */
/* 		add constants for new modules			*/
/*      and for serial transfer					*/
/*												*/
/************************************************/

/* Programming algorithm defines */
#define AMD29FXXX     0
#define NEW_ALGOR     1

/* cartridge defines */
#define NO_SRAM 0
#define NO_MBC  0             

#define ROM		0
#define RAM     1    
#define File    2

#define MBC1    1
#define MBC2    2
#define MBC3    3
#define MBC4    4						/* RAM is equal to MBC3 ? */
#define MBC5    5						/* RAM is equal to MBC3 ! */

#define CHAR_CR    13                   /* Ascii CR */
#define CHAR_LF    10                   /* Ascii LF */
#define GBB_IDLE  128                   /* Idle char used by GB Flash */
#define GBB_RDY     1                   /* Ready char used by GB Flash */
#define ESCAPE     27                   /* Key character to break */
#define EXIT_OKAY   0                   /* Routine exit was normal */
#define EXIT_BRK    1                   /* Routine exit from break key */
#define NUM_IDLE    5                   /* Number of idles for Contact */

/* MBC defines */
#define ROM16_RAM8    0
#define ROM4_RAM32    1

char *type[] = {"ROM ONLY",                       // 0
				"ROM+MBC1",                       // 1
				"ROM+MBC1+SRAM",                  // 2
				"ROM+MBC1+SRAM(Battery)",         // 3
				"UNKNOWN",                        // 4
				"ROM+MBC2",                       // 5
				"ROM+MBC2(Battery)",              // 6
				"UNKNOWN",                        // 7
				"ROM+SRAM",                       // 8
				"ROM+SRAM(Battery)",              // 9
				"UNKNOWN",                        // A
				"ROM+MMM01",                      // B
				"ROM+MMM01+SRAM",                 // C
				"ROM+MMM01+SRAM(Battery)",        // D
				"UNKNOWN",                        // E
				"ROM+MBC3(Timer,Battery)",        // F
				"ROM+MBC3(Timer)+SRAM(Battery)",  // 10
				"ROM+MBC3",                       // 11
				"ROM+MBC3+SRAM",                  // 12
				"ROM+MBC3+SRAM(Battery)",         // 13
				"UNKNOWN",                        // 14
				"ROM+MBC4",                       // 15
				"ROM+MBC4+SRAM",                  // 16
				"ROM+MBC4+SRAM(Battery)",         // 17
				"UNKNOWN",                        // 18
				"ROM+MBC5",                       // 19
				"ROM+MBC5+SRAM",                  // 1A
				"ROM+MBC5+SRAM(Battery)",         // 1B
				"ROM+MBC5(Rumble)",               // 1C
				"ROM+MBC5(Rumble)+SRAM",          // 1D
				"ROM+MBC5(Rumble)+SRAM(Battery)", // 1E
				"UNKNOWN"};						  // 1F

int  rom[] 	 = { 32, 64, 128, 256, 512, 1024, 2048, 4096 };

int  ram[]   = { 0, 2, 8, 32, 128 };

int  mbc[]   = { NO_MBC, MBC1, MBC1, MBC1, NO_MBC, 
				 MBC2, MBC2, NO_MBC, NO_MBC, NO_MBC,
			     NO_MBC, NO_MBC, NO_MBC, NO_MBC, NO_MBC, 
			     MBC3, MBC3, MBC3, MBC3, MBC3, 
			     NO_MBC, MBC4, MBC4, MBC4, NO_MBC, 
			     MBC5, MBC5, MBC5, MBC5, MBC5, 
			     MBC5 }; 
			   
int sram[]   = { NO_SRAM, NO_SRAM, NO_SRAM, MBC1, NO_SRAM, 
				 NO_SRAM, MBC2, NO_SRAM, NO_SRAM, MBC1, 
				 NO_SRAM, NO_SRAM, NO_SRAM, MBC1, NO_SRAM, 
				 NO_SRAM, MBC3, NO_SRAM, NO_SRAM, MBC3, 
				 NO_SRAM, NO_SRAM, NO_SRAM, MBC3, NO_SRAM,
			     NO_SRAM, NO_SRAM, MBC3, NO_SRAM, NO_SRAM, 
			     MBC3 };

int 		   wait_delay, Cart_Bank;
int            newcart;
unsigned 	   checksum;
unsigned char  Algorithm, Size;   
unsigned long  Address = 0L;
unsigned char  DataPortValue;
unsigned char  header[0x50];

unsigned ctrlport;
unsigned dataport;
unsigned statusport;

#define GCTRL    ctrlport
#define GDATA    dataport
#define GSTATUS  statusport

enum BOOLEAN
   {
   false,
   true
   };

void delaytime(int i)
{
	while(i--);
}                      

void delay_10us()
{
long x;
   for (x=0;x<0x2000;x++);
}

void delay_100us()
{
long x;
   for (x=0;x<0x10000;x++);
}

void delay_20ms()
{
long x;
   for (x=0;x<0xfffff;x++);
}

// #define DELAY   delaytime(wait_delay)
#define DELAY   delay_10us()
#define BYTE    unsigned char
#define WORD    unsigned int
#define LONG    unsigned long

/* Change those defines to match your compiler. */
#define OUTPORT(port, val)      outp(port, val); DELAY
#define INPORT(port)            inp(port)

#ifdef  MK_FP
  #undef MK_FP
#endif
#define MK_FP(seg, ofs)     ((void far *) ((unsigned long) (seg)<<16|(ofs)))

void PrintChipSize(void);

LONG ChipSize (BYTE size);  

