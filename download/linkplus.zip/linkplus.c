/*********************************************/
/*									       	 */
/* PLEASE REPORT ANY COMMENTS AND            */
/* IMPROVEMENTS TO reinerziegler@GMX.de      */
/*                                           */
/* last edit 19-Apr-00 by Reiner Ziegler	 */
/*											 */
/*											 */
/* V1.0  first version, works...             */
/*											 */
/* Compiled with Microsoft C++ 1.51			 */
/*********************************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h> 
#include <fcntl.h>
#include <io.h> 
#include <math.h>    
#include <time.h>
#include "common.h"					/* defines for LinkPlus */ 

void usage(void)
{
	printf("\nLinkPlus Version 1.00 from Reiner Ziegler\n");
	printf("\t-a\tAnalyze file header\n");
	printf("\t-g\tGameLink cable programming (file1 file2 file3)\n");
}

/* exit program with errorcode 1 */

void ErrorExit(void)
{
   exit(1);
}

void PrgExit(unsigned char value)
{     
 switch (value)
  {
  case 0:
       printf("\nno Sync found !\n");
       break;
  case 1:
       printf("\nSync lost !\n");
       break;
  case 2:
       printf("\nESC key pressed !\n");
       break;
  }
 ErrorExit();
}

/* Send & receive a byte with GameBoy     */

int SerialTransfer(enum BOOLEAN lock, unsigned char out)
   {
   short int b,z;
   b = 0;

   if (lock) printf("send %x  ",out);   

   for (z = 0; z < 8; z++)
      {
      DataPortValue &= ~2;
      OUTPORT(GDATA, DataPortValue);
      if (out & 0x80)
         {
         DataPortValue |= 1;
         OUTPORT(GDATA, DataPortValue);
         }
      else
         {
         DataPortValue &= ~1;
         OUTPORT(GDATA, DataPortValue);
         }
      out = out << 1;
      DataPortValue |= 2;
      OUTPORT(GDATA, DataPortValue);

      b = b << 1;
      b = b + (((INPORT(GSTATUS) >> 5) & 1));

      }
   if (lock) { printf(" receive %x\n",b);
     getch(); }
   return (b);
   }

/* Delay then send & receive a byte with GameBoy. */
/* This gives GameBoy time to reload it's registers. */
/* Entry: lock holds state of serial lock */

int SerialTransferDelay(enum BOOLEAN lock, unsigned char out)
   {
   int i,j;

   for(i=0; i<(wait_delay/10); i++)        //waitdelay/10
      {
      for(j=0; j<3; j++);
      }
   return (SerialTransfer(lock, out));
   }

/* Send & receive a byte with GameBoy then wait for ready */

int SerialTransferWait(unsigned char out)
   {
   short int a;

   a = ~GBB_RDY;
   while (a != GBB_RDY)
      {
      a = SerialTransferDelay(true, out);
      out = GBB_IDLE;
 
      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            return(EXIT_BRK);
      }
   return(EXIT_OKAY);
   }

/* if port not specified set to LPT1 */

void SetInitPort(int port)
   {
   	dataport = *(unsigned far *)MK_FP(0x0040, 6 + 2*port);
	if(dataport == 0)
	{
		printf("Can't find address of parallel port %d...\n", port);
		ErrorExit();
	} else {
		statusport = dataport + 1;
		ctrlport   = dataport + 2;
		if(dataport != 0x378) printf("Parallel port %d is located at %X-%X\n", port, dataport, ctrlport);
	}
   DataPortValue = 0xfe;
   OUTPORT(GDATA, 0);
   }

 /* Wait for input ready character or escape */
char WaitReady(enum BOOLEAN lock, unsigned char c)
   {
   short int a;

   a = 0;
   while ((c != ESCAPE) && (a != GBB_RDY))
      {
      c = GBB_IDLE;
      a = SerialTransferDelay(lock, c);

      if (kbhit())
         c = getch();
      }
   return (c);
   }

/* Wait for CR character or escape */
char WaitCR(VOID)
   {
   short int a;
   unsigned char c;

   a = 0;
   while (a != CHAR_CR)
      {
      c = GBB_IDLE;
      a = SerialTransferDelay(true, c);

      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            return(EXIT_BRK);
      }
   return (EXIT_OKAY);
   }

/* Return on Serial Lock or break key */
void SerialLock(enum BOOLEAN lock)
   {
   LONG i = 0;
   unsigned char GbbIdle = GBB_IDLE;
   short int a,GBtype;
   short int cnt = 0;

   printf("Press ESC to exit.\n");
   printf("Trying to contact GameBoy ...");

   while (cnt < NUM_IDLE)
      {
      GBtype = SerialTransferDelay(lock, GbbIdle);
      a      = SerialTransferDelay(lock, GbbIdle);
 
 	  if ((cnt == 0) && (a == GbbIdle)) {
		switch (GBtype)
		{
        case 0x01:
             printf("\nGameBoy or SuperGameBoy");
             break;
        case 0xff:
             printf("\nPocketGameBoy or SuperGameBoy2");
             break;
        case 0x11:
             printf("\nColorGameBoy");
             break;
   	  	}
 	  }	
 
      /* If we receive NUM_IDLE idles in a row then exit */
      if (a == GBB_IDLE) cnt++;
      else cnt = 0;
   
      /* Exit if break key pressed */
      if (kbhit())
         if (getch() == ESCAPE)
            PrgExit(2);
	  i++;	
      }
      printf(" found !\ntransmit ");
  }

/* send 0xF0 for erase chip     */
/*      0xF1 for next cartbank  */
/*      0xF2 for reset module   */

void SendCartCommand(BYTE value, enum BOOLEAN lock)
{
  		 BYTE a,c,old = 0x40; 
 		 
         a = SerialTransfer(lock, 0x40);
         a = SerialTransfer(lock, 0x40);
         if (a != 0x40) PrgExit(0);

		 c = value;			 
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;

    	 c = 9;
	     a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;  

    	 c = 4;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;                      

    	 c = 61;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;             

    	 c = 0;
 		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;                 

    	 c = 0;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;

		 c = 0x40;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;
}

void TerminalMode(FILE * fp, enum BOOLEAN lock)
{
   LONG i = 0;	
   unsigned char c;
   BYTE a,old = 0x40;   
   int byte, AdrReg = 0;

   while ((!feof(fp)) && (i < (ChipSize(Size)/8)))
      {
         /* Clear everything in GB Flash     */
         /* input buffer by sending '@' char */

         a = SerialTransfer(lock, 0x40);
         a = SerialTransfer(lock, 0x40);
         if (a != 0x40) PrgExit(0);
		 
		 c = (BYTE)Cart_Bank;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;
		 c = (BYTE)((i & 0x7ffff) >> 14);
         a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;  
		 c = (BYTE)((i & 0x3fff) >> 8);
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;                      
		 c = (BYTE)(i & 0xff);
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;             
		 c = 0x10;
 		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;                 
		 c = 0x00;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;

		 c = 0x40;
		 a = SerialTransfer(lock,c);
		 if (a != old ) PrgExit(1);
		 old = c;

		 printf(".");          

         for (byte = 0; byte < 0x1000; byte++) {
/*			if(feof(fp)) {
			   printf("Unexpected EOF\n");
			   ErrorExit();
			}
*/          
			c = (BYTE)fgetc(fp);
            a = SerialTransfer(lock,c);
     	    if (a != old ) PrgExit(1);
		    old = c;
            i++;
         }   
         /* Exit if break key pressed */
         if (kbhit())
           if ((c =getch()) == ESCAPE) PrgExit(2);

         c = 0x40;
         a = SerialTransfer(lock,c);
     	 if (a != old ) PrgExit(1);
		 old = c;   
//       printf("ready");        
//		 getch();
         c = 0x40;
         a = SerialTransfer(lock,c);
     	 if (a != old ) PrgExit(1);
		 old = c;   
//		 printf("\n+1");
//		 getch();
   }
   printf(" ready\n");
}
    

/* Return actual chip size in bits */

LONG ChipSize (BYTE size)
   {
   BYTE i;
   LONG Length = 16384;

   for(i=0; i<size; i++)
      Length *= 2;

   return(Length);
   }

/* Print chip size */

void PrintChipSize (void)
   {
   LONG i = ChipSize(Size);
   printf("Chip size     : %lu bits (%lu bytes)\n", i, i/8);
   }

void read_header(unsigned char *h, BYTE mode, FILE * fp)
{
	int byte, index = 0;
 	fpos_t pos;
    char Gname[30] = {0};                                                                      
    
	PrintChipSize();
	/* Set file position to header and read data */
    pos = 0x100;
   	fsetpos( fp, &pos );
	for(byte = 0; byte < 0x50; byte++) {
		h[index++] = fgetc(fp);
	}                        
	pos = 0x00;
	fsetpos( fp, &pos );

	strncat(Gname,&h[0x34],16);                  
	printf("Game name     : %s\n", Gname);

	if(h[0x43] == 0x80)
		printf("              : Color GameBoy Game, but will run on old GameBoy also\n"); 
	
	if(h[0x43] == 0xC0)
		printf("              : Color GameBoy Game, will not run on old GameBoy\n"); 

	if(h[0x46] == 0x03)
		printf("              : Super GameBoy functions included\n");

	if(h[0x4A] == 0x01)
		printf("              : Non-Japanese Game\n"); 

	if(h[0x4A] == 0x00)
		printf("              : Japanese Game\n"); 

	if(h[0x47] <= 0xFB) {    
		printf("Cartridge type: %d(%s)\n", h[0x47], type[h[0x47]]); }

	if(h[0x47] == 0xFC) {
		printf("Cartridge type: %d(%s)\n", h[0x47], "Pocket Camera");
	    h[0x47] = 0x13; }

	if(h[0x47] == 0xFD) {
		printf("Cartridge type: %d(%s)\n", h[0x47], "Bandai TAMA5");
	    h[0x47] = 0x13; }

	if(h[0x47] == 0xFE) {    
		printf("Cartridge type: %d(%s)\n", h[0x47], "ROM+HuC3"); 
	    h[0x47] = 0x03; }

	if(h[0x47] == 0xFF) {
		printf("Cartridge type: %d(%s)\n", h[0x47], "ROM+HuC1+SRAM(Battery)");
	    h[0x47] = 0x03; }

	printf("ROM size      : %d(%d kB)\n", h[0x48], rom[h[0x48]]);

	if(sram[h[0x47]] == MBC2)
		printf("RAM size      : 512*4 Bit\n");
	else	
		printf("RAM size      : %d(%d kB)\n", h[0x49], ram[h[0x49]]);
	checksum = ((unsigned)h[0x4E] << 8) + h[0x4F];
}


/* Pauses for a specified number of microseconds. */
void sleep( clock_t wait )
{
   clock_t goal;
   goal = wait + clock();
   while( goal > clock() );
}    


void main(int argc, char **argv)
{
	int arg, fh;
	FILE *fp;
 	char fname[20] = {"startup.gb"};     
	double Fsize = 0;
    enum BOOLEAN lock = false;

	printf("\n");
	if(argc < 2) {
		usage();
		ErrorExit();
	}

    wait_delay = 2000;
    sleep( (clock_t)CLOCKS_PER_SEC/32);

	for(arg = 1; arg < argc; arg++) {
		if(argv[arg][0] != '-') {
			usage();
			ErrorExit();
		}
		switch(toupper(argv[arg][1])) {
            case 'G':
    				wait_delay = wait_delay/20;
                    SetInitPort(1);
                    do {
                   		if ((fh = _open( fname, _O_RDONLY))  == -1 ) { 
                       		printf("Error opening file %s\n", fname);
                       		ErrorExit();
                    	}
   				    	if (_filelength( fh ) <= 2048L) { Size = 0; }
   				    	else {      
   					   		Fsize = (log(_filelength( fh )/2048)/log(2));   
   					   		// printf("File size     : %.0f\n",Fsize); 
   					   		Size = (unsigned char)Fsize;
   					   		_close( fh ); }
				  		if ((fp = fopen(fname, "rb")) == NULL) {
                       		printf("Error opening file %s\n", fname);
                       		ErrorExit();
                    	}
						read_header(header,File,fp);
						printf("\n");
  						/* Wait for serial lock or escape key */
						SerialLock(lock);
						if (Cart_Bank == 0) SendCartCommand(0xf0,lock);
              			TerminalMode(fp,lock);
						printf("\n");   				
                    	fclose(fp);
   						/* add extension .GB if none present */
         				strcpy(fname, argv[++arg]);
         				if (strchr(fname, '.') == NULL)
            			strcat(fname, ".gb");
            			Cart_Bank++;
						SendCartCommand(0xf1,lock); }
            		while ((strlen(fname) > 3) & (Cart_Bank < 4)); 
					SendCartCommand(0xf2,lock);
                    break;
			case 'A':
                   /* add extension .GB if none present */
         			strcpy(fname, argv[++arg]);
         			if (strchr(fname, '.') == NULL)
            		strcat(fname, ".gb");
 					if (strlen(fname) == 3) {
						break;
					}				
               		if ((fh = _open( fname, _O_RDONLY))  == -1 ) { 
                       	printf("Error opening file %s\n", fname);
                       	ErrorExit();
                    }
   				    if (_filelength( fh ) <= 2048L) {
   				       Size = 0; }
   				    else {      
   					   Fsize = (log(_filelength( fh )/2048)/log(2));   
   					   printf("File size     : %.0f\n",Fsize); 
   					   Size = (unsigned char)Fsize;
   					   _close( fh ); }
				  	if ((fp = fopen(fname, "rb")) == NULL) {
                       	printf("Error opening file %s\n", fname);
                       	ErrorExit();
                    }
					read_header(header,File,fp);
                    fclose(fp);
					break;
			default:
					usage();
                    ErrorExit();
		}
	}
	exit(0);
}


