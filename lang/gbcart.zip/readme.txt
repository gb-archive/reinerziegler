GBcart1.0

GBCart is a Windows 9x frontend for readplus.

It supports the most frequently used commands of
readplus.

readplus, startup.gb (for the multicart option) and the 
emulator program must be located in the same dirctory 
as gbcart. 

Program options are stored in gbcart.ini.


