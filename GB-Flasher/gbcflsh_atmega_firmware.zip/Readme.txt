GB Cart Flasher firmware files for ATMEGA8515 microcontroller in IntelHex format.
Fuse bits configuration is described in User's Manual.