#!/bin/bash
if [ ! $UID -eq 0 ]; then
    echo "You must have root privileges to use install!"
else
    cp gbcflsh /usr/bin
    cp gbcflsh_english.qm /usr/bin
    cp gbcflsh.desktop /usr/share/applications
    cp gbicon.xpm /usr/share/icons
fi
